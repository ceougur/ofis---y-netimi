/* DestekOfis — Banka (v2.1.0; docs/BANKA-MODULU-PLAN.md §8). Sol menüde Taksitler'in hemen altında (kullanıcı kararı, K13).
 * Pencere sekmeleri: Genel Bakış · Hesaplar · Hareketler · Ayarlar. POS ile Ekstre ve Mutabakat sekmeleri o özellikler gelince görünür
 * (yarım özellik görünmez, §12.1).
 *  - Hareketler (Aşama 4; §8.6): sunucuda sayfalanan dizin (imleçli "Daha Fazla Göster", HOF.listGate), süzgeçler (hesap, tür, giriş/çıkış,
 *    durum, tarih, tutar, arama), yürüyen bakiye (tek hesap seçili ve başka süzgeç yokken), "Planlı İşlemler" görünümü (deftere girmez;
 *    Gerçekleştir / Atla / Sil) ve "+ Masraf", "+ Faiz", "+ Diğer İşlem", "+ Planlı İşlem". Satır → İşlem Kartı: fiş satırları, bağlar,
 *    Ters Kaydet, Düzelt, Açıklamayı Düzelt; pasif düğmenin nedeni görünür yazıyla. Benzer İşlem'de (409 bank-similar) "Yine de Kaydet"
 *    aynı istek kimliğiyle gönderilir (similarOk). Fiş formunun vergi ve hesap varsayılanları Banka Ayarları'ndan (voucher-meta).
 *  - Transfer (Aşama 9; §3.7 #11): Hareketler'de ve Hesap Detayı'nda "Transfer" (Transfer Yapma yetkisi): Gönderen / Alıcı Hesap, tutar, kanal,
 *    valör, isteğe bağlı ücret (BSMV Dahil / Hariç / Yok); önizleme "Alıcıya Giren · Ücret · Gönderenden Çıkan". Aynı form Düzelt ve Planlı
 *    İşlem'de. Genel Bakış'ta "Bugün ve Bu Ay": Giriş / Çıkış dış hareketler, Transfer Giriş / Çıkış ayrı (iki kez sayılmaz).
 *  - Genel Bakış (K10): ana değer Gerçek Banka (banka hesaplarının 102 bakiyeleri); Kart ve Kredi Borcu yalnız kart/kredi hesabı varsa;
 *    Hesabı Atanmamış Eski Hareketler ayrı satırda, hiçbir toplama girmez ("Şimdi Düzenle").
 *  - Hesaplar: liste, hesap kartı (aç, düzelt, Pasife Al, sil), Hesap Detayı (son hareketler, Açılışı Düzelt), Alt Hesap Mizanı.
 *  - Ayarlar: Temel ve Gelişmiş; standartlar seçili gelir; bölüm bölüm ve tümü "Varsayılanlara Dön" (kullanıcı kararı).
 *  - Kurulum Sihirbazı: Banka'yı ilk açan hesap yetkilisine bir kez (kişi ve şirket bazında, sunucuda); her adım atlanabilir, atlanırsa
 *    Genel Bakış'ta "Kurulumu Tamamla" kalır. Eski Hareketleri Aktar adımı yalnız hesabı atanmamış hareket varsa.
 *  - Ortak hesap seçici (HOF.bank.pickerHtml / mountPicker / attachPicker; K13): tek hesapta bilgi satırı (kimlik gönderilmez, sunucu seçer),
 *    hiç hesap yoksa bugünkü görünüm; liste form açılışında tazelenir; modül tahsilat/ödeme formları kullanır.
 * Kurallar sunucuda (server/lib/bank/accounts.mjs, settings.mjs); ekran yalnız gösterir, pasif düğmenin nedeni yanında yazılır. */
(() => {
  "use strict";
  const HOF = window.HOF;
  const { esc } = HOF;
  const BASE = "/api/workspace/bank";
  // Sekme sırası (§8.2): Hareketler Hesaplar'dan hemen sonra (Aşama 4). POS (2.2.0) ve Ekstre ve Mutabakat (2.3.0) kendi betiklerinden
  // HOF.bank.addTab ile Ayarlar'dan önce eklenir (hof-bank-pos.js).
  const BASE_TABS = [
    ["overview", "Genel Bakış"],
    ["accounts", "Hesaplar"],
    ["movements", "Hareketler"],
  ];
  const extraTabs = new Map();
  const tabList = () => [...BASE_TABS, ...[...extraTabs.entries()].filter(([, spec]) => !spec.visible || spec.visible()).map(([id, spec]) => [id, spec.label]), ["settings", "Ayarlar"]];
  const KINDS = [
    ["demand", "Vadesiz"],
    ["commercial", "Ticari"],
    ["time", "Vadeli"],
    ["fx", "Döviz"],
    ["loan", "Kredi Hesabı"],
    ["card", "Kredi Kartı"],
    ["other", "Diğer"],
  ];
  const CURRENCIES = [
    ["TRY", "TL"],
    ["USD", "USD"],
    ["EUR", "EUR"],
    ["GBP", "GBP"],
  ];
  const POLICY_LABELS = { warn: "Uyar", block: "Engelle", off: "Kontrol Yok" };
  const STATUS_CHIPS = [
    ["active", "Etkin"],
    ["passive", "Pasif"],
    ["all", "Tümü"],
  ];
  const KEYWORD_GROUPS = [
    ["pos", "POS"],
    ["cash", "Nakit"],
    ["transfer", "Virman"],
    ["fee", "Ücret"],
    ["interest", "Faiz"],
  ];
  const BANK_NAMES = ["Akbank", "Albaraka Türk", "Denizbank", "Enpara.com", "Fibabanka", "Garanti BBVA", "Halkbank", "HSBC", "ING", "İş Bankası", "Kuveyt Türk", "Odeabank", "QNB", "Şekerbank", "TEB", "Türkiye Finans", "VakıfBank", "Vakıf Katılım", "Yapı Kredi", "Ziraat Bankası", "Ziraat Katılım"];
  // 102 ailesi (Gerçek Banka'ya giren hesaplar); kart 309, kredi 300 (Kart ve Kredi Borcu).
  const MAIN_KINDS = new Set(["demand", "commercial", "time", "fx", "other"]);
  const BINDABLE_KINDS = new Set(["demand", "commercial", "other"]);
  // v2.2.0 (İz 2.2): hesabın kullanım işaretleri — yalnız Vadesiz, Ticari ve Diğer TL hesapta (sunucu başka türde 400 bank-flag-kind verir).
  const FLAG_FIELDS = [
    ["useCard", "Kredi Kartı Kullan (altına kart eklenir)"],
    ["useCheque", "Çek Kullan (verilen çekte Çek Hesabı olarak seçilir; alınan çek bu hesaba tahsile verilir)"],
    ["useNote", "Senet Kullan (verilen senedin ödeme hesabı olarak önerilir; alınan senet bu hesaba tahsile verilir)"],
    ["usePos", "POS Kullan (altına POS tanımlanır)"],
  ];
  const FLAG_SHORT = { useCard: "Kredi Kartı", useCheque: "Çek", useNote: "Senet", usePos: "POS" };
  // 2.1 (müşteri sorusu "doğrulanmadı ne demek?"): durumun adı ve ne yapılacağı açık.
  const UNCONFIRMED = "Açılış Bakiyesi Doğrulanmadı";
  const UNCONFIRMED_WHY = "Açılış bakiyesi bankadaki gerçek bakiyeyle teyit edilmedi; bu hesapta eksi bakiye denetimi kapalı. Doğrulamak için hesaba tıklayın → Açılışı Düzelt → “Bu tutar bankadaki gerçek bakiyedir”i işaretleyin.";
  // Sunucunun alan adı (HttpError field) → formdaki alan.
  const FIELD_OF = { iban: "iban", code: "code", currency: "currency", kind: "kind", "Banka Adı": "bankName", "Hesap Adı": "name", date: "openingDate", "Açılış Tarihi": "openingDate", "Açılış Bakiyesi": "openingAmount", "Açılış Kuru": "openingRate", Limit: "creditLimit", "Ekstre Kesim Günü": "statementDay", "Son Ödeme Günü": "dueDay", negativePolicy: "negativePolicy" };

  // Alanı yazmayan hatalar (tarih, kilit) koddan alana bağlanır.
  const FIELD_OF_CODE = { "date-future": "openingDate", "date-invalid": "openingDate", "date-missing": "openingDate", "period-locked": "openingDate", "bank-opening-after-first": "openingDate", "rate-invalid": "openingRate" };

  let modal = null;
  // 2.4.3 (C11): pencere kapanırken açık olan sekme (oturum içinde; sayfa yenilenince Genel Bakış).
  let lastTab = "overview";
  // Eklenen bölümlerin yükleyicileri (HOF.bank.addReloadHook): pencere her yenilendiğinde aynı kapıdan, çizimden önce.
  const reloadHooks = new Set();
  let wizard = null;
  let ticket = 0;
  let wizardOffered = false;
  let choicesCache = null;
  let metaCache = null;
  const view = { tab: "overview", mode: "tab", accountId: "", status: "active", summary: null, list: null, account: null, settings: null, choices: null, legacy: null, legacyStale: false, runs: null, error: "", advanced: false, dirty: false, selected: new Set(), legacyTarget: "", eventRef: "", event: null, eventBack: "movements", meta: null, due: null, latest: null };
  // Hareket listeleri (Aşama 4): Hareketler sekmesi ve Hesap Detayı ayrı durum ve ayrı liste kapısıyla (HOF.listGate: eski yanıt yeni
  // süzgeci ezmez; süzgeç yüklenirken "Daha Fazla" yok sayılır).
  const PAGE = 50;
  const newMoves = (key, filter = {}) => ({ key, filter: { account: "", type: "", dir: "", status: "", from: "", to: "", min: "", max: "", q: "", pos: "", ...filter }, planned: false, rows: [], plans: [], balance: false, hasMore: false, cursor: null, loaded: false, error: "", account: "", gate: HOF.listGate() });
  const moves = newMoves("main");
  let accountMoves = newMoves("account");

  const moduleName = () => HOF.uiLabel?.("side.bank", "Banka") || "Banka";
  const root = () => modal?.dialog.querySelector("[data-bank]");
  const canAccounts = () => HOF.can("bank.accounts");
  const api = (path, options) => HOF.api(`${BASE}${path}`, options);
  const decimal = new Intl.NumberFormat("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmt = (minor, currency = "TRY") => {
    const value = Number(minor || 0) / 100;
    if (!currency || currency === "TRY") return HOF.formatMoney(value);
    return new Intl.NumberFormat("tr-TR", { style: "currency", currency, maximumFractionDigits: 2 }).format(value);
  };
  const signed = (minor, currency) => `${minor > 0 ? "+" : minor < 0 ? "−" : ""}${fmt(Math.abs(minor), currency)}`;
  const amountInput = minor => (minor ? decimal.format(Number(minor) / 100) : "");
  const kindLabel = kind => KINDS.find(([id]) => id === kind)?.[1] || kind;
  const currencyLabel = code => CURRENCIES.find(([id]) => id === code)?.[1] || code;
  const dateText = value => (value ? HOF.formatDate(`${value}T12:00:00`) : "—");
  // POS komisyon oranı en az iki ondalıkla ("2,5" → "2,50"; plan §8.9 örneği "%3,50"); dört ondalığa kadar olduğu gibi.
  const pctText = rate => {
    const text = String(rate ?? "").trim();
    if (!text) return "";
    const [whole, frac = ""] = text.split(",");
    return `${whole},${frac.padEnd(2, "0")}`;
  };
  const td = (label, html, cls = "") => `<td data-label="${esc(label)}"${cls ? ` class="${cls}"` : ""}>${html}</td>`;
  const accountLabel = account => `${account.bankName} · ${account.name}`;
  const openingLabel = kind => (kind === "card" || kind === "loan" ? "Açılıştaki Borç" : "Açılış Bakiyesi");
  /** Döviz hesabı bu sürümde kapalı (sunucu config.fxEnabled; Genel Bakış features.fx). */
  const fxOn = () => Boolean(view.summary?.features?.fx);
  // GG2 (düşük): salt okunur lisansta yöneticiye yanlış neden (yetki) gösterilmez.
  const READ_ONLY_TEXT = "Program salt okunur çalışıyor (lisans); kayıt değiştirilemez.";
  const limitLabel = kind => (kind === "card" ? "Kart Limiti" : kind === "loan" ? "Kredi Limiti" : "KMH Limiti");

  // ---------- Pencere ----------
  function open({ tab = "", accountId = "", legacy = false } = {}) {
    if (!HOF.can("bank.view")) return HOF.toast("Banka penceresi Banka Görüntüleme yetkisi olan hesaplara açıktır.", { type: "error" });
    if (!modal) {
      // 2.4.3 (C11): pencere yeniden açılınca son sekme ve Hareketler'in süzgeci (oturum içinde; sayfa yenilenince baştan) hatırlanır — Rapor
      // Merkezi'nin son dönemi hatırlaması gibi. Önceden her açılış Genel Bakış'la ve "Tüm Hesaplar"la başlıyordu. İstenen sekme/hesap önceliklidir.
      view.tab = tabList().some(([id]) => id === lastTab) ? lastTab : "overview";
      view.mode = "tab";
      modal = HOF.modal({
        title: moduleName(),
        eyebrow: "OPERASYON",
        size: "wide",
        body: '<div class="hof-bank" data-bank><p class="hof-empty">Yükleniyor…</p></div>',
        // GG2 (düşük): Ayarlar'da kaydedilmemiş değişiklik varken pencere sorusuz kapanmaz (sekme değişimindeki aynı soru).
        beforeClose: () => (view.dirty && view.tab === "settings" ? HOF.confirm({ title: "Kaydedilmemiş Değişiklik", message: "Banka ayarlarında kaydedilmemiş değişiklik var. Kaydetmeden çıkılsın mı?", confirmLabel: "Kaydetmeden Çık", danger: true }) : true),
        onClose: () => {
          modal = null;
          // İşlem Kartı ya da Hesap Detayı açıkken kapanırsa geldiği sekme hatırlanır.
          if (view.mode === "tab") lastTab = view.tab;
          else if (view.mode === "event" && tabList().some(([id]) => id === view.eventBack)) lastTab = view.eventBack;
          else if (view.mode === "account") lastTab = "accounts";
          clearTimeout(dateTimer);
          // Gelişmiş Ayarlar her açılışta kapalı gelir (GG2 düşük bulgu).
          view.advanced = false;
          view.mode = "tab";
          view.accountId = "";
          view.account = null;
          view.eventRef = "";
          view.event = null;
          view.dirty = false;
          view.selected = new Set();
          // 2.4.3 (C11): Hareketler'in süzgeci ve Planlı görünümü kalır (oturum içinde); liste yeniden açılışta sunucudan taze yüklenir.
          Object.assign(moves, { rows: [], plans: [], loaded: false, cursor: null, hasMore: false, error: "" });
        },
      });
      modal.dialog.classList.add("hof-bank-modal");
      modal.dialog.addEventListener("click", onClick);
      modal.dialog.addEventListener("change", onChange);
      modal.dialog.addEventListener("input", onInput);
      modal.dialog.addEventListener("keydown", onKey);
      // 2.4.3 (C7): tarih süzgecinden çıkınca beklemeden uygulanır.
      modal.dialog.addEventListener("focusout", event => {
        if (event.target.matches?.('input[type="date"][data-mv]')) applyFilters();
      });
    }
    if (tab) setTab(tab, { load: false });
    if (accountId) {
      view.mode = "account";
      view.accountId = accountId;
    } else if (legacy) enterLegacy();
    render();
    return reload({ first: true });
  }
  const viewKey = () => `${view.mode}|${view.tab}|${view.accountId}|${view.eventRef}`;
  /**
   * Eski Hareketler görünümüne geçiş. CI 460 kararı: önceki ziyaretin listesi (önbellek) hemen çizilir, sunucunun yanıtı gelince yenilenir.
   * 2.1.0 temel sürüm (küçük düzeltmeler): önbellekten çizilen liste taze yanıt gelene kadar SEÇİLEMEZ (legacyStale; canPick). Arada Kurulum
   * Sihirbazı, Bu Hesaba Ata ya da başka bir pencere satırı bağlamış olabilir; önceden önbellekteki satır seçilip Bu Hesaba Ata'ya basılabiliyordu
   * (sunucu 409 bank-already-assigned; veri bozulmaz ama kullanıcı yanlış uyarı görür). Bankaya Geçmiş Say / Kart Borcuna Aktar formları zaten
   * tıklama anında sunucudan okur (CI 460); onlar önbellekle durabilir.
   */
  function enterLegacy() {
    view.mode = "legacy";
    view.selected = new Set();
    view.legacyStale = Boolean(view.legacy);
  }

  /** Pencerenin verisi: özet ve hesaplar her zaman; görünüme göre hesap kartı, eski hareketler ya da ayarlar. */
  async function reload({ quiet = false, first = false } = {}) {
    const own = quiet ? ticket : ++ticket;
    const key = viewKey();
    const options = quiet ? { background: true } : {};
    try {
      const [summary, list] = await Promise.all([api("/summary", options), api("/accounts?status=all", options)]);
      const next = { summary, list };
      if (view.mode === "account" && view.accountId) {
        next.account = await api(`/accounts/${encodeURIComponent(view.accountId)}`, options);
        // Hesap Detayı'nda hesabın hareketleri (yürüyen bakiyeli dizin; §8.5): ilk çizimde boş görünmesin diye hesapla birlikte yüklenir.
        if (accountMoves.filter.account !== view.accountId) accountMoves = newMoves("account", { account: view.accountId });
        await loadMoves(accountMoves, { quiet, paint: false });
      }
      if (view.mode === "legacy") {
        [next.legacy, next.runs] = await Promise.all([api("/legacy", options), api("/setup", options).then(data => data.runs)]);
        next.legacyStale = false;
      }
      const settingsTab = view.mode === "tab" && view.tab === "settings";
      if (settingsTab && !view.dirty) [next.settings, next.choices] = await Promise.all([api("/settings", options), api("/choices", options)]);
      if (view.mode === "tab" && view.tab === "overview") {
        // Vadesi gelen planlı işlemler (rozetin nedeni) ve son banka hareketleri (§8.4 "Son Banka Hareketleri"); ikisi de yalnız okur.
        [next.due, next.latest] = await Promise.all([api("/plans?due=1", options).then(data => data.plans).catch(() => []), api(`/movements?limit=10`, options).then(data => data.rows).catch(() => [])]);
      }
      if (view.mode === "tab" && view.tab === "movements") {
        // 2.2.0 (İz 3.3): POS süzgecinin seçenekleri (POS tanımlıysa görünür).
        [next.meta, next.posList] = await Promise.all([voucherMeta().catch(() => view.meta), api("/pos?status=", options).then(data => data.pos || []).catch(() => view.posList || [])]);
        await loadMoves(moves, { quiet, paint: false });
      }
      // Eklenen sekmenin ve bölümlerin verisi (HOF.bank.addTab / addReloadHook; POS: liste, işlemler, takvim): aynı yenileme kapısından.
      const extra = view.mode === "tab" ? extraTabs.get(view.tab) : null;
      await Promise.all([...(extra?.load ? [extra.load({ quiet, options })] : []), ...[...reloadHooks].map(hook => hook({ mode: view.mode, tab: view.tab, accountId: view.accountId, quiet, options }))]);
      if (view.mode === "event" && view.eventRef) next.event = await api(`/events/${encodeURIComponent(view.eventRef)}`, options);
      if (!modal || own !== ticket || key !== viewKey()) return;
      // Ayarlar düzenlenirken arka plan yenilemesi formu ezmez (kaydedilmemiş değişiklik kaybolmasın): veri alınır, ekran çizilmez.
      const keepForm = settingsTab && view.dirty;
      if (keepForm) delete next.settings;
      Object.assign(view, next, { error: "" });
      if (view.legacy) view.selected = new Set([...view.selected].filter(id => view.legacy.rows.some(row => rowKey(row) === id && canPick(row))));
      if (!keepForm) render();
      if (first) maybeWizard();
    } catch (error) {
      if (!modal || own !== ticket || key !== viewKey()) return;
      if (quiet && !HOF.lostRecord(error)) throw error;
      if (view.mode === "account" && error.status === 404) {
        HOF.toastError(error);
        view.mode = "tab";
        view.tab = "accounts";
        view.accountId = "";
        view.account = null;
        return reload();
      }
      if (view.mode === "event" && error.status === 404) {
        HOF.toastError(error);
        view.eventRef = "";
        view.event = null;
        return goBack();
      }
      view.error = error.message;
      render();
    }
  }

  function setTab(tab, { load = true } = {}) {
    if (!tabList().some(([id]) => id === tab)) return;
    view.tab = tab;
    view.mode = "tab";
    view.accountId = "";
    view.account = null;
    view.eventRef = "";
    view.event = null;
    if (tab !== "settings") view.dirty = false;
    if (load) {
      render();
      reload();
    }
  }
  function openAccount(id) {
    view.mode = "account";
    view.accountId = id;
    view.account = null;
    view.eventRef = "";
    view.event = null;
    render();
    reload();
  }
  /** İşlem Kartı (§8.6): İşlem No ya da kimlikle. Geri dönüş açıldığı yere (Hareketler, Hesap Detayı, Genel Bakış); kart → kart geçişinde değişmez. */
  function openEvent(ref, { back = "" } = {}) {
    if (!ref) return;
    if (view.mode !== "event") view.eventBack = back || (view.mode === "account" ? "account" : view.mode === "tab" ? view.tab : "movements");
    view.mode = "event";
    view.eventRef = ref;
    view.event = null;
    render();
    reload();
  }
  function goBack() {
    view.eventRef = "";
    view.event = null;
    if (view.eventBack === "account" && view.accountId) {
      view.mode = "account";
      render();
      return reload();
    }
    return setTab(tabList().some(([id]) => id === view.eventBack) ? view.eventBack : "movements");
  }

  function render() {
    const node = root();
    if (!node) return;
    const extra = view.mode === "tab" ? extraTabs.get(view.tab) : null;
    const content = view.mode === "account" ? accountHtml() : view.mode === "legacy" ? legacyHtml() : view.mode === "event" ? eventHtml() : extra ? extraHtml(extra) : view.tab === "accounts" ? accountsHtml() : view.tab === "movements" ? movementsHtml() : view.tab === "settings" ? settingsHtml() : overviewHtml();
    const tabs = `<div class="hof-bank-tabs" role="tablist" aria-label="Banka bölümleri">${tabList().map(([id, label]) => `<button type="button" role="tab" class="hof-rep-chip ${view.mode === "tab" && view.tab === id ? "is-on" : ""}" aria-selected="${view.mode === "tab" && view.tab === id}" data-tab="${id}">${esc(label)}</button>`).join("")}</div>`;
    HOF.swap(node, `${tabs}<div class="hof-bank-body">${content}</div>`);
  }

  /** Eklenen sekmenin içeriği (HOF.bank.addTab): sekmenin kendi html()'i; hata olursa sekme boş kalmaz, neden yazılır. */
  function extraHtml(spec) {
    try {
      return spec.html() || HOF.listPending(view.error);
    } catch (error) {
      return `<p class="hof-empty">${esc(error?.message || "Bölüm gösterilemedi.")}</p>`;
    }
  }

  // ---------- Genel Bakış (K10) ----------
  function overviewHtml() {
    const s = view.summary;
    if (!s) return HOF.listPending(view.error);
    const accounts = view.list?.accounts || [];
    const mains = accounts.filter(account => MAIN_KINDS.has(account.kind));
    const debts = accounts.filter(account => !MAIN_KINDS.has(account.kind));
    const labels = s.labels || {};
    const active = mains.filter(account => account.status === "active").length;
    // Döviz (Aşama 13) bu sürümde yok: Para Birimi ve TL Karşılığı sütunları yalnız döviz açıkken ya da TL dışı hesap varken görünür (bütün hesaplar
    // TL iken TL Karşılığı = Gerçek Bakiye, aynı sayı iki sütunda; ertelenen özelliği ima ediyordu — 2.1.0 temel sürüm denetimi).
    const fxCols = fxOn() || mains.some(account => account.currency !== "TRY");
    const tiles = [
      `<div class="hof-rep-stat hof-bank-real is-in"><span>${esc(labels.realBank || "Gerçek Banka")}</span><strong data-bank-real>${s.realBank.defined ? esc(fmt(s.realBank.minor)) : "—"}</strong><small>${s.realBank.defined ? `${active} etkin hesap${fxCols ? " · TL karşılığı" : ""}` : "Banka Hesabı Tanımlanmadı"}</small></div>`,
    ];
    if (debts.length) tiles.push(`<div class="hof-rep-stat is-out"><span>${esc(labels.debt || "Kart ve Kredi Borcu")}</span><strong data-bank-debt>${esc(fmt(s.debt.totalMinor))}</strong><small>Kart ${esc(fmt(s.debt.cardMinor))} · Kredi ${esc(fmt(s.debt.loanMinor))}</small></div>`);
    const rows = [];
    if (s.setup?.needed) {
      rows.push(
        canAccounts()
          ? `<div class="hof-bank-row is-setup" data-bank-setup><div><b>Kurulumu Tamamla</b><small>Banka hesaplarınızı ve açılış bakiyelerini girin; hesap tanımlanmadan girilmiş eski hareketleri hesaba aktarın.</small></div><button type="button" class="hof-button hof-button-small" data-act="wizard">Kurulumu Tamamla</button></div>`
          : `<div class="hof-bank-row is-setup"><div><b>Kurulum Bekliyor</b><small>${esc(HOF.license?.writable === false ? READ_ONLY_TEXT : "Banka hesaplarını Banka Hesabı Tanımlama yetkisi olan kişi tanımlar.")}</small></div></div>`,
      );
    }
    const unassigned = s.unassigned || { totalMinor: 0 };
    // Toplam bugüne kadarki satırlardır; eski sürümden kalan ileri tarihli satırlar ayrı bilgi (tarihi gelince atanır; 2.1.0 temel sürüm).
    const ahead = unassigned.future?.count ? unassigned.future : null;
    if (unassigned.totalMinor || unassigned.newCount || ahead) {
      rows.push(`<div class="hof-bank-row is-unassigned" data-bank-unassigned><div><b>${esc(labels.unassigned || "Hesabı Atanmamış Eski Hareketler")}</b> <strong>${esc(fmt(unassigned.totalMinor))}</strong>
        <small>Havale / EFT (102.00) ${esc(fmt(unassigned.bankMinor))} · POS / Kart (108.00) ${esc(fmt(unassigned.cardMinor))} — Gerçek Banka'ya ve hiçbir toplama girmez.${unassigned.newCount ? ` Hesabı belirsiz yeni hareket: ${unassigned.newCount}.` : ""}</small>${ahead ? `<small data-bank-unassigned-future>Tarihi gelmemiş ${ahead.count} eski hareket (${esc(signed(ahead.totalMinor))}, ilk ${esc(dateText(ahead.firstDate))}) bu toplama girmez; tarihi gelince atanabilir.</small>` : ""}</div>
        <button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="legacy">Şimdi Düzenle</button></div>`);
    }
    // Vadesi gelen planlı işlemler (rozette sayılır; Aşama 4): deftere kendiliğinden yazılmaz, kullanıcı Gerçekleştir ile kaydeder.
    if (view.due?.length) {
      rows.push(`<div class="hof-bank-row is-due" data-bank-due><div><b>Vadesi Gelen Planlı İşlemler</b> <strong>${view.due.length}</strong>
        <small>Planlı işlemler deftere kendiliğinden yazılmaz; bankada gerçekleştiyse Hareketler → Planlı İşlemler'den “Gerçekleştir” ile kaydedin.</small></div>
        <button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="plans-due">Planlı İşlemleri Aç</button></div>`);
    }
    let table = "";
    // Aşama 9 (§8.4 K10; §12.3 Aşama 6 "Banka Bugün Çıkış transferi saymaz, Transfer satırında"): Bugün ve Bu Ay giriş-çıkışı. Giriş/Çıkış dış
    // hareketlerdir; şirketin kendi hesapları arasındaki para (Kasa ile Banka Arası, Bankalar Arası Transfer, kredi, kart borcu) ayrı Transfer
    // kolonlarındadır, iki kez sayılmaz. Transfer ücreti ve kredi faizi Çıkış'tadır.
    let flowsHtml = "";
    if (s.flows && s.realBank.defined) {
      const f = s.flows;
      const cell = (label, minor, attr) => td(label, `<span data-flow-${attr}="${Number(minor) || 0}">${esc(fmt(minor))}</span>`, "num");
      const line = (key, label, item, fee) => `<tr data-flow="${key}">${td("Dönem", `<b>${esc(label)}</b>`)}${cell("Giriş", item.inMinor, "in")}${cell("Çıkış", item.outMinor, "out")}${cell("Transfer Giriş", item.transferInMinor, "tin")}${cell("Transfer Çıkış", item.transferOutMinor, "tout")}${fee === null ? td("Banka Masrafları", "—", "num") : cell("Banka Masrafları", fee, "fee")}</tr>`;
      flowsHtml = `<h4 class="hof-bank-subtitle">Bugün ve Bu Ay</h4><div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-flows" data-bank-flows><thead><tr><th>Dönem</th><th class="num">Giriş</th><th class="num">Çıkış</th><th class="num">Transfer Giriş</th><th class="num">Transfer Çıkış</th><th class="num">Banka Masrafları</th></tr></thead><tbody>${line("today", "Bugün", f.today, null)}${line("month", "Bu Ay", f.month, f.month.feeMinor ?? 0)}</tbody></table></div>
        <p class="hof-rep-note">Giriş ve Çıkış: cari, fatura, taksit, çek ve banka fişi hareketleri. Transfer: şirketin kendi hesapları arasında (Kasa ile Banka Arası, Bankalar Arası Transfer, kredi, kart borcu); giriş ve çıkışa sayılmaz. Transfer ücreti ve kredi faizi Çıkış'tadır.</p>`;
    }
    if (mains.length) {
      const groups = new Map();
      for (const account of mains) {
        if (!groups.has(account.bankName)) groups.set(account.bankName, []);
        groups.get(account.bankName).push(account);
      }
      const body = [...groups.entries()]
        .map(([bank, list]) => {
          const lines = list
            .map(account => `<tr data-account="${esc(account.id)}" tabindex="0" class="${account.status === "passive" ? "is-passive" : ""}">
              ${td("Banka", esc(bank))}
              ${td("Hesap", `<b>${esc(account.name)}</b> <small>${esc(account.code)} · ${esc(account.glSub)}${account.status === "passive" ? " · Pasif" : ""}</small>`)}
              ${fxCols ? td("Para Birimi", esc(currencyLabel(account.currency))) : ""}
              ${td("Gerçek Bakiye", esc(fmt(account.currency === "TRY" ? account.balanceMinor : account.fxBalanceMinor, account.currency)), "num")}
              ${fxCols ? td("TL Karşılığı", esc(fmt(account.balanceMinor)), "num") : ""}
              ${td("Son Hareket", esc(account.lastMovementDate ? dateText(account.lastMovementDate) : "—"))}
            </tr>`)
            .join("");
          const subMinor = list.reduce((sum, account) => sum + account.balanceMinor, 0);
          const sub = list.length > 1 ? `<tr class="hof-bank-subtotal"><td colspan="${fxCols ? 4 : 2}" data-label="Ara Toplam">Ara Toplam · ${esc(bank)}</td>${td(fxCols ? "TL Karşılığı" : "Gerçek Bakiye", esc(fmt(subMinor)), "num")}<td class="hof-bank-blank"></td></tr>` : "";
          return lines + sub;
        })
        .join("");
      const totals = (s.byCurrency || []).map(item => (fxCols ? `<tr class="hof-bank-total"><td colspan="3" data-label="Toplam">Toplam ${esc(currencyLabel(item.currency))}</td>${td("Gerçek Bakiye", esc(fmt(item.currency === "TRY" ? item.tryMinor : item.fxMinor, item.currency)), "num")}${td("TL Karşılığı", esc(fmt(item.tryMinor)), "num")}<td class="hof-bank-blank"></td></tr>` : `<tr class="hof-bank-total"><td colspan="2" data-label="Toplam">Toplam</td>${td("Gerçek Bakiye", esc(fmt(item.tryMinor)), "num")}<td class="hof-bank-blank"></td></tr>`)).join("");
      table = `<h4 class="hof-bank-subtitle">Banka Hesapları</h4><div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table"><thead><tr><th>Banka</th><th>Hesap</th>${fxCols ? "<th>Para Birimi</th>" : ""}<th class="num">Gerçek Bakiye</th>${fxCols ? '<th class="num">TL Karşılığı</th>' : ""}<th>Son Hareket</th></tr></thead><tbody>${body}</tbody><tfoot>${totals}</tfoot></table></div>`;
    }
    if (debts.length) {
      table += `<h4 class="hof-bank-subtitle">Kart ve Kredi Hesapları</h4><div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table"><thead><tr><th>Banka</th><th>Hesap</th><th>Tür</th><th class="num">Borç</th></tr></thead><tbody>${debts
        .map(account => `<tr data-account="${esc(account.id)}" tabindex="0">${td("Banka", esc(account.bankName))}${td("Hesap", `<b>${esc(account.name)}</b> <small>${esc(account.code)} · ${esc(account.glSub)}</small>`)}${td("Tür", esc(account.kindLabel))}${td("Borç", esc(fmt(-account.balanceMinor)), "num")}</tr>`)
        .join("")}</tbody></table></div>`;
    }
    // Boş durum yalnız anlatır; tek düğme yukarıdaki "Kurulumu Tamamla" satırında (kart kalabalığı yok, talimat 35).
    const empty = accounts.length
      ? ""
      : `<div class="hof-bank-empty" data-bank-empty><h4>Henüz Banka Hesabı Yok</h4><p>${canAccounts() ? "Banka hesaplarınızı ve açılış bakiyelerini Kurulum Sihirbazı ile birkaç adımda girin. " : ""}Hesap tanımlanana kadar havale / EFT ile girilen tahsilat ve ödemeler “Hesabı Atanmamış Eski Hareketler”de toplanır.</p></div>`;
    // Son Banka Hareketleri (§8.4; 10 satır, tek kaynaktan): satır İşlem Kartı'nı açar.
    const latest = view.latest?.length
      ? `<div class="hof-bank-subhead"><h4 class="hof-bank-subtitle">Son Banka Hareketleri</h4><button type="button" class="hof-link-button" data-act="mv-open">Tüm Hareketler</button></div>
        <div class="hof-bank-table-wrap">${moveTableHtml(view.latest, { showAccount: true, showBalance: false, extraClass: "hof-bank-latest" })}</div>`
      : "";
    return `<div class="hof-rep-stats hof-bank-stats">${tiles.join("")}</div>${rows.join("")}${empty}${table}${flowsHtml}${latest}
      <p class="hof-rep-note">Gerçek Banka: banka hesaplarınızın (102) defter bakiyelerinin toplamı. Hesabı atanmamış eski hareketler bu toplama girmez.</p>`;
  }

  // ---------- Hesaplar ----------
  function accountsHtml() {
    if (!view.list) return HOF.listPending(view.error);
    const shown = view.list.accounts.filter(account => view.status === "all" || account.status === view.status);
    const tools = [
      canAccounts() ? '<button type="button" class="hof-button hof-button-small" data-act="new">+ Yeni Hesap</button>' : "",
      canAccounts() ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="wizard">Kurulum Sihirbazı</button>' : "",
      // Hesabı atanmamış eski hareket ya da geri alınabilir kurulum varsa (Genel Bakış'taki satır bakiye sıfırken görünmez).
      canAccounts() && (view.summary?.unassigned?.totalMinor || view.summary?.unassigned?.future?.count || view.summary?.setup?.runs) ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="legacy">Eski Hareketler</button>' : "",
      HOF.can("bank.reports") ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="subtrial">Alt Hesap Mizanı</button>' : "",
    ].join("");
    const rows = shown
      .map(
        account => `<tr data-account="${esc(account.id)}" tabindex="0" class="${[account.status === "passive" ? "is-passive" : "", account.depth ? "hof-bank-child" : ""].filter(Boolean).join(" ")}">
          ${td("Kod", `<b>${esc(account.code)}</b>`)}
          ${td("Banka ve Hesap", `${account.depth ? '<span class="hof-bank-child-mark" aria-hidden="true">↳</span> ' : ""}${esc(accountLabel(account))}${account.cardLast4 ? ` <span class="hof-plan-refno">•••• ${esc(account.cardLast4)}</span>` : ""}${account.branchName ? `<small>${esc(account.branchName)}</small>` : ""}${suggestHtml(account)}`)}
          ${td("Tür", esc(account.kindLabel))}
          ${td("Para Birimi", esc(currencyLabel(account.currency)))}
          ${td("IBAN", account.ibanText ? `<span class="hof-bank-iban">${esc(account.ibanText)}</span>` : "—")}
          ${td("Alt Hesap", esc(account.glSub))}
          ${td("Bakiye", `${esc(fmt(MAIN_KINDS.has(account.kind) ? (account.currency === "TRY" ? account.balanceMinor : account.fxBalanceMinor) : -account.balanceMinor, account.currency))}${MAIN_KINDS.has(account.kind) ? "" : "<small>borç</small>"}`, "num")}
          ${td("Durum", `${account.status === "active" ? '<span class="hof-plan-badge is-done">Etkin</span>' : '<span class="hof-plan-badge is-muted">Pasif</span>'}${account.balanceConfirmed ? '<small class="hof-bank-ok">Bakiye Doğrulandı</small>' : `<small class="is-warn" data-unconfirmed title="${esc(UNCONFIRMED_WHY)}">${UNCONFIRMED}</small>`}`)}
        </tr>`,
      )
      .join("");
    const empty = view.status === "active" && !view.list.accounts.length ? (canAccounts() ? "Banka hesabı yok. “+ Yeni Hesap” ya da Kurulum Sihirbazı ile ekleyin." : "Banka hesabı yok.") : "Bu süzgeçte hesap yok.";
    return `<div class="hof-bank-toolbar">${tools}<div class="hof-rep-presets" role="group" aria-label="Durum">${STATUS_CHIPS.map(([id, label]) => `<button type="button" class="hof-rep-chip ${view.status === id ? "is-on" : ""}" data-status="${id}">${esc(label)}</button>`).join("")}</div></div>
      <div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-accounts"><thead><tr><th>Kod</th><th>Banka ve Hesap</th><th>Tür</th><th>Para Birimi</th><th>IBAN</th><th>Alt Hesap</th><th class="num">Bakiye</th><th>Durum</th></tr></thead><tbody>${rows || `<tr><td colspan="8" class="hof-empty">${esc(empty)}</td></tr>`}</tbody></table></div>
      ${shown.some(account => !account.balanceConfirmed) ? `<p class="hof-rep-note hof-bank-unconfirmed-note" data-unconfirmed-note><b>${UNCONFIRMED}:</b> ${esc(UNCONFIRMED_WHY)}</p>` : ""}
      <p class="hof-rep-note">Hesap Kodu sizindir (ör. ZIR-TL); alt hesap kodunu (102.01) program verir ve değişmez. Kredi kartları bağlı oldukları banka hesabının altında görünür; kart, banka hesabının ayrıntısındaki “+ Kredi Kartı Ekle” ile tanımlanır. Satıra tıklayınca hesabın ayrıntısı açılır.</p>`;
  }
  /**
   * v2.2.0 (İz 2.3): bankasına bağlanmamış eski kart için öneri — aynı bankanın hesabı (sunucunun parentSuggestions'ı). Kendiliğinden bağlanmaz;
   * "Bağla" kartı o hesaba bağlar (PUT parentId).
   */
  function suggestHtml(account) {
    if (account.kind !== "card" || account.parentId || !account.parentSuggestions?.length) return "";
    const target = account.parentSuggestions[0];
    const button = canAccounts() && HOF.license?.writable !== false ? ` <button type="button" class="hof-link-button" data-act="link-card" data-card="${esc(account.id)}" data-parent="${esc(target.id)}">Bağla</button>` : "";
    return `<small class="hof-bank-suggest" data-card-suggest="${esc(account.id)}">Öneri: ${esc(target.label)} hesabının altına bağlanabilir.${button}</small>`;
  }

  // ---------- Hesap Detayı (§8.5) ----------
  function accountHtml() {
    const a = view.account;
    const back = '<button type="button" class="hof-plan-back" data-act="back">← Hesaplar</button>';
    if (!a) return `<div class="hof-bank-detail-head">${back}</div>${HOF.listPending(view.error)}`;
    const main = MAIN_KINDS.has(a.kind);
    const balance = main ? (a.currency === "TRY" ? a.balanceMinor : a.fxBalanceMinor) : -a.balanceMinor;
    const fact = (label, value) => (value ? `<div><dt>${esc(label)}</dt><dd>${value}</dd></div>` : "");
    const opening = a.opening;
    // GG2 (düşük): satırsız (sıfır) açılış "girilmemiş" sayılır — yerine ilk açılışı girmek ters kayıt yazmaz, bank.cancel istemez.
    const openingSet = Boolean(opening?.hasLines);
    const openingAction = openingSet ? "Açılışı Düzelt" : "Açılış Bakiyesi Gir";
    const policy = a.balanceConfirmed ? `${esc(POLICY_LABELS[a.policy] || a.policy)}${a.negativePolicy ? "" : " <small>(Banka Ayarlarındaki)</small>"}` : `Kontrol Yok <small>(${esc(a.policyNote)})</small>`;
    const blocks = [];
    const canCancel = HOF.can("bank.cancel");
    const readOnly = HOF.license?.writable === false;
    let openingBlock = "";
    if (readOnly) openingBlock = READ_ONLY_TEXT;
    else if (opening && a.openingLocked) openingBlock = `Açılış (${dateText(opening.date)}) kilitli dönemde; ${dateText(a.lockedUntil)} tarihine kadar kayıtlar değiştirilemez.`;
    else if (openingSet && !canCancel) openingBlock = "Eski açılış ters kaydedilir; Banka Hareketi Silme, İptal ve Ters Kayıt yetkisi gerekir.";
    let deleteBlock = "";
    if (readOnly) deleteBlock = READ_ONLY_TEXT;
    else if (a.movementCount) deleteBlock = `Bu hesaba bağlı ${a.movementCount} hareket var; kullanılmayacaksa Pasife Alın.`;
    else if (a.setupNo) deleteBlock = `Hesap Kurulum Sihirbazı'yla kuruldu (${a.setupNo}); önce Hesaplar → Eski Hareketler → Kurulum Geçmişi'nden Geri Al.`;
    else if (a.plannedCount) deleteBlock = `Bu hesapta ${a.plannedCount} planlı işlem var; önce Planlı İşlemler'den silin.`;
    else if (openingSet && a.openingLocked) deleteBlock = "Hesabın açılışı kilitli dönemde; hesap silinemez.";
    else if (openingSet && !canCancel) deleteBlock = "Açılışı olan hesabı silmek için Banka Hareketi Silme, İptal ve Ters Kayıt yetkisi gerekir.";
    if (canAccounts()) {
      if (openingBlock) blocks.push([openingAction, openingBlock]);
      if (deleteBlock) blocks.push(["Sil", deleteBlock]);
    }
    // Hesap Detayı'ndan hareket girişi (§8.5: + Masraf, + Faiz, …): hesabın türüne göre; pasif hesapta pasif ve nedeni yazılı. Döviz
    // hesabında fiş Aşama 13'te (yarım özellik görünmez).
    const moveButtons = [];
    if (HOF.can("bank.move") && a.currency === "TRY") {
      const why = a.status === "active" ? "" : "Hesap pasif; işlem girmek için önce Etkinleştir.";
      if (["demand", "commercial", "other"].includes(a.kind)) moveButtons.push(["v-fee", "+ Masraf", why, ""], ["v-interest", "+ Faiz", why], ["v-other", "+ Diğer İşlem", why]);
      // 2.4.3 MM3: Vergi Ödemesi (B 360 / A 102; Vergi Ödemesi ve KDV Mahsubu yetkisi).
      if (["demand", "commercial", "other"].includes(a.kind) && HOF.can("tax.manage")) moveButtons.push(["v-tax", "+ Vergi Ödemesi", why]);
      else if (a.kind === "time") moveButtons.push(["v-interest", "+ Faiz", why, ""]);
      else if (a.kind === "card") moveButtons.push(["v-card", "+ Kart Borcu Ödemesi", why, ""]);
      else if (a.kind === "loan" && HOF.can("bank.transfer")) moveButtons.push(["v-loan", "+ Kredi İşlemi", why, ""]);
    }
    // Aşama 9 (§8.5 "Transfer"): bankalar arası transfer bu hesaptan (Transfer Yapma yetkisi; vadeli hesap dahil).
    if (HOF.can("bank.transfer") && a.currency === "TRY" && ["demand", "commercial", "other", "time"].includes(a.kind)) moveButtons.push(["v-transfer", "Transfer", a.status === "active" ? "" : "Hesap pasif; işlem girmek için önce Etkinleştir."]);
    if (a.status !== "active" && moveButtons.length) blocks.push(["Hareket Girişi", "Hesap pasif; işlem girmek için önce Etkinleştir."]);
    const button = (act, label, why = "", cls = "hof-button-ghost") => `<button type="button" class="hof-button hof-button-small ${cls}" data-act="${act}" ${why ? `disabled aria-disabled="true" title="${esc(why)}"` : ""}>${esc(label)}</button>`;
    const actions = [
      ...moveButtons.map(([act, label, why, cls]) => button(act, label, why, cls)),
      ...(canAccounts()
        ? [
            button("edit", "Düzenle"),
            button("opening", openingAction, openingBlock, openingSet ? "hof-button-ghost" : ""),
            button("status", a.status === "active" ? "Pasife Al" : "Etkinleştir"),
            button("delete", "Sil", deleteBlock, "hof-button-danger-ghost"),
          ]
        : []),
    ].join("");
    return `<div class="hof-bank-detail-head">${back}
        <div class="hof-plan-title"><h3>${esc(accountLabel(a))} <span class="hof-plan-refno">${esc(a.code)}</span> ${a.status === "active" ? '<span class="hof-plan-badge is-done">Etkin</span>' : '<span class="hof-plan-badge is-muted">Pasif</span>'}</h3><small>${esc(a.kindLabel)} · ${esc(currencyLabel(a.currency))} · Alt Hesap ${esc(a.glSub)}</small></div>
        <div class="hof-chq-amount"><span>${main ? "Gerçek Bakiye" : "Borç"}</span><strong data-bank-balance>${esc(fmt(balance, a.currency))}</strong>${a.currency !== "TRY" && main ? `<small>TL karşılığı ${esc(fmt(a.balanceMinor))}</small>` : ""}</div>
      </div>
      <p class="hof-bank-confirm ${a.balanceConfirmed ? "is-ok" : "is-warn"}" data-confirm-line>${a.balanceConfirmed ? "✓ Bakiye Doğrulandı" : `<b>${UNCONFIRMED}.</b> ${esc(a.policyNote)} Doğrulamak için ${canAccounts() && !openingBlock ? `<button type="button" class="hof-link-button" data-act="opening">${esc(openingAction)}</button>` : `“${esc(openingAction)}”`} ile açılışı açıp “Bu tutar bankadaki gerçek bakiyedir”i işaretleyin.`}</p>
      <dl class="hof-chq-facts">
        ${fact("Bağlı Banka Hesabı", a.kind === "card" ? (a.parentId ? `<button type="button" class="hof-link-button" data-open-account="${esc(a.parentId)}">${esc(a.parentLabel)}${a.parentCode ? ` (${esc(a.parentCode)})` : ""}</button>` : `Bağlı değil${a.parentSuggestions?.length ? ` · ${suggestHtml(a)}` : ""}`) : "")}
        ${fact("Son 4 Hane", a.cardLast4 ? `•••• ${esc(a.cardLast4)}` : "")}
        ${fact("Kullanım", BINDABLE_KINDS.has(a.kind) ? FLAG_FIELDS.filter(([key]) => a[key]).map(([key]) => FLAG_SHORT[key]).join(" · ") || "İşaret yok (Düzenle'den Kredi Kartı, Çek, Senet ya da POS Kullan seçilir)" : "")}
        ${fact("IBAN", a.ibanText ? `<span class="hof-bank-iban">${esc(a.ibanText)}</span>` : "")}
        ${fact("Şube", esc([a.branchName, a.branchCode].filter(Boolean).join(" · ")))}
        ${fact("Hesap No", esc(a.accountNo))}
        ${fact("Hesap Sahibi", esc(a.holder))}
        ${fact("SWIFT", esc(a.swift))}
        ${fact(limitLabel(a.kind), a.creditLimitMinor ? esc(fmt(a.creditLimitMinor)) : "")}
        ${fact("Hesap Kesim Günü", a.statementDay ? esc(String(a.statementDay)) : "")}
        ${fact("Son Ödeme Günü", a.dueDay ? esc(String(a.dueDay)) : "")}
        ${fact(openingLabel(a.kind), opening ? `${esc(fmt(opening.amountMinor, a.currency))} · ${esc(dateText(opening.date))}${opening.no && openingSet ? ` · <span class="hof-plan-refno">${esc(opening.no)}</span>` : ""}` : "Girilmedi")}
        ${fact("Eksi Bakiye Denetimi", policy)}
        ${fact("Faturada", a.showOnInvoice ? "IBAN faturada gösterilir" : "")}
        ${fact("Açıklama", esc(a.description))}
      </dl>
      ${actions ? `<div class="hof-chq-actions" role="toolbar" aria-label="Hesap işlemleri">${actions}</div>` : ""}
      ${blocks.length ? `<ul class="hof-inv-blocks" data-bank-blocks>${blocks.map(([name, why]) => `<li><b>${esc(name)} kapalı:</b> ${esc(why)}</li>`).join("")}</ul>` : ""}
      ${linkedSectionsHtml(a)}
      <div class="hof-bank-subhead"><h4 class="hof-bank-subtitle">Hesap Hareketleri</h4><button type="button" class="hof-link-button" data-act="mv-account">Hareketler'de Süz</button></div>
      <div class="hof-bank-moves-wrap" data-moves="account" data-account="${esc(accountMoves.account)}">${movesListHtml(accountMoves)}</div>
      <p class="hof-rep-note">Yürüyen bakiye en yeni hareketten geriye doğru; satıra tıklayınca İşlem Kartı açılır.</p>`;
  }
  /**
   * v2.2.0 (İz 2.2–2.3): banka hesabının altındaki bölümler — "Kredi Kartları" (Kredi Kartı Kullan işaretli ya da kartı olan hesapta; kart
   * listesi + "+ Kredi Kartı Ekle") ve "POS'lar" (POS Kullan işaretli hesapta). POS'ların içeriği POS izinden gelir: HOF.bank.addAccountSection
   * ile kayıtlı bölüm (account → HTML) önce sorulur; kayıtlı bölüm yoksa yer tutucu yazı.
   */
  const accountSections = new Map();
  function linkedSectionsHtml(a) {
    if (!BINDABLE_KINDS.has(a.kind)) return "";
    const out = [];
    const writable = HOF.license?.writable !== false;
    if (a.useCard || a.cards?.length) {
      const add = canAccounts() && writable && a.status === "active" ? '<button type="button" class="hof-button hof-button-small" data-act="card-add">+ Kredi Kartı Ekle</button>' : "";
      const rows = (a.cards || [])
        .map(
          card => `<tr data-account="${esc(card.id)}" tabindex="0" class="${card.status === "passive" ? "is-passive" : ""}">
            ${td("Kart", `<b>${esc(card.name)}</b>${card.cardLast4 ? ` <span class="hof-plan-refno">•••• ${esc(card.cardLast4)}</span>` : ""}`)}
            ${td("Kod", esc(card.code))}
            ${td("Kart Limiti", card.creditLimitMinor ? esc(fmt(card.creditLimitMinor)) : "—", "num")}
            ${td("Borç", esc(fmt(card.debtMinor)), "num")}
            ${td("Son Ödeme Günü", card.dueDay ? esc(String(card.dueDay)) : "—")}
          </tr>`,
        )
        .join("");
      out.push(`<section class="hof-bank-linked" data-bank-cards>
        <div class="hof-bank-subhead"><h4 class="hof-bank-subtitle">Kredi Kartları</h4>${add}</div>
        ${rows ? `<div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table"><thead><tr><th>Kart</th><th>Kod</th><th class="num">Kart Limiti</th><th class="num">Borç</th><th>Son Ödeme Günü</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p class="hof-muted">Bu hesaba bağlı kredi kartı yok.</p>'}
        <p class="hof-rep-note">Kartın borcu bu hesaptan ödenir: Kart Borcu Ödemesi'nde ödeyen hesap olarak bu hesap gelir.</p>
      </section>`);
    }
    if (a.usePos) {
      const extra = [...accountSections.values()].map(fn => {
        try {
          return fn(a) || "";
        } catch {
          return "";
        }
      }).join("");
      out.push(extra || `<section class="hof-bank-linked" data-bank-pos-slot="${esc(a.id)}"><div class="hof-bank-subhead"><h4 class="hof-bank-subtitle">POS'lar</h4></div><p class="hof-muted">Bu hesaba bağlı POS yok.</p></section>`);
    }
    return out.join("");
  }

  // ---------- Hesabı Atanmamış Eski Hareketler (§10.3) ----------
  const rowKey = row => `${row.table}:${row.id}`;
  const bindableOf = list => (list?.accounts || []).filter(account => account.status === "active" && account.currency === "TRY" && BINDABLE_KINDS.has(account.kind));
  const bindableAccounts = () => bindableOf(view.list);
  const legacyTarget = () => bindableAccounts().find(account => account.id === view.legacyTarget) || bindableAccounts()[0] || null;
  // Seçilebilen satır: sunucunun "atanabilir" dediği (havale, açık dönem) ve seçili hesabın açılış gününde ya da sonrasında olan (öncesi
  // açılış bakiyesinin içindedir; sunucu 409 bank-before-opening verir).
  // Önbellekten çizilen liste (legacyStale) taze yanıt gelene kadar seçilemez (enterLegacy).
  const canPick = (row, target = legacyTarget()) => Boolean(!view.legacyStale && row.assignable && target && row.date >= target.openingDate);
  function legacyHtml() {
    const back = '<button type="button" class="hof-plan-back" data-act="back-overview">← Genel Bakış</button>';
    const data = view.legacy;
    if (!data) return `<div class="hof-bank-detail-head">${back}</div>${HOF.listPending(view.error)}`;
    const targets = bindableAccounts();
    const target = legacyTarget();
    const pickable = row => canPick(row, target);
    const assignable = data.rows.filter(pickable);
    const allOn = assignable.length && assignable.every(row => view.selected.has(rowKey(row)));
    const rows = data.rows
      .map(
        row => `<tr class="${row.kind === "in" ? "is-in" : "is-out"}">
          <td class="hof-bank-check">${pickable(row) && canAccounts() ? `<input type="checkbox" data-pick="${esc(rowKey(row))}" ${view.selected.has(rowKey(row)) ? "checked" : ""} aria-label="Seç">` : row.future && canAccounts() ? `<input type="checkbox" disabled data-pick-later aria-label="Seçilemez: ${esc(row.reason || "")}" title="${esc(row.reason || "")}">` : view.legacyStale && row.assignable && canAccounts() ? '<input type="checkbox" disabled data-pick-stale aria-label="Liste güncelleniyor; güncel liste gelince seçilebilir">' : ""}</td>
          ${td("Tarih", esc(dateText(row.date)))}
          ${td("Yol", row.way === "bank" ? "Havale / EFT" : "POS / Kart")}
          ${td("Cari / Açıklama", `${esc(row.partyName || "—")}${row.description ? `<small>${esc(row.description)}</small>` : ""}`)}
          ${td("İşlem No", row.eventNo ? `<span class="hof-plan-refno">${esc(row.eventNo)}</span>` : "—")}
          ${td("Tutar", `<b>${esc(signed(row.kind === "in" ? row.amountMinor : -row.amountMinor))}</b>`, "num")}
          ${td("Durum", row.future ? `<span class="hof-plan-badge is-muted" data-legacy-future>Tarihi Gelince Atanabilir</span><small class="hof-bank-why">${esc(row.reason || "")}</small>` : row.locked ? '<span class="hof-plan-badge is-muted">Kilitli Dönem — Atanamaz</span>' : row.closed ? `<span class="hof-plan-badge is-muted" title="${esc(row.reason || "")}">Devir Kapanışı'yla Kapandı</span>` : row.way !== "bank" ? '<span class="hof-plan-badge is-info">Bankaya Geçmiş Say</span>' : target && row.date < target.openingDate ? `<span class="hof-plan-badge is-muted" title="Hesabın açılışı ${esc(dateText(target.openingDate))}; bu hareket açılış bakiyesinin içindedir (Kurulum Sihirbazı'ndaki Devir Kapanışı'yla kapanır).">Açılıştan Önce</span>` : "")}
        </tr>`,
      )
      .join("");
    const runs = (view.runs || [])
      .map(
        run => `<tr>${td("Tarih", esc(dateText(run.date)))}${td("Hesap", esc(run.accountLabel || "—"))}${td("İşlem No", run.no ? `<span class="hof-plan-refno">${esc(run.no)}</span>` : "—")}${td("Aktarılan", esc(run.reclass ? `${run.reclass.mode === "card" ? "Kart Borcuna Aktar" : "Bankaya Geçmiş Say"} ${fmt(run.reclass.amountMinor)}` : `${run.assigned} hareket${run.carry && (run.carry.bankMinor || run.carry.cardMinor) ? ` · Devir Kapanışı ${fmt(run.carry.bankMinor + run.carry.cardMinor)}` : ""}`))}${td("Durum", run.status === "active" ? '<span class="hof-plan-badge is-done">Geçerli</span>' : '<span class="hof-plan-badge is-muted">Geri Alındı</span>')}<td class="hof-bank-actions-cell">${run.status === "active" && canAccounts() ? `<button type="button" class="hof-link-button" data-act="undo" data-run="${esc(run.id)}">Geri Al</button>` : ""}</td></tr>`,
      )
      .join("");
    const tools = canAccounts()
      ? `<div class="hof-bank-toolbar">
          ${targets.length ? `<label class="hof-bank-inline"><span>Hedef Hesap</span><select data-legacy-target>${targets.map(account => `<option value="${esc(account.id)}" ${account.id === target?.id ? "selected" : ""}>${esc(accountLabel(account))} (${esc(account.code)}) · açılış ${esc(dateText(account.openingDate))}</option>`).join("")}</select></label><button type="button" class="hof-button hof-button-small" data-act="assign" ${view.selected.size ? "" : 'disabled title="Önce listeden atanacak hareketleri seçin."'}>Seçilenleri Bu Hesaba Ata (${view.selected.size})</button>` : '<span class="hof-muted">Havale hareketleri etkin bir TL vadesiz, ticari ya da diğer hesaba atanır; önce hesap açın.</span>'}
          ${data.totals.cardMinor > 0 && targets.length ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="reclass-bank">Bankaya Geçmiş Say</button>' : ""}
          ${data.totals.cardMinor < 0 ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="reclass-card">Kart Borcuna Aktar</button>' : ""}
          <button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="wizard">Kurulum Sihirbazı</button>
        </div>`
      : "";
    return `<div class="hof-bank-detail-head">${back}<div class="hof-plan-title"><h3>Hesabı Atanmamış Eski Hareketler</h3><small>Banka hesabı tanımlanmadan girilmiş havale / EFT ve POS hareketleri. Gerçek Banka'ya girmez.</small></div></div>
      <div class="hof-rep-stats hof-bank-stats"><div class="hof-rep-stat"><span>Havale / EFT (102.00)</span><strong>${esc(fmt(data.totals.bankMinor))}</strong></div><div class="hof-rep-stat"><span>POS / Kart (108.00)</span><strong>${esc(fmt(data.totals.cardMinor))}</strong></div><div class="hof-rep-stat"><span>Kilitli Dönem — Atanamaz</span><strong>${data.lockedCount}</strong><small>${data.count} hareket</small></div>${data.future?.count ? `<div class="hof-rep-stat" data-legacy-future-stat><span>Tarihi Gelince Atanabilir</span><strong>${data.future.count}</strong><small>${esc(signed(data.future.totalMinor))} · ilk ${esc(dateText(data.future.firstDate))} · toplamlara girmez</small></div>` : ""}</div>
      ${tools}
      ${view.legacyStale && canAccounts() ? (view.error ? HOF.listPending(view.error) : '<p class="hof-rep-note" data-legacy-stale role="status">Liste güncelleniyor; hareketler güncel liste gelince seçilebilir.</p>') : ""}
      <div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-legacy"><thead><tr><th class="hof-bank-check">${canAccounts() && assignable.length ? `<input type="checkbox" data-pick-all ${allOn ? "checked" : ""} aria-label="Hepsini seç">` : ""}</th><th>Tarih</th><th>Yol</th><th>Cari / Açıklama</th><th>İşlem No</th><th class="num">Tutar</th><th>Durum</th></tr></thead><tbody>${rows || '<tr><td colspan="7" class="hof-empty">Hesabı atanmamış eski hareket yok.</td></tr>'}</tbody></table></div>
      <p class="hof-rep-note">Bir hareket yalnız hesabın açılış tarihinde ya da sonrasındaysa ve dönemi açıksa atanır; açılıştan önceki hareketler açılış bakiyesinin içindedir (Kurulum Sihirbazı'ndaki Devir Kapanışı'yla kapanır). Tarihi gelmemiş eski hareket (eski sürümde ileri tarihle girilmiş) o gün atanır; o güne kadar toplamlara girmez. POS ve kart bakiyesi Bankaya Geçmiş Say ya da Kart Borcuna Aktar ile taşınır.</p>
      ${runs ? `<h4 class="hof-bank-subtitle">Kurulum Geçmişi</h4><div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table"><thead><tr><th>Tarih</th><th>Hesap</th><th>İşlem No</th><th>Aktarılan</th><th>Durum</th><th></th></tr></thead><tbody>${runs}</tbody></table></div>` : ""}`;
  }

  // ---------- Ayarlar (§8.11; kullanıcı kararı: Temel ve Gelişmiş, standartlar seçili, Varsayılanlara Dön) ----------
  function settingControl(section, item, value, editable, chart) {
    const attrs = `data-set="${esc(section.id)}.${esc(item.key)}" data-type="${esc(item.type)}" id="hof-bank-set-${esc(section.id)}-${esc(item.key)}" ${editable ? "" : "disabled"}`;
    const option = (id, label, current) => `<option value="${esc(id)}" ${String(id) === String(current ?? "") ? "selected" : ""}>${esc(label)}</option>`;
    switch (item.type) {
      case "select":
        return `<select ${attrs}>${item.options.map(([id, label]) => option(id, label, value)).join("")}</select>`;
      case "bool":
        return `<select ${attrs}>${option("true", "Açık", String(Boolean(value)))}${option("false", "Kapalı", String(Boolean(value)))}</select>`;
      case "number":
        return `<input type="number" inputmode="numeric" step="1" min="${item.min}" max="${item.max}" ${item.nullable ? 'data-nullable="1" placeholder="Boş"' : ""} value="${value === null || value === undefined ? "" : esc(value)}" ${attrs}>`;
      case "text":
        return `<input type="text" maxlength="6" value="${esc(value ?? "")}" placeholder="${esc(item.hint || "")}" ${attrs}>`;
      case "account": {
        const accounts = (view.choices?.accounts || []).filter(account => view.choices.forms.bank.ids.includes(account.id));
        return `<select ${attrs}>${option("", "İlk Açılan TL Vadesiz Hesap", value)}${accounts.map(account => option(account.id, `${account.label} (${account.code})`, value)).join("")}</select>`;
      }
      // 2.2.0 (İz 3.4): Varsayılan POS — etkin POS'lar (seçici listesinden; boşsa ilk tanımlanan POS).
      case "pos":
        return `<select ${attrs}>${option("", "İlk Tanımlanan POS", value)}${(view.choices?.pos || []).map(item => option(item.id, `${item.name} (${item.code})`, value)).join("")}</select>`;
      case "gl":
        return `<select ${attrs}>${item.allowed.map(code => option(code, `${code} · ${chart[code] || ""}`, value)).join("")}</select>`;
      case "fixed":
        return `<span class="hof-bank-fixed">${esc(section.id === "gl" ? `${item.value} · ${chart[item.value] || ""}` : item.text)}</span>`;
      case "feeTypes":
        return `<div class="hof-bank-fees" ${attrs}>${(value || []).map(fee => feeRow(fee, editable)).join("")}${editable ? '<button type="button" class="hof-link-button" data-act="fee-add">+ Tür Ekle</button>' : ""}</div>`;
      case "keywords":
        return `<div class="hof-bank-keywords" ${attrs}>${KEYWORD_GROUPS.map(([group, label]) => `<label><span>${esc(label)}</span><input type="text" data-kw="${group}" value="${esc((value?.[group] || []).join(", "))}" ${editable ? "" : "disabled"}></label>`).join("")}</div>`;
      default:
        return "";
    }
  }
  // Masraf türünün hesabı (§8.11): 770 Banka Masrafları, 653 POS ve Ödeme Kuruluşu Komisyonları (vergi kipinden bağımsız).
  const FEE_GL = [
    ["770", "Masraf (770)"],
    ["653", "Komisyon (653)"],
  ];
  const feeRow = (fee, editable) =>
    `<div class="hof-bank-fee" data-fee data-key="${esc(fee.key || "")}"><input type="text" data-fee-name value="${esc(fee.name)}" maxlength="60" aria-label="Masraf türü" ${editable ? "" : "disabled"}><select data-fee-gl aria-label="Hesap" ${editable ? "" : "disabled"}>${FEE_GL.map(([code, label]) => `<option value="${code}" ${fee.gl === code ? "selected" : ""}>${esc(label)}</option>`).join("")}</select>${editable ? '<button type="button" class="hof-mini hof-mini-danger" data-act="fee-remove" title="Türü kaldır" aria-label="Türü kaldır">×</button>' : ""}</div>`;
  function sectionHtml(section, values, editable, chart) {
    const items = section.items.filter(item => item.available !== false);
    if (!items.length) return "";
    const resettable = editable && items.some(item => item.type !== "fixed");
    return `<fieldset class="hof-bank-set" data-section="${esc(section.id)}"><legend>${esc(section.label)}</legend>
      ${resettable ? `<button type="button" class="hof-link-button hof-bank-set-reset" data-act="reset-section" data-section="${esc(section.id)}">Varsayılanlara Dön</button>` : ""}
      ${items
        .map(
          item => `<div class="hof-bank-set-item"><label for="hof-bank-set-${esc(section.id)}-${esc(item.key)}">${esc(item.label)}</label>${settingControl(section, item, item.type === "fixed" ? item.value : values?.[section.id]?.[item.key], editable, chart)}${item.help ? `<small>${esc(item.help)}</small>` : ""}</div>`,
        )
        .join("")}
    </fieldset>`;
  }
  function settingsHtml() {
    const data = view.settings;
    if (!data) return HOF.listPending(view.error);
    const editable = HOF.can("bank.settings");
    const chart = data.chart || {};
    const shown = level => data.sections.filter(section => section.level === level && section.available !== false);
    return `<p class="hof-modal-text">Standartlar seçili gelir; çoğu ofisin bir şeyi değiştirmesi gerekmez. Ayarlar yalnız bundan sonraki kayıtlara uygulanır.</p>
      ${editable ? "" : `<p class="hof-bank-confirm is-warn">${esc(HOF.license?.writable === false ? READ_ONLY_TEXT : "Banka ayarlarını yalnız Banka Ayarları yetkisi olanlar değiştirir.")}</p>`}
      <form class="hof-bank-settings" data-settings novalidate>
        <h4 class="hof-bank-subtitle">Temel Ayarlar</h4>
        <div class="hof-bank-sets">${shown("basic").map(section => sectionHtml(section, data.values, editable, chart)).join("")}</div>
        <button type="button" class="hof-button hof-button-small hof-button-ghost hof-bank-advanced-toggle" data-act="advanced" aria-expanded="${view.advanced}">${view.advanced ? "Gelişmiş Ayarları Gizle" : "Gelişmiş Ayarları Göster"}</button>
        <div class="hof-bank-sets" data-advanced ${view.advanced ? "" : "hidden"}><p class="hof-rep-note">Gelişmiş ayarlar profesyonel kullanım içindir; değiştirmeden önce mali müşavirinize danışın.</p>${shown("advanced").map(section => sectionHtml(section, data.values, editable, chart)).join("")}</div>
        <p class="hof-form-error" role="alert"></p>
        ${editable ? `<div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-act="reset-all">Tümünü Varsayılanlara Dön</button><button type="submit" class="hof-button" data-act="save-settings">Ayarları Kaydet</button></div>${view.dirty ? '<p class="hof-bank-dirty">Kaydedilmemiş değişiklik var.</p>' : ""}` : ""}
      </form>`;
  }
  /** Ekrandaki ayar değerleri: { bölüm: { anahtar: değer } } (yalnız görünen ve değiştirilebilen kalemler). */
  function collectSettings(form) {
    const values = {};
    for (const node of form.querySelectorAll("[data-set]")) {
      const [section, key] = node.dataset.set.split(".");
      let value;
      switch (node.dataset.type) {
        case "fixed":
          continue;
        case "bool":
          value = node.value === "true";
          break;
        case "number":
          value = node.value.trim() === "" ? (node.dataset.nullable ? null : "") : Number(node.value);
          break;
        case "feeTypes":
          value = [...node.querySelectorAll("[data-fee]")].map(row => ({ key: row.dataset.key || "", name: row.querySelector("[data-fee-name]").value.trim(), gl: row.querySelector("[data-fee-gl]").value })).filter(fee => fee.name || fee.key);
          break;
        case "keywords":
          value = Object.fromEntries(KEYWORD_GROUPS.map(([group]) => [group, node.querySelector(`[data-kw="${group}"]`).value.split(",").map(word => word.trim()).filter(Boolean)]));
          break;
        default:
          value = node.value;
      }
      (values[section] ||= {})[key] = value;
    }
    return values;
  }
  async function saveSettings(form) {
    const error = form.querySelector(".hof-form-error");
    error.textContent = "";
    form.querySelectorAll(".is-invalid").forEach(node => node.classList.remove("is-invalid"));
    const button = form.querySelector('[data-act="save-settings"]');
    button.disabled = true;
    try {
      view.settings = await api("/settings", { method: "PUT", body: { values: collectSettings(form) } });
      view.dirty = false;
      render();
      HOF.toast("Banka ayarları kaydedildi.", { type: "success" });
    } catch (failure) {
      error.textContent = failure.message;
      const field = failure.data?.field;
      const node = field ? form.querySelector(`[data-set="${CSS.escape(field)}"]`) : null;
      if (node) {
        node.classList.add("is-invalid");
        node.closest(".hof-bank-set")?.closest("[data-advanced]")?.removeAttribute("hidden");
        node.focus?.();
      }
    } finally {
      if (button.isConnected) button.disabled = false;
    }
  }
  async function resetSettings(section = "") {
    const all = !section;
    if (all || view.dirty) {
      const go = await HOF.confirm({ title: all ? "Tümünü Varsayılanlara Dön" : "Varsayılanlara Dön", message: `${all ? "Bütün banka ayarları standart değerlerine döner." : "Bu bölüm standart değerlerine döner."}${view.dirty ? " Kaydedilmemiş değişiklikler kaybolur." : ""} Değişiklik işlem geçmişine yazılır.`, confirmLabel: "Varsayılanlara Dön" });
      if (!go) return;
    }
    try {
      view.settings = await api("/settings/reset", { method: "POST", body: all ? {} : { section } });
      view.dirty = false;
      render();
      HOF.toast(all ? "Bütün banka ayarları varsayılana döndü." : "Bölüm varsayılana döndü.", { type: "success" });
    } catch (error) {
      HOF.toastError(error);
    }
  }

  // ---------- Hesap formu (aç / düzelt) ----------
  function accountFields(account = null, { preset = {} } = {}) {
    const edit = Boolean(account);
    const kind = account?.kind || "demand";
    const locked = edit && (account.movementCount > 0 || Boolean(account.opening?.amountMinor));
    // v2.2.0 (İz 2.3): kurumsal kart bu formda açılmaz — yalnız banka hesabının içinden ("+ Kredi Kartı Ekle", cardForm). Tür listesinde yok.
    const kindOptions = KINDS.filter(([id]) => id !== "fx" && id !== "card").map(([value, label]) => ({ value, label }));
    const fields = [
      { name: "bankName", label: "Banka Adı", required: true, autofocus: true, value: account?.bankName || "", maxlength: 120, list: BANK_NAMES, placeholder: "ör. Ziraat Bankası" },
      { name: "name", label: "Hesap Adı", required: true, value: account?.name || "", maxlength: 120, placeholder: "ör. Ana TL Hesabı" },
      { name: "kind", label: "Hesap Türü", type: "select", value: kind === "fx" ? "demand" : kind, options: kindOptions, readonly: locked, help: locked ? "Hareketi ya da açılış bakiyesi olan hesabın türü ve para birimi değişmez; gerekirse yeni hesap açın." : fxOn() ? "Döviz hesabı için Vadesiz seçip para birimini değiştirin." : "Kredi kartı burada açılmaz: hesap açıldıktan sonra hesabın ayrıntısında “+ Kredi Kartı Ekle”." },
      // GG2 (kullanıcı kararı "Ertelenenler 2.1.0'da GÖRÜNMEZ"): döviz hesabı sonraki sürümde; alan yalnız döviz açıkken (testler) ya da var olan
      // döviz hesabında (salt okunur) görünür.
      ...(fxOn() || (account && account.currency !== "TRY") ? [{ name: "currency", label: "Para Birimi", type: "select", value: account?.currency || "TRY", options: CURRENCIES.map(([value, label]) => ({ value, label })), readonly: locked || !fxOn() }] : []),
      { name: "code", label: "Hesap Kodu", value: account?.code || "", maxlength: 30, placeholder: "Boş bırakılırsa önerilir (ör. ZIR-TL)" },
      { name: "iban", label: "IBAN", value: account?.ibanText || "", maxlength: 40, placeholder: "TR00 0000 0000 0000 0000 0000 00", autocomplete: "off" },
      { name: "branchName", label: "Şube", value: account?.branchName || "", maxlength: 120 },
      { name: "branchCode", label: "Şube Kodu", value: account?.branchCode || "", maxlength: 20 },
      { name: "accountNo", label: "Hesap No", value: account?.accountNo || "", maxlength: 40 },
      { name: "creditLimit", label: limitLabel(kind), value: amountInput(account?.creditLimitMinor), inputmode: "decimal", placeholder: "ör. 50.000,00" },
      { name: "negativePolicy", label: "Eksi Bakiye Denetimi", type: "select", value: account?.negativePolicy || "", options: [{ value: "", label: "Banka Ayarlarındaki" }, ...Object.entries(POLICY_LABELS).map(([value, label]) => ({ value, label }))], help: "Açılış bakiyesi doğrulanana kadar denetim kapalıdır." },
      { name: "showOnInvoice", label: "IBAN faturada gösterilsin", type: "checkbox", value: Boolean(account?.showOnInvoice) },
      // v2.2.0 (İz 2.2): kullanım işaretleri (yalnız Vadesiz, Ticari, Diğer TL hesapta görünür; eski hesaplarda kapalı).
      ...FLAG_FIELDS.map(([name, label]) => ({ name, label, type: "checkbox", value: account ? Boolean(account[name]) : Boolean(preset[name]) })),
      { name: "description", label: "Açıklama", value: account?.description || "", maxlength: 500 },
    ];
    if (edit) fields.push({ name: "balanceConfirmed", label: "Açılış bakiyesi bankadaki gerçek bakiyedir (Bakiye Doğrulandı)", type: "checkbox", value: Boolean(account.balanceConfirmed) });
    else fields.push(...openingFields());
    return fields;
  }
  const openingFields = (account = null) => [
    { name: "openingDate", label: "Açılış Tarihi", type: "date", required: true, max: "today", value: account?.opening?.date || account?.openingDate || HOF.localToday(), help: "Bu günün başındaki banka bakiyesi; o günden önceki hareketler bakiyenin içindedir." },
    { name: "openingAmount", label: openingLabel(account?.kind), value: account?.opening ? amountInput(account.opening.amountMinor) : "", inputmode: "decimal", placeholder: "ör. 100.000,00 (boş: 0)" },
    { name: "openingRate", label: "Açılış Kuru (TL)", value: "", inputmode: "decimal", placeholder: "ör. 34,25", help: "Döviz hesabında açılış bakiyesinin TL karşılığı için." },
    { name: "confirmed", label: "Bu tutar bankadaki gerçek bakiyedir (Bakiye Doğrulandı)", type: "checkbox", value: Boolean(account?.balanceConfirmed) },
  ];
  /** Türe ve para birimine göre ilgili alanları gösterir (KMH vadesizde, işaretler havale alan hesapta, kur dövizde). */
  function wireKindFields(form) {
    const field = name => form.querySelector(`[name="${name}"]`);
    const show = (name, visible) => {
      const node = field(name)?.closest(".hof-field, .hof-check");
      if (node) node.hidden = !visible;
    };
    const sync = () => {
      const kind = field("kind")?.value || "demand";
      const currency = field("currency");
      if (currency && ["loan", "card", "time"].includes(kind) && currency.value !== "TRY" && !currency.hasAttribute("readonly")) currency.value = "TRY";
      if (currency) for (const option of currency.options) option.disabled = ["loan", "card", "time"].includes(kind) && option.value !== "TRY";
      const tl = (currency?.value || "TRY") === "TRY";
      show("creditLimit", ["demand", "card", "loan"].includes(kind) && tl);
      const limit = field("creditLimit")?.closest(".hof-field")?.querySelector("span");
      if (limit) limit.textContent = limitLabel(kind);
      // İşaretler yalnız havale alan TL hesapta (sunucu başka türde 400 bank-flag-kind); gizlenen işaret gönderilmez (işaretsiz sayılır).
      for (const [name] of FLAG_FIELDS) {
        const on = BINDABLE_KINDS.has(kind) && tl;
        show(name, on);
        if (!on && field(name)) field(name).checked = false;
      }
      show("openingRate", Boolean(currency) && currency.value !== "TRY");
      const amount = field("openingAmount")?.closest(".hof-field")?.querySelector("span");
      if (amount) amount.textContent = openingLabel(kind);
    };
    form.addEventListener("change", event => {
      if (event.target.matches?.('[name="kind"], [name="currency"]')) sync();
    });
    // Salt okunur açılır liste: tarayıcı readonly'yi seçimde uygulamaz; değer değişmesin.
    for (const select of form.querySelectorAll("select[readonly]")) {
      const value = select.value;
      select.addEventListener("change", () => (select.value = value));
    }
    const iban = field("iban");
    iban?.addEventListener("blur", () => {
      const clean = iban.value.replace(/\s+/g, "").toLocaleUpperCase("tr-TR");
      iban.value = clean ? clean.replace(/(.{4})/g, "$1 ").trim() : "";
    });
    sync();
  }
  /** Sunucu hatasını ilgili alanın yanında gösterir (formun hata satırı ayrıca dolar). */
  function markField(form, error) {
    form.querySelectorAll(".is-invalid").forEach(node => {
      node.classList.remove("is-invalid");
      node.removeAttribute("aria-invalid");
    });
    const name = FIELD_OF[error?.data?.field] || FIELD_OF_CODE[error?.data?.code] || "";
    const node = name ? form.querySelector(`[name="${name}"]`) : null;
    if (!node) return;
    node.classList.add("is-invalid");
    node.setAttribute("aria-invalid", "true");
    node.closest(".hof-field")?.removeAttribute("hidden");
    node.focus();
  }
  const flagsBody = data => Object.fromEntries(FLAG_FIELDS.map(([name]) => [name, Boolean(data[name])]));
  /** Hesap açma gövdesi (formdan; açılış dahil). */
  function createBody(data) {
    const body = {
      bankName: data.bankName,
      name: data.name,
      kind: data.kind,
      currency: data.currency,
      code: data.code,
      iban: data.iban,
      branchName: data.branchName,
      branchCode: data.branchCode,
      accountNo: data.accountNo,
      description: data.description,
      negativePolicy: data.negativePolicy,
      showOnInvoice: Boolean(data.showOnInvoice),
      ...(BINDABLE_KINDS.has(data.kind) ? flagsBody(data) : {}),
      opening: { date: data.openingDate, amount: String(data.openingAmount ?? "").trim() || "0", confirmed: Boolean(data.confirmed) },
    };
    const currency = data.currency || "TRY";
    body.currency = currency;
    if (currency !== "TRY" && String(data.openingAmount || "").trim()) body.opening.rate = data.openingRate;
    if (["demand", "loan"].includes(data.kind) && currency === "TRY") body.creditLimit = data.creditLimit;
    return body;
  }
  /**
   * Banka hesabı formu (aç / düzelt). Kart hesabı Kredi Kartı formunda (cardForm). v2.2.0 (İz 2.4): "Banka Hesabı Tanımla" / "Çek Hesabı Tanımla"
   * bu formu ÜSTE açar (alttaki form kapanmaz): inline (Banka penceresi dışında) kaydedince sayfa değişmez, söz kaydedilen hesapla çözülür;
   * Vazgeç'te null. preset: işaretlerin ön değeri (Çek Hesabı Tanımla → Çek Kullan işaretli).
   */
  function accountForm(account = null, { inline = false, preset = {} } = {}) {
    if (account?.kind === "card") return cardForm({ card: account });
    if (!canAccounts()) {
      HOF.toast("Banka hesabı açma ve düzeltme Banka Hesabı Tanımlama yetkisi ister.", { type: "error" });
      return Promise.resolve(null);
    }
    const edit = Boolean(account);
    const requestId = HOF.requestId();
    let formNode = null;
    let saved = null;
    return new Promise(resolve => {
      HOF.formModal({
        title: edit ? "Banka Hesabını Düzenle" : inline ? "Banka Hesabı Tanımla" : "Yeni Banka Hesabı",
        eyebrow: moduleName().toLocaleUpperCase("tr-TR"),
        size: "wide",
        intro: edit ? "Banka, ad, kod, IBAN ve şube bilgileri her zaman düzeltilir. Açılış bakiyesini hesap ayrıntısındaki “Açılışı Düzelt” ile değiştirin." : `Açılış bakiyesi, açılış tarihinin gün başındaki bakiyedir. Bakiyeyi bankadan teyit ettiyseniz “Bakiye Doğrulandı”yı işaretleyin; eksi bakiye denetimi o zaman açılır.${inline ? " Kaydedince hesap, açık formunuzda seçili gelir; girdiğiniz bilgiler kaybolmaz." : ""}`,
        fields: accountFields(account, { preset }),
        submitLabel: edit ? "Kaydet" : "Hesabı Aç",
        onClose: () => resolve(saved),
        onOpen: dialog => {
          formNode = dialog.querySelector("form");
          formNode.classList.add("hof-bank-form");
          wireKindFields(formNode);
        },
        onSubmit: async data => {
          try {
            if (edit) {
              const body = { bankName: data.bankName, name: data.name, code: data.code, iban: data.iban, branchName: data.branchName, branchCode: data.branchCode, accountNo: data.accountNo, description: data.description, negativePolicy: data.negativePolicy, showOnInvoice: Boolean(data.showOnInvoice), balanceConfirmed: Boolean(data.balanceConfirmed) };
              const currency = data.currency || account.currency || "TRY";
              if (!(account.movementCount > 0 || account.opening?.amountMinor)) Object.assign(body, { kind: data.kind, ...(data.currency ? { currency: data.currency } : {}) });
              if (["demand", "loan"].includes(data.kind) && currency === "TRY") body.creditLimit = data.creditLimit;
              if (BINDABLE_KINDS.has(data.kind)) Object.assign(body, flagsBody(data));
              saved = await api(`/accounts/${encodeURIComponent(account.id)}`, { method: "PUT", body });
              choicesCache = null;
              HOF.toast("Banka hesabı güncellendi.", { type: "success" });
              await reload();
            } else {
              const result = await api("/accounts", { method: "POST", body: createBody(data), requestId });
              saved = result?.replayed ? result.account : result;
              HOF.toast(result?.replayed ? "Bu hesap zaten açılmıştı." : `${result.label || "Banka hesabı"} açıldı (${result.code} · ${result.glSub}).`, { type: "success" });
              choicesCache = null;
              HOF.emit("bank-changed");
              if (inline || !modal) return;
              if (saved?.id) openAccount(saved.id);
              else await reload();
            }
          } catch (error) {
            markField(formNode, error);
            throw error;
          }
        },
      });
    });
  }
  /**
   * v2.2.0 (İz 2.3; müşteri: "kredi kartlarını bankaya bağlamak gerekiyor"): Kredi Kartı formu. Kart bankanın İÇİNDEN eklenir: Bağlı Banka
   * Hesabı (kartın borcunu ödeyen hesap; banka adı ondan), Kart Adı, Son 4 Hane, Kart Limiti, Hesap Kesim ve Son Ödeme Günü, açılıştaki borç.
   * Her banka, bir bankada birden çok kart. Düzenle'de bağlı banka değiştirilir (eski bağsız kart "Bağlı Değil" kalabilir; öneri yazılır).
   * parentId: ön seçili banka; inline: Tanımla'dan (sayfa değişmez). Hiç banka hesabı yoksa "Banka Hesabı Tanımla" önce o hesabı açar.
   * Dönüş: söz (kaydedilen kart ya da null).
   */
  function cardForm({ card = null, parentId = "", inline = false } = {}) {
    if (!canAccounts()) {
      HOF.toast("Kredi kartı tanımlama Banka Hesabı Tanımlama yetkisi ister.", { type: "error" });
      return Promise.resolve(null);
    }
    const edit = Boolean(card);
    const requestId = HOF.requestId();
    let formNode = null;
    let saved = null;
    const bankOptions = data => (data?.forms?.bank?.ids || []).map(id => data.accounts.find(account => account.id === id)).filter(Boolean);
    const optionsHtml = (list, value) => `${edit && !card.parentId ? `<option value="">Bağlı Değil</option>` : list.length > 1 || !list.length ? `<option value="">Banka Hesabı Seçin</option>` : ""}${list.map(account => `<option value="${esc(account.id)}" ${account.id === value ? "selected" : ""}>${esc(`${account.label} (${account.code})`)}</option>`).join("")}`;
    const fields = [
      { name: "parentId", label: "Bağlı Banka Hesabı", type: "select", required: !edit || Boolean(card?.parentId), value: card?.parentId || parentId, options: [] },
      { name: "name", label: "Kart Adı", required: true, autofocus: true, value: card?.name || "", maxlength: 120, placeholder: "ör. World, Bonus, Axess" },
      { name: "cardLast4", label: "Son 4 Hane", value: card?.cardLast4 || "", maxlength: 4, inputmode: "numeric", placeholder: "ör. 1234", autocomplete: "off" },
      { name: "creditLimit", label: "Kart Limiti", value: amountInput(card?.creditLimitMinor), inputmode: "decimal", placeholder: "ör. 50.000,00" },
      { name: "statementDay", label: "Hesap Kesim Günü", type: "number", min: 1, max: 31, value: card?.statementDay || "" },
      { name: "dueDay", label: "Son Ödeme Günü", type: "number", min: 1, max: 31, value: card?.dueDay || "" },
      { name: "code", label: "Hesap Kodu", value: card?.code || "", maxlength: 30, placeholder: "Boş bırakılırsa önerilir (ör. YAP-KART)" },
      { name: "negativePolicy", label: "Eksi Bakiye Denetimi", type: "select", value: card?.negativePolicy || "", options: [{ value: "", label: "Banka Ayarlarındaki" }, ...Object.entries(POLICY_LABELS).map(([value, label]) => ({ value, label }))], help: "Kart limitine kadar serbest; açılış doğrulanana kadar denetim kapalıdır." },
      { name: "description", label: "Açıklama", value: card?.description || "", maxlength: 500 },
      ...(edit
        ? [{ name: "balanceConfirmed", label: "Açılış bakiyesi bankadaki gerçek bakiyedir (Bakiye Doğrulandı)", type: "checkbox", value: Boolean(card.balanceConfirmed) }]
        : openingFields({ kind: "card" })
            .filter(field => field.name !== "openingRate")
            .map(field => (field.name === "openingDate" ? { ...field, help: "Bu günün başındaki kart borcu; o günden önceki harcamalar borcun içindedir." } : field.name === "openingAmount" ? { ...field, placeholder: "ör. 12.500,00 (boş: 0)" } : field))),
    ];
    return new Promise(resolve => {
      HOF.formModal({
        title: edit ? "Kredi Kartını Düzenle" : inline ? "Kredi Kartı Tanımla" : "Kredi Kartı Ekle",
        eyebrow: moduleName().toLocaleUpperCase("tr-TR"),
        size: "wide",
        intro: edit
          ? "Kartın adı, son 4 hanesi, limiti ve günleri her zaman düzeltilir. Bağlı banka hesabı değişirse kartın banka adı da o hesaptan gelir; kartın bakiyesi değişmez."
          : `Kart, borcunu ödeyen banka hesabının altına eklenir; kart numarasının yalnız son 4 hanesi yazılır. Açılıştaki borç, açılış gününün başındaki kart borcudur.${inline ? " Kaydedince kart, açık formunuzda seçili gelir; girdiğiniz bilgiler kaybolmaz." : ""}`,
        fields,
        extraHtml: '<div class="hof-bank-define-slot" data-card-parent-empty hidden></div>',
        submitLabel: edit ? "Kaydet" : "Kartı Ekle",
        onClose: () => resolve(saved),
        onOpen: async dialog => {
          formNode = dialog.querySelector("form");
          formNode.classList.add("hof-bank-form");
          const select = formNode.querySelector('[name="parentId"]');
          const empty = formNode.querySelector("[data-card-parent-empty]");
          const fill = data => {
            const list = bankOptions(data);
            const keep = select.value || card?.parentId || parentId;
            const current = edit && card.parentId && !list.some(account => account.id === card.parentId) ? [{ id: card.parentId, label: card.parentLabel || card.parentId, code: card.parentCode || "" }] : [];
            const all = [...current, ...list];
            const value = all.some(account => account.id === keep) ? keep : all.length === 1 && !edit ? all[0].id : "";
            select.innerHTML = optionsHtml(all, value);
            select.value = value;
            // Hiç banka hesabı yoksa: önce kartın bağlı olacağı banka hesabı tanımlanır (üste açılır; kart formu kapanmaz).
            empty.hidden = all.length > 0;
            empty.innerHTML = all.length ? "" : `<p class="hof-rep-note">Kartın bağlı olacağı banka hesabı yok. Önce banka hesabını tanımlayın; kaydedince burada seçili gelir.</p><button type="button" class="hof-button hof-button-small" data-card-define-bank>Banka Hesabı Tanımla</button>`;
            if (edit && !card.parentId && card.parentSuggestions?.length) {
              const note = formNode.querySelector("[data-card-suggest-note]") || HOF.el("small", { class: "hof-bank-suggest", "data-card-suggest-note": "" });
              note.textContent = `Öneri: ${card.parentSuggestions[0].label} (aynı banka). Seçerseniz kart o hesabın altına bağlanır.`;
              select.closest(".hof-field")?.append(note);
            }
          };
          formNode.addEventListener("click", async event => {
            if (!event.target.closest("[data-card-define-bank]")) return;
            event.preventDefault();
            const bankAccount = await accountForm(null, { inline: true, preset: { useCard: true } });
            if (!formNode.isConnected) return;
            fill(await choices(true).catch(() => null));
            if (bankAccount?.id && [...select.options].some(option => option.value === bankAccount.id)) select.value = bankAccount.id;
            select.focus();
          });
          try {
            fill(await choices(true));
          } catch {
            fill(null);
          }
        },
        onSubmit: async data => {
          try {
            if (edit) {
              const body = { name: data.name, cardLast4: data.cardLast4, creditLimit: data.creditLimit, statementDay: data.statementDay, dueDay: data.dueDay, code: data.code, negativePolicy: data.negativePolicy, description: data.description, balanceConfirmed: Boolean(data.balanceConfirmed) };
              if ((data.parentId || "") !== (card.parentId || "")) body.parentId = data.parentId || "";
              saved = await api(`/accounts/${encodeURIComponent(card.id)}`, { method: "PUT", body });
              choicesCache = null;
              HOF.toast("Kredi kartı güncellendi.", { type: "success" });
              await reload();
            } else {
              const body = { kind: "card", parentId: data.parentId, name: data.name, cardLast4: data.cardLast4, creditLimit: data.creditLimit, statementDay: data.statementDay, dueDay: data.dueDay, code: data.code, negativePolicy: data.negativePolicy, description: data.description, opening: { date: data.openingDate, amount: String(data.openingAmount ?? "").trim() || "0", confirmed: Boolean(data.confirmed) } };
              const result = await api("/accounts", { method: "POST", body, requestId });
              saved = result?.replayed ? result.account : result;
              HOF.toast(result?.replayed ? "Bu kart zaten eklenmişti." : `${result.label || "Kredi kartı"} eklendi (${result.code}).`, { type: "success" });
              choicesCache = null;
              HOF.emit("bank-changed");
              if (inline || !modal) return;
              await reload();
            }
          } catch (error) {
            markField(formNode, error);
            throw error;
          }
        },
      });
    });
  }
  /** Eski (bağsız) kartı önerilen banka hesabına bağlar (kendiliğinden bağlanmaz; kullanıcı "Bağla" der). */
  async function linkCard(cardId, parentId) {
    const card = view.list?.accounts?.find(item => item.id === cardId) || (view.account?.id === cardId ? view.account : null);
    const parent = view.list?.accounts?.find(item => item.id === parentId);
    const go = await HOF.confirm({ title: "Kartı Bankasına Bağla", message: `${card ? accountLabel(card) : "Kart"} ${parent ? accountLabel(parent) : "seçilen"} hesabının altına bağlansın mı? Kartın bakiyesi ve hareketleri değişmez; Kart Borcu Ödemesi'nde ödeyen hesap olarak bu hesap gelir.`, confirmLabel: "Bağla" });
    if (!go) return;
    try {
      await api(`/accounts/${encodeURIComponent(cardId)}`, { method: "PUT", body: { parentId } });
      choicesCache = null;
      HOF.toast("Kart bankasına bağlandı.", { type: "success" });
      await reload();
    } catch (error) {
      HOF.toastError(error);
    }
  }
  function openingForm(account) {
    const correct = Boolean(account.opening?.hasLines);
    let formNode = null;
    HOF.formModal({
      title: correct ? "Açılışı Düzelt" : "Açılış Bakiyesi Gir",
      eyebrow: accountLabel(account).toLocaleUpperCase("tr-TR"),
      intro: correct ? `Eski açılış (${account.opening.no}) ters kaydedilir ve yenisi yazılır; ikisi de işlem geçmişinde kalır. Yeni tarih hesabın ilk hareketinden sonra olamaz.` : "Açılış tarihinin gün başındaki banka bakiyesini girin.",
      fields: openingFields(account).map(field => (field.name === "openingRate" ? { ...field, help: account.currency === "TRY" ? "" : field.help } : field)),
      submitLabel: correct ? "Açılışı Düzelt" : "Açılışı Kaydet",
      onOpen: dialog => {
        formNode = dialog.querySelector("form");
        const rate = formNode.querySelector('[name="openingRate"]')?.closest(".hof-field");
        if (rate) rate.hidden = account.currency === "TRY";
      },
      onSubmit: async data => {
        try {
          const body = { date: data.openingDate, amount: String(data.openingAmount ?? "").trim() || "0", confirmed: Boolean(data.confirmed) };
          if (account.currency !== "TRY") body.rate = data.openingRate;
          const result = await api(`/accounts/${encodeURIComponent(account.id)}/opening`, { method: "POST", body });
          HOF.toast(result.reversed ? `Açılış düzeltildi; eski açılış ${result.reversed} ters kaydedildi.` : "Açılış kaydedildi.", { type: "success" });
          await reload();
        } catch (error) {
          markField(formNode, error);
          throw error;
        }
      },
    });
  }
  async function toggleStatus(account) {
    const passive = account.status === "active";
    if (passive) {
      const go = await HOF.confirm({ title: "Hesabı Pasife Al", message: `${accountLabel(account)} formlardaki hesap seçiminden kalkar; geçmiş hareketleri ve bakiyesi kalır. Sonra yeniden etkinleştirebilirsiniz.`, confirmLabel: "Pasife Al" });
      if (!go) return;
    }
    try {
      await api(`/accounts/${encodeURIComponent(account.id)}/status`, { method: "POST", body: { status: passive ? "passive" : "active" } });
      choicesCache = null;
      HOF.toast(passive ? "Hesap pasife alındı." : "Hesap etkinleştirildi.", { type: "success" });
      await reload();
    } catch (error) {
      HOF.toastError(error);
    }
  }
  async function removeAccount(account) {
    const go = await HOF.confirm({ title: "Banka Hesabını Sil", message: `${accountLabel(account)} (${account.code}) silinsin mi?${account.opening?.amountMinor ? " Açılış bakiyesi ters kaydedilir." : ""} Aynı adla yeniden açabilirsiniz; alt hesap kodu (${account.glSub}) yeniden verilmez.`, confirmLabel: "Sil", danger: true });
    if (!go) return;
    try {
      await api(`/accounts/${encodeURIComponent(account.id)}`, { method: "DELETE" });
      choicesCache = null;
      HOF.toast("Banka hesabı silindi.", { type: "success" });
      setTab("accounts");
    } catch (error) {
      HOF.toastError(error);
    }
  }

  // ---------- Eski hareket araçları ----------
  async function assignSelected() {
    const target = root()?.querySelector("[data-legacy-target]")?.value;
    const rows = [...view.selected].map(key => {
      const [table, ...rest] = key.split(":");
      return { table, id: rest.join(":") };
    });
    if (!target || !rows.length) return;
    const account = (view.list?.accounts || []).find(item => item.id === target);
    const go = await HOF.confirm({ title: "Hesaba Ata", message: `${rows.length} hareket ${account ? accountLabel(account) : "seçilen hesap"} hesabına bağlanacak ve Gerçek Banka'ya girecek. Bu atama Kurulum Geçmişi'nde görünmez ve geri alınmaz. Devam edilsin mi?`, confirmLabel: "Hesaba Ata" });
    if (!go) return;
    try {
      const requestId = HOF.requestId();
      const result = await withConfirms(flags => api("/legacy/assign", { method: "POST", body: { accountId: target, rows, ...flags }, requestId }));
      view.selected = new Set();
      HOF.toast(`${result.assigned ?? rows.length} hareket hesaba atandı.`, { type: "success" });
      await reload();
    } catch (error) {
      HOF.toastError(error);
    }
  }
  // CI 460 (10.10.2026): form açılıp açılmayacağı ve önerilen tutar tıklama anında SUNUCUDAN okunur. Eski Hareketler'e dönüşte ekran önce
  // önceki ziyaretin verisiyle çizilir ve yenileme gelene kadar (yavaş sunucuda saniyeler) düğme o veriyle durur; başka yerden açılıştan sonra
  // girilmiş POS varken eski önbellekle "bankaya geçmemiş POS tahsilatı yok" deniyordu. Çift tıklama tek istek, tek form.
  let reclassBusy = false;
  async function reclassForm(mode) {
    if (reclassBusy) return;
    reclassBusy = true;
    let legacy;
    let list;
    try {
      [legacy, list] = await Promise.all([api("/legacy"), api("/accounts?status=all")]);
    } catch (error) {
      return HOF.toastError(error);
    } finally {
      reclassBusy = false;
    }
    if (!modal) return;
    const accounts = mode === "bank" ? bindableOf(list) : (list?.accounts || []).filter(account => account.kind === "card" && account.status === "active");
    if (!accounts.length) return HOF.toast(mode === "bank" ? "Önce etkin bir TL vadesiz, ticari ya da diğer banka hesabı açın." : "Önce kredi kartı tanımlayın: banka hesabının ayrıntısında + Kredi Kartı Ekle.", { type: "error" });
    // GG2: aktarılabilir tutar hesap bazında (açılıştan ve Devir Kapanışı'ndan sonraki satırlar; tahsilat ve kartla ödeme ayrı) — sunucunun hesabı.
    const availableOf = id => Math.abs(legacy?.reclassable?.[id]?.minor || 0);
    const first = accounts.find(account => availableOf(account.id) > 0) || accounts[0];
    if (!accounts.some(account => availableOf(account.id) > 0)) {
      return HOF.toast(mode === "bank" ? "Hesapların açılışından sonra bankaya geçmemiş POS tahsilatı yok. Açılıştan önceki hareketler açılış bakiyesinin içindedir (Kurulum Sihirbazı'ndaki Devir Kapanışı'yla kapanır)." : "Kart hesaplarının açılışından sonra kart borcuna aktarılmamış kartla ödeme yok. Açılıştan önceki hareketler açılış bakiyesinin içindedir (Kurulum Sihirbazı'ndaki Devir Kapanışı'yla kapanır).", { type: "error" });
    }
    const introOf = id => (mode === "bank" ? `Hesap tanımlanmadan girilmiş POS tahsilatlarının bankaya geçmiş tutarını hesaba aktarır. Seçilen hesabın açılışından sonraki satırlar aktarılır (en çok ${fmt(availableOf(id))}).` : `Hesap tanımlanmadan kredi kartıyla yapılmış ödemeleri kredi kartının borcuna aktarır. Seçilen kartın açılışından sonraki satırlar aktarılır (en çok ${fmt(availableOf(id))}).`);
    const requestId = HOF.requestId();
    HOF.formModal({
      title: mode === "bank" ? "Bankaya Geçmiş Say" : "Kart Borcuna Aktar",
      eyebrow: "HESABI ATANMAMIŞ POS / KART",
      intro: esc(introOf(first.id)),
      fields: [
        { name: "accountId", label: mode === "bank" ? "Banka Hesabı" : "Kredi Kartı", type: "select", value: first.id, options: accounts.map(account => ({ value: account.id, label: `${accountLabel(account)} (${account.code}) · en çok ${fmt(availableOf(account.id))}` })) },
        { name: "date", label: "Tarih", type: "date", required: true, max: "today", value: HOF.localToday() },
        { name: "amount", label: "Tutar", required: true, value: amountInput(availableOf(first.id)), inputmode: "decimal" },
      ],
      onOpen: dialog => {
        const form = dialog.querySelector("form");
        form?.querySelector('[name="accountId"]')?.addEventListener("change", event => {
          const amount = form.querySelector('[name="amount"]');
          if (amount) amount.value = amountInput(availableOf(event.target.value));
          const intro = dialog.querySelector(".hof-modal-text, .hof-form-intro");
          if (intro) intro.textContent = introOf(event.target.value);
        });
      },
      submitLabel: "Aktar",
      onSubmit: async data => {
        await api("/legacy/reclass", { method: "POST", body: { mode, ...data }, requestId });
        HOF.toast("Aktarıldı; Kurulum Geçmişi'nden geri alınabilir.", { type: "success" });
        await reload();
      },
    });
  }
  async function undoRun(id) {
    const go = await HOF.confirm({ title: "Kurulumu Geri Al", message: "Bu kurulumun fişleri ters kaydedilir ve hesaba bağlanan hareketler yeniden “Hesabı Atanmamış”a döner. Devam edilsin mi?", confirmLabel: "Geri Al", danger: true });
    if (!go) return;
    try {
      const result = await withConfirms(flags => api(`/setup/${encodeURIComponent(id)}/undo`, { method: "POST", body: { ...flags } }), { verb: "cancel" });
      HOF.toast(`Geri alındı: ${result.unassigned} hareket yeniden hesabı atanmamış.`, { type: "success" });
      await reload();
    } catch (error) {
      HOF.toastError(error);
    }
  }

  // ---------- Alt Hesap Mizanı ----------
  async function openSubTrial() {
    const box = HOF.modal({ title: "Alt Hesap Mizanı", eyebrow: moduleName().toLocaleUpperCase("tr-TR"), size: "wide", body: '<div data-subtrial><p class="hof-empty">Yükleniyor…</p></div>' });
    box.dialog.classList.add("hof-bank-modal-small");
    const node = box.dialog.querySelector("[data-subtrial]");
    try {
      const data = await api("/sub-trial");
      const money = value => esc(HOF.formatMoney(value));
      const rows = data.rows.map(row => `<tr>${td("Alt Hesap", `<b>${esc(row.sub)}</b>`)}${td("Hesap Adı", esc(row.name || "—"))}${td("Borç", money(row.debit), "num")}${td("Alacak", money(row.credit), "num")}${td("Bakiye", `<b>${money(row.balance)}</b>`, "num")}</tr>`).join("");
      const mains = data.mains.map(item => `<li class="${item.ok ? "is-ok" : "is-bad"}"><b>${esc(item.account)} ${esc(item.name)}</b> ${money(item.balance)} ${item.ok ? "=" : "≠"} Alt Hesaplar ${money(item.subTotal)} ${item.ok ? "✓" : "✗"}</li>`).join("");
      HOF.swap(node, `<div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-subtrial"><thead><tr><th>Alt Hesap</th><th>Hesap Adı</th><th class="num">Borç</th><th class="num">Alacak</th><th class="num">Bakiye</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="hof-empty">Banka alt hesabında hareket yok.</td></tr>'}</tbody></table></div>${mains ? `<ul class="hof-bank-mains">${mains}</ul>` : ""}<p class="hof-rep-note">Her ana hesabın bakiyesi alt hesaplarının toplamına eşit olmalıdır. 102.00 ve 108.00: hesabı atanmamış eski hareketler. 101.01 / 101.02: portföydeki ve bankaya tahsile verilen çekler; 121.01 / 121.02: portföydeki ve bankaya tahsile verilen senetler.</p>`);
    } catch (error) {
      HOF.swap(node, `<p class="hof-empty hof-list-error" role="alert">${esc(error.message)}</p>`);
    }
  }

  // ---------- Kurulum Sihirbazı (§8.3, §10.3) ----------
  function maybeWizard() {
    const s = view.summary;
    if (!s || wizard || wizardOffered || !canAccounts()) return;
    if (!s.setup?.needed || s.setup?.dismissed) return;
    wizardOffered = true;
    openWizard();
  }
  async function dismissWizard() {
    try {
      await api("/setup/dismiss", { method: "POST", body: {} });
    } catch {
      // Kapatma kaydı kritik değil: sihirbaz bir sonraki açılışta yeniden önerilir.
    }
  }
  function openWizard() {
    if (!canAccounts()) return HOF.toast("Kurulum Sihirbazı Banka Hesabı Tanımlama yetkisi ister.", { type: "error" });
    if (wizard) return;
    const legacyTotal = view.summary?.unassigned?.totalMinor || 0;
    const state = { step: "account", saved: [], requestId: HOF.requestId(), setupRequestId: HOF.requestId(), legacy: legacyTotal !== 0, preview: null, previewError: "", done: null };
    wizard = HOF.modal({
      title: "Kurulum Sihirbazı",
      eyebrow: moduleName().toLocaleUpperCase("tr-TR"),
      size: "wide",
      body: '<div class="hof-bank-wiz" data-wiz></div>',
      onClose: () => {
        wizard = null;
        dismissWizard().finally(() => {
          if (modal) reload();
        });
      },
    });
    wizard.dialog.classList.add("hof-bank-wiz-modal");
    wizard.dialog.addEventListener("click", event => onWizardClick(event, state));
    wizard.dialog.addEventListener("change", event => onWizardChange(event, state));
    wizard.dialog.addEventListener("submit", event => {
      event.preventDefault();
      if (event.target.matches("[data-wiz-form]")) saveWizardAccount(state, { next: true });
    });
    renderWizard(state);
  }
  const wizardNode = () => wizard?.dialog.querySelector("[data-wiz]");
  function wizardSteps(state) {
    const steps = [["account", "Hesap ve Açılış"], ...(state.legacy ? [["legacy", "Eski Hareketleri Aktar"]] : []), ["done", "Bitti"]];
    const at = steps.findIndex(([id]) => id === state.step);
    return `<ol class="hof-bank-steps">${steps.map(([id, label], index) => `<li class="${index === at ? "is-on" : index < at ? "is-done" : ""}" ${index === at ? 'aria-current="step"' : ""}><b>${index + 1}</b> ${esc(label)}</li>`).join("")}</ol>`;
  }
  function renderWizard(state) {
    const node = wizardNode();
    if (!node) return;
    const saved = state.saved.length
      ? `<ul class="hof-bank-wiz-saved" data-wiz-saved>${state.saved.map(account => `<li>✓ <b>${esc(accountLabel(account))}</b> · ${esc(account.code)} · ${esc(account.glSub)} · ${esc(fmt(account.opening?.amountMinor || 0, account.currency))}${account.balanceConfirmed ? " · Bakiye Doğrulandı" : ""}</li>`).join("")}</ul>`
      : "";
    let content = "";
    if (state.step === "account") {
      const fields = [
        { name: "bankName", label: "Banka Adı", required: true, autofocus: true, maxlength: 120, list: BANK_NAMES, placeholder: "ör. Ziraat Bankası" },
        { name: "name", label: "Hesap Adı", required: true, maxlength: 120, placeholder: "ör. Ana TL Hesabı" },
        // v2.2.0 (İz 2.3): kredi kartı sihirbazda da açılmaz — hesap açıldıktan sonra hesabın ayrıntısında "+ Kredi Kartı Ekle".
        { name: "kind", label: "Hesap Türü", type: "select", value: "demand", options: KINDS.filter(([id]) => id !== "fx" && id !== "card").map(([value, label]) => ({ value, label })) },
        ...(fxOn() ? [{ name: "currency", label: "Para Birimi", type: "select", value: "TRY", options: CURRENCIES.map(([value, label]) => ({ value, label })) }] : []),
        { name: "iban", label: "IBAN", maxlength: 40, placeholder: "TR00 0000 0000 0000 0000 0000 00" },
        ...openingFields(),
      ];
      // Fatura Ayarları'ndaki eski banka listesi (E2.16): henüz hesap olarak açılmamış IBAN'lar tek tıkla forma dolar.
      const suggestions = (view.summary?.setup?.suggestions || []).filter(item => !state.saved.some(account => account.iban === item.iban));
      const suggest = suggestions.length
        ? `<div class="hof-bank-wiz-suggest" data-wiz-suggest><small>Fatura Ayarları'ndaki banka bilgileri:</small>${suggestions.map((item, index) => `<button type="button" class="hof-rep-chip" data-wiz="suggest" data-index="${index}">${esc(item.bankName || "Banka")} · ${esc(item.iban.replace(/(.{4})/g, "$1 ").trim())}</button>`).join("")}</div>`
        : "";
      state.suggestions = suggestions;
      content = `<p class="hof-modal-text">Bankadaki her hesabı, açılış tarihindeki (gün başı) bakiyesiyle girin. Birden çok hesabınız varsa “Kaydet ve Yeni Hesap Ekle” ile sırayla ekleyin. Her adım atlanabilir.</p>
        ${saved}${suggest}
        <form class="hof-form hof-bank-form hof-bank-wiz-form" data-wiz-form novalidate>${fields.map(HOF.fieldHtml).join("")}
          <p class="hof-form-error" role="alert"></p>
          <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-wiz="skip">Bu Adımı Atla</button><button type="button" class="hof-button hof-button-ghost" data-wiz="save-more">Kaydet ve Yeni Hesap Ekle</button><button type="submit" class="hof-button" data-wiz="save-next">${state.saved.length ? "Kaydet ve İlerle" : "Kaydet ve İlerle"}</button></div>
        </form>`;
    } else if (state.step === "legacy") {
      const targets = bindableAccounts().filter(account => account.opening);
      const p = state.preview;
      const previewHtml = state.previewError
        ? `<p class="hof-bank-confirm is-warn">${esc(state.previewError)}</p>`
        : p
          ? `<dl class="hof-chq-facts hof-bank-preview" data-wiz-preview>
              <div><dt>Devir Kapanışı</dt><dd>Havale / EFT ${esc(fmt(p.carry.bankMinor))} · POS / Kart ${esc(fmt(p.carry.cardMinor))}</dd></div>
              <div><dt>Bağlanacak Hareket</dt><dd>${p.assign.count} hareket · net ${esc(signed(p.assign.amountMinor))}</dd></div>
              <div><dt>Kilitli Dönem — Atanamaz</dt><dd>${p.skipped.locked}</dd></div>
              ${p.skipped.future ? `<div data-wiz-future><dt>Tarihi Gelmemiş — Sonra Atanır</dt><dd>${p.skipped.future} hareket · net ${esc(signed(p.skipped.futureMinor))} · ilk ${esc(dateText(p.skipped.futureFirst))}</dd></div>` : ""}
              <div><dt>Sonra Hesap Bakiyesi</dt><dd>${esc(fmt(p.after.accountMinor))}</dd></div>
              <div><dt>Sonra Hesabı Atanmamış</dt><dd>Havale / EFT ${esc(fmt(p.after.unassignedBankMinor))} · POS / Kart ${esc(fmt(p.after.unassignedCardMinor))}</dd></div>
            </dl>`
          : '<p class="hof-empty">Önizleme hazırlanıyor…</p>';
      content = targets.length
        ? `<p class="hof-modal-text">Hesap tanımlanmadan girilmiş havale / EFT ve POS hareketleri “Hesabı Atanmamış Eski Hareketler”de duruyor. Açılış tarihinden önceki bakiye açılışa kapatılır (Devir Kapanışı); sonraki havale hareketleri seçtiğiniz hesaba bağlanır. Bu işlem Kurulum Geçmişi'nden geri alınabilir.</p>
          <form class="hof-form hof-bank-wiz-legacy" novalidate>
            ${HOF.fieldHtml({ name: "accountId", label: "Hesap", type: "select", value: state.accountId || targets[0].id, options: targets.map(account => ({ value: account.id, label: `${accountLabel(account)} (${account.code}) · açılış ${dateText(account.opening.date)}` })) })}
            ${HOF.fieldHtml({ name: "carryClose", label: "Açılıştan önceki eski bakiye açılışa kapatılsın (Devir Kapanışı)", type: "checkbox", value: state.carryClose !== false })}
            ${HOF.fieldHtml({ name: "assignAll", label: "Açılıştan sonraki eski havale hareketleri bu hesaba bağlansın", type: "checkbox", value: state.assignAll !== false })}
          </form>
          ${previewHtml}
          <p class="hof-form-error" role="alert">${esc(state.error || "")}</p>
          <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-wiz="skip">Bu Adımı Atla</button><button type="button" class="hof-button" data-wiz="transfer" ${p && !state.previewError ? "" : "disabled"}>Aktar</button></div>`
        : `<p class="hof-modal-text">Eski hareketleri aktarmak için önce açılış bakiyesi girilmiş, etkin bir TL vadesiz, ticari ya da diğer hesap gerekir. Bu adımı atlayıp sonra Genel Bakış → Hesabı Atanmamış Eski Hareketler'den yapabilirsiniz.</p>
          <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-wiz="back">← Hesap ve Açılış</button><button type="button" class="hof-button" data-wiz="skip">Bu Adımı Atla</button></div>`;
    } else {
      const s = view.summary;
      content = `<div class="hof-bank-wiz-done" data-wiz-done>
          <h4>${state.saved.length || state.done ? "Kurulum Tamamlandı" : "Kurulum Atlandı"}</h4>
          ${saved}
          ${state.done ? `<p>Eski hareketler aktarıldı: ${state.done.assigned} hareket hesaba bağlandı${state.done.carryNo ? `; Devir Kapanışı ${esc(state.done.carryNo)}` : ""}.</p>` : ""}
          ${state.done?.skipped?.future ? `<p data-wiz-done-future>Tarihi gelmemiş ${state.done.skipped.future} eski hareket atlandı (ilk ${esc(dateText(state.done.skipped.futureFirst))}); tarihi gelince Hesabı Atanmamış Eski Hareketler'den hesaba atayın.</p>` : ""}
          ${s?.realBank?.defined ? `<p class="hof-bank-wiz-real">Gerçek Banka: <b data-wiz-real>${esc(fmt(s.realBank.minor))}</b></p>` : ""}
          <p>${state.saved.length ? "Hesapları Hesaplar sekmesinden düzenleyebilir, yeni hesap ekleyebilirsiniz." : "Genel Bakış'taki “Kurulumu Tamamla” ile istediğiniz zaman devam edebilirsiniz."}</p>
        </div>
        <div class="hof-actions"><button type="button" class="hof-button" data-wiz="finish">Genel Bakış'a Git</button></div>`;
    }
    HOF.swap(node, `${wizardSteps(state)}${content}`);
    const form = node.querySelector("[data-wiz-form]");
    if (form) wireKindFields(form);
    if (state.step === "legacy" && !state.preview && !state.previewError && bindableAccounts().some(account => account.opening)) loadPreview(state);
  }
  const wizardForm = () => wizardNode()?.querySelector("[data-wiz-form]");
  const formData = form => Object.fromEntries([...form.querySelectorAll("[name]")].map(input => [input.name, input.type === "checkbox" ? input.checked : input.value]));
  const pristine = data => !String(data.bankName || "").trim() && !String(data.name || "").trim() && !String(data.openingAmount || "").trim() && !String(data.iban || "").trim();
  async function saveWizardAccount(state, { next = false } = {}) {
    const form = wizardForm();
    if (!form) return;
    const error = form.querySelector(".hof-form-error");
    error.textContent = "";
    const data = formData(form);
    if (next && pristine(data) && state.saved.length) return goWizard(state, state.legacy ? "legacy" : "done");
    const missing = [...form.querySelectorAll("[required]")].find(input => !String(input.value || "").trim());
    if (missing) {
      error.textContent = `"${missing.closest(".hof-field")?.querySelector("span")?.textContent.replace(/\s*\*\s*$/, "").trim()}" alanı boş bırakılamaz.`;
      missing.focus();
      return;
    }
    const buttons = [...form.querySelectorAll("button")];
    buttons.forEach(button => (button.disabled = true));
    try {
      const saved = await api("/accounts", { method: "POST", body: createBody({ ...data, code: "" }), requestId: state.requestId });
      state.requestId = HOF.requestId();
      const account = saved?.replayed ? saved.account : saved;
      if (account && !state.saved.some(item => item.id === account.id)) state.saved.push(account);
      choicesCache = null;
      await refreshWizardData();
      if (next) return goWizard(state, state.legacy ? "legacy" : "done");
      renderWizard(state);
      HOF.toast(`${account ? accountLabel(account) : "Hesap"} kaydedildi.`, { type: "success" });
    } catch (failure) {
      error.textContent = failure.message;
      markField(form, failure);
    } finally {
      buttons.forEach(button => button.isConnected && (button.disabled = false));
    }
  }
  /** Sihirbaz ilerlerken hesap listesi ve özet (eski hareketler, Gerçek Banka) yenilenir. */
  async function refreshWizardData() {
    try {
      const [summary, list] = await Promise.all([api("/summary"), api("/accounts?status=all")]);
      Object.assign(view, { summary, list });
      // Ayarlar'da kaydedilmemiş değişiklik varsa pencere yeniden çizilmez (reload ile aynı kural).
      if (modal && !(view.mode === "tab" && view.tab === "settings" && view.dirty)) render();
    } catch {
      // Ana pencere kendi yenilemesinde tekrar dener.
    }
  }
  async function goWizard(state, step) {
    state.step = step;
    state.error = "";
    if (step === "legacy") {
      state.preview = null;
      state.previewError = "";
    }
    if (step === "done") await refreshWizardData();
    renderWizard(state);
  }
  async function loadPreview(state) {
    const form = wizardNode()?.querySelector(".hof-bank-wiz-legacy");
    const accountId = form?.querySelector('[name="accountId"]')?.value || state.accountId || bindableAccounts().find(account => account.opening)?.id;
    if (!accountId) return;
    state.accountId = accountId;
    const body = { accountId, carryClose: state.carryClose !== false, assign: state.assignAll === false ? "none" : "all" };
    try {
      state.preview = await api("/setup?dryRun=1", { method: "POST", body });
      state.previewError = "";
    } catch (error) {
      state.preview = null;
      state.previewError = error.message;
    }
    if (wizard && state.step === "legacy") renderWizard(state);
  }
  async function runSetup(state) {
    const body = { accountId: state.accountId, carryClose: state.carryClose !== false, assign: state.assignAll === false ? "none" : "all" };
    const button = wizardNode()?.querySelector('[data-wiz="transfer"]');
    if (button) button.disabled = true;
    try {
      // Yargıç B2: bağlama hesabı eksiye düşürecekse (K7 Uyar) soru sorulur; Engelle'de neden yazılır.
      const result = await withConfirms(flags => api("/setup", { method: "POST", body: { ...body, ...flags }, requestId: state.setupRequestId }));
      state.done = result.replayed ? { assigned: 0, carryNo: "" } : result;
      state.setupRequestId = HOF.requestId();
      await goWizard(state, "done");
    } catch (error) {
      state.error = error.message;
      renderWizard(state);
    }
  }
  function onWizardClick(event, state) {
    const act = event.target.closest("[data-wiz]")?.dataset.wiz;
    if (!act) return;
    if (act === "skip") {
      // GG2 (düşük): doldurulmuş hesap formu sorusuz atılmaz.
      const form = state.step === "account" ? wizardForm() : null;
      const typed = form && ["bankName", "name", "iban", "openingAmount"].some(name => String(form.querySelector(`[name="${name}"]`)?.value || "").trim());
      const next = state.step === "account" && state.legacy ? "legacy" : "done";
      if (!typed) return goWizard(state, next);
      return HOF.confirm({ title: "Bu Adımı Atla", message: "Forma girilenler kaydedilmeyecek. Bu adım atlansın mı?", confirmLabel: "Kaydetmeden Atla", danger: true }).then(go => go && goWizard(state, next));
    }
    else if (act === "back") goWizard(state, "account");
    else if (act === "save-more") saveWizardAccount(state);
    else if (act === "suggest") {
      const item = state.suggestions?.[Number(event.target.closest("[data-index]")?.dataset.index)];
      const form = wizardForm();
      if (!item || !form) return;
      form.querySelector('[name="bankName"]').value = item.bankName || "";
      form.querySelector('[name="iban"]').value = item.iban.replace(/(.{4})/g, "$1 ").trim();
      form.querySelector('[name="name"]').focus();
    }
    else if (act === "transfer") runSetup(state);
    else if (act === "finish") {
      wizard?.close();
      if (modal) setTab("overview");
    }
  }
  function onWizardChange(event, state) {
    if (state.step !== "legacy") return;
    const input = event.target;
    if (input.name === "accountId") state.accountId = input.value;
    else if (input.name === "carryClose") state.carryClose = input.checked;
    else if (input.name === "assignAll") state.assignAll = input.checked;
    else return;
    state.preview = null;
    state.previewError = "";
    loadPreview(state);
  }

  // ---------- Hareketler (Aşama 4; §8.6) ----------
  /** Fiş formunun seçenekleri (türler, masraf türleri, vergi kipleri, tekrarlar, hesap adları, varsayılanlar); banka değişince boşalır. */
  function voucherMeta(force = false) {
    if (!metaCache || force)
      metaCache = api("/voucher-meta").catch(error => {
        metaCache = null;
        throw error;
      });
    return metaCache;
  }
  const STATUS_FILTERS = [
    ["", "Etkin ve Ters Kaydedilen"],
    ["active", "Yalnız Etkin"],
    ["reversed", "Ters Kaydedilen"],
    ["cancelled", "İptal Edilen"],
    ["all", "Hepsi"],
  ];
  const DIR_FILTERS = [
    ["", "Tümü"],
    ["in", "Giriş"],
    ["out", "Çıkış"],
  ];
  const filtered = state => Object.entries(state.filter).some(([key, value]) => key !== "account" && String(value || "").trim());
  /**
   * Liste yüklemesi (HOF.listGate kuralı): kullanıcının yüklemesi eski yanıtları geçersiz kılar; arka plan yenilemesi (quiet) kılmaz ve
   * yüklenmiş satır sayısını korur (en çok 200); "Daha Fazla" imleçle sonraki sayfayı ekler, süzgeç yüklenirken yok sayılır. İmleç geçersizse
   * (sunucu yeniden başladı ya da süzgeç değişti) liste baştan açılır. paint: false → yalnız veri (pencere çizimiyle birlikte gösterilir).
   */
  // Bağımsız inceleme H4/H5 (11.10.2026): (H4) Daha Fazla'nın yanıtı yalnız isteğin gittiği listeye eklenir — arada arka plan yenilemesi listeyi
  // değiştirdiyse Daha Fazla yeni listenin sonundan yeniden istenir (HOF.listGate retry; önceden sayfa sınırındaki hareket ekranda görünmüyordu).
  // (H5) aynı süzgeçteki her yeniden yükleme (kayıttan sonraki pencere yenilemesi dahil) yüklü satır sayısını korur (en çok 200; önceden
  // + Masraf kaydı Daha Fazla ile açılan satırları 50'ye geri alıyordu); yükleme sürerken tıklanan Daha Fazla yok sayılmaz, aynı süzgeçteki
  // yükleme bitince çalışır (süzgeç değiştiyse eski listenin uzunluğu yeni süzgece uygulanmaz — HOF.listGate kuralı).
  const movesSign = state => JSON.stringify([state.planned, state.filter]);
  async function loadMoves(state, options = {}) {
    await HOF.listRetry(() => loadMovesOnce(state, options));
    // Yükleme sürerken tıklanan Daha Fazla: yükleme bittiğinde (yazılmış ya da daha yeni bir yenilemeye yenilmiş) ekrandaki liste tıklandığı
    // süzgeçteyse şimdi çalışır; başka bir yükleme hâlâ sürüyorsa yine sıraya girer (o bitince).
    if (!options.more && !options.quiet && state.moreAfter) {
      const wanted = state.moreAfter;
      state.moreAfter = "";
      if (state.sign === wanted && state.hasMore && !state.planned) loadMoves(state, { more: true });
    }
  }
  /** Tek deneme; true → liste arada değişti, aynı istek yeni listeyle yinelenir (HOF.listRetry). */
  async function loadMovesOnce(state, { more = false, quiet = false, paint = true } = {}) {
    const run = state.gate.start({ quiet, more });
    if (!run) {
      if (more) state.moreAfter = movesSign(state);
      return false;
    }
    const sign = movesSign(state);
    const options = quiet ? { background: true } : {};
    try {
      if (state.planned) {
        const query = new URLSearchParams();
        if (state.filter.account) query.set("account", state.filter.account);
        const data = await api(`/plans${String(query) ? `?${query}` : ""}`, options);
        if (!run.current()) return run.retry();
        run.applied();
        Object.assign(state, { plans: data.plans || [], loaded: true, error: "", account: state.filter.account, hasMore: false, sign });
      } else {
        const query = new URLSearchParams();
        for (const [key, value] of Object.entries(state.filter)) if (String(value ?? "").trim()) query.set(key, String(value).trim());
        if (more) query.set("cursor", state.cursor || "");
        else if ((quiet || sign === state.sign) && state.rows.length > PAGE) query.set("limit", String(Math.min(200, state.rows.length)));
        const data = await api(`/movements?${query}`, options);
        if (!run.current()) return run.retry();
        run.applied();
        Object.assign(state, { rows: more ? [...state.rows, ...data.rows] : data.rows, cursor: data.nextCursor || null, hasMore: Boolean(data.hasMore), balance: Boolean(data.balance), loaded: true, error: "", account: data.account || "", sign });
      }
    } catch (error) {
      if (!run.current()) return false;
      if (more) {
        HOF.toastError(error);
        if (error?.data?.code === "bank-cursor") await loadMoves(state, { paint });
        return false;
      }
      if (quiet && !HOF.lostRecord(error)) throw error;
      Object.assign(state, { rows: [], plans: [], loaded: true, error: error.message, hasMore: false, cursor: null, sign: "" });
    } finally {
      run.done();
    }
    if (paint) paintMoves(state);
    return false;
  }
  function paintMoves(state) {
    const node = root()?.querySelector(`[data-moves="${state.key}"]`);
    if (!node) return;
    node.dataset.account = state.account || "";
    HOF.swap(node, movesListHtml(state));
    // 2.3.0 İz 5.1: PDF / Excel bağları süzgeçle birlikte yenilenir (süzgeç değişince yalnız liste çizilir).
    const exportBar = state.key === "main" ? root()?.querySelector("[data-mv-export]") : null;
    if (exportBar) exportBar.outerHTML = movesExportHtml(state);
  }
  /** Hareket satırları: tarih, İşlem No, tür (durum rozetiyle), [hesap], açıklama (cari, açıklama, referans, fatura), tutar, [bakiye]. */
  // debt (GG2 düşük): kurumsal kart ve kredi hesabında yürüyen bakiye "Borç" kolonunda artı gösterilir (başlıktaki Borç ve Açılıştaki Borç gibi).
  function moveTableHtml(rows, { showAccount = false, showBalance = false, extraClass = "", debt = false } = {}) {
    const body = rows
      .map(row => {
        // Aşama 9: iki hesaplı işlemde (transfer, kart borcu, kredi) karşı hesap da yazılır.
        const desc = [row.partyName, row.counterAccountLabel ? `Karşı Hesap ${row.counterAccountLabel}` : "", row.description, row.reference ? `Ref. ${row.reference}` : "", row.invoiceNo ? `Fatura ${row.invoiceNo}` : "", row.feeNo ? `Masraf ${row.feeNo}` : ""].filter(Boolean).join(" · ");
        const badge = row.status === "active" ? "" : ` <span class="hof-plan-badge is-muted">${esc(row.statusLabel)}</span>`;
        const cls = row.status !== "active" ? "is-muted" : row.signedMinor >= 0 ? "is-in" : "is-out";
        return `<tr data-event="${esc(row.eventId)}" data-no="${esc(row.no)}" data-type="${esc(row.type)}" data-state="${esc(row.status)}" data-signed="${Number(row.signedMinor) || 0}" data-balance="${row.balanceAfterMinor === null || row.balanceAfterMinor === undefined ? "" : row.balanceAfterMinor}" tabindex="0" class="${cls}">
          ${td("Tarih", esc(dateText(row.date)))}
          ${td("İşlem No", `<span class="hof-plan-refno">${esc(row.no)}</span>`)}
          ${td("Tür", `${esc(row.typeLabel)}${badge}`)}
          ${showAccount ? td("Hesap", esc(row.accountLabel || "—")) : ""}
          ${td("Açıklama", esc(desc || "—"))}
          ${td("Tutar", `<b>${esc(signed(row.signedMinor))}</b>`, "num")}
          ${showBalance ? td(debt ? "Borç" : "Bakiye", esc(fmt(debt ? -row.balanceAfterMinor : row.balanceAfterMinor)), "num") : ""}
        </tr>`;
      })
      .join("");
    return `<table class="hof-table hof-bank-table hof-bank-moves ${extraClass}"><thead><tr><th>Tarih</th><th>İşlem No</th><th>Tür</th>${showAccount ? "<th>Hesap</th>" : ""}<th>Açıklama</th><th class="num">Tutar</th>${showBalance ? `<th class="num">${debt ? "Borç" : "Bakiye"}</th>` : ""}</tr></thead><tbody>${body}</tbody></table>`;
  }
  function movesListHtml(state) {
    if (!state.loaded || state.error) return HOF.listPending(state.error);
    if (state.planned) return plansHtml(state);
    if (!state.rows.length) return `<p class="hof-empty" data-moves-empty>${filtered(state) ? "Bu süzgeçte hareket yok." : state.key === "account" ? "Bu hesapta hareket yok." : "Henüz banka hareketi yok."}</p>`;
    const more = state.hasMore ? `<div class="hof-bank-more"><button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="mv-more" data-moves-key="${esc(state.key)}">Daha Fazla Göster</button><small>${state.rows.length} hareket gösteriliyor</small></div>` : state.rows.length > PAGE ? `<p class="hof-rep-note">${state.rows.length} hareketin hepsi gösteriliyor.</p>` : "";
    const account = state.account ? (view.account?.id === state.account ? view.account : (view.list?.accounts || []).find(item => item.id === state.account)) : null;
    const debt = Boolean(account) && !MAIN_KINDS.has(account.kind);
    return `<div class="hof-bank-table-wrap">${moveTableHtml(state.rows, { showAccount: !state.account, showBalance: state.balance, extraClass: state.key === "account" ? "hof-bank-recent" : "", debt })}</div>${more}`;
  }
  const PLAN_OUT = new Set(["fee", "interest_out", "other_out", "card_payment", "loan_repay", "transfer"]);
  function plansHtml(state) {
    if (!state.plans.length) return '<p class="hof-empty" data-moves-empty>Planlı işlem yok. Kira, kredi taksiti ya da masraf talimatı gibi tekrar eden ödemeleri “+ Planlı İşlem” ile ekleyin.</p>';
    const canMove = HOF.can("bank.move");
    const rows = state.plans
      .map(plan => {
        const allowed = canMove && (!TRANSFER_KINDS.has(plan.kind) || HOF.can("bank.transfer"));
        const amount = (PLAN_OUT.has(plan.kind) ? -1 : 1) * plan.amountMinor;
        const actions = allowed ? `<button type="button" class="hof-link-button" data-act="plan-run" data-plan="${esc(plan.id)}">Gerçekleştir</button>${plan.repeat !== "none" ? `<button type="button" class="hof-link-button" data-act="plan-skip" data-plan="${esc(plan.id)}">Atla</button>` : ""}<button type="button" class="hof-link-button is-danger" data-act="plan-cancel" data-plan="${esc(plan.id)}">Sil</button>` : "";
        return `<tr data-plan="${esc(plan.id)}" class="${plan.due ? "is-due" : ""}">
          ${td("Planlı Tarih", esc(dateText(plan.plannedDate)))}
          ${td("Tür", esc(plan.typeLabel))}
          ${td("Hesap", `${esc(plan.accountLabel || "—")}${plan.toAccountLabel ? `<small>${esc(plan.toAccountLabel)}</small>` : ""}`)}
          ${td("Tekrar", esc(plan.repeatLabel))}
          ${td("Açıklama", esc(plan.description || "—"))}
          ${td("Tutar", `<b>${esc(signed(amount))}</b>`, "num")}
          ${td("Durum", plan.due ? '<span class="hof-plan-badge is-soon">Vadesi Geldi</span>' : '<span class="hof-plan-badge is-info">Planlı</span>')}
          <td class="hof-bank-actions-cell">${actions}</td>
        </tr>`;
      })
      .join("");
    return `<div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-plans"><thead><tr><th>Planlı Tarih</th><th>Tür</th><th>Hesap</th><th>Tekrar</th><th>Açıklama</th><th class="num">Tutar</th><th>Durum</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }
  /** Hareketler sekmesi: işlem düğmeleri, süzgeçler, liste (ya da Planlı İşlemler). */
  function movementsHtml() {
    const s = moves;
    const canMove = HOF.can("bank.move");
    const accounts = view.list?.accounts || [];
    const option = (value, label, current) => `<option value="${esc(value)}" ${String(value) === String(current ?? "") ? "selected" : ""}>${esc(label)}</option>`;
    const banks = new Map();
    for (const account of accounts) {
      if (!banks.has(account.bankName)) banks.set(account.bankName, []);
      banks.get(account.bankName).push(account);
    }
    const accountSelect = `<select data-mv="account" aria-label="Hesap">${option("", "Tüm Hesaplar", s.filter.account)}${[...banks.entries()].map(([bank, list]) => `<optgroup label="${esc(bank)}">${list.map(account => option(account.id, `${account.name} (${account.code})${account.status === "passive" ? " · Pasif" : ""}`, s.filter.account)).join("")}</optgroup>`).join("")}</select>`;
    const groups = view.meta?.groups || [];
    const filter = (label, control, wide = false) => `<label class="hof-bank-filter${wide ? " is-wide" : ""}"><span>${esc(label)}</span>${control}</label>`;
    const tools = [
      canMove ? `<button type="button" class="hof-button hof-button-small" data-act="v-fee">+ Masraf</button><button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="v-interest">+ Faiz</button><button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="v-other">+ Diğer İşlem</button>` : "",
      // Aşama 9: Bankalar Arası Transfer (Transfer Yapma yetkisi; en az iki transfer hesabı formda denetlenir).
      HOF.can("bank.transfer") ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="v-transfer">Transfer</button>' : "",
      canMove && HOF.can("tax.manage") ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="v-tax">+ Vergi Ödemesi</button>' : "",
      canMove ? '<button type="button" class="hof-button hof-button-small hof-button-ghost" data-act="plan-new">+ Planlı İşlem</button>' : "",
    ].join("");
    const filters = s.planned
      ? filter("Hesap", accountSelect)
      : [
          filter("Hesap", accountSelect),
          filter("İşlem Türü", `<select data-mv="type">${option("", "Tümü", s.filter.type)}${groups.map(item => option(item.key, item.label, s.filter.type)).join("")}</select>`),
          filter("Giriş ve Çıkış", `<select data-mv="dir">${DIR_FILTERS.map(([value, label]) => option(value, label, s.filter.dir)).join("")}</select>`),
          filter("Durum", `<select data-mv="status">${STATUS_FILTERS.map(([value, label]) => option(value, label, s.filter.status)).join("")}</select>`),
          // 2.2.0 (İz 3.3, plan §8.6 "Süzgeçler: … POS"): yalnız seçilen POS'un banka hareketleri (gün sonu fişleri, İptal İadesi).
          ...((view.posList || []).length || s.filter.pos ? [filter("POS", `<select data-mv="pos">${option("", "Tüm POS'lar", s.filter.pos)}${(view.posList || []).map(item => option(item.id, `${item.name} (${item.code})${item.status === "passive" ? " · Pasif" : ""}`, s.filter.pos)).join("")}</select>`)] : []),
          filter("Başlangıç", `<input type="date" data-mv="from" value="${esc(s.filter.from)}" max="${esc(HOF.localToday())}">`),
          filter("Bitiş", `<input type="date" data-mv="to" value="${esc(s.filter.to)}">`),
          filter("En Az Tutar", `<input type="text" inputmode="decimal" data-mv="min" value="${esc(s.filter.min)}" placeholder="ör. 100">`),
          filter("En Çok Tutar", `<input type="text" inputmode="decimal" data-mv="max" value="${esc(s.filter.max)}" placeholder="ör. 5.000">`),
          filter("Ara", `<input type="search" data-mv="q" value="${esc(s.filter.q)}" maxlength="100" placeholder="Cari adı, açıklama, referans ya da İşlem No">`, true),
        ].join("");
    return `<div class="hof-bank-toolbar">${tools}<div class="hof-rep-presets" role="group" aria-label="Görünüm"><button type="button" class="hof-rep-chip ${s.planned ? "is-on" : ""}" aria-pressed="${s.planned}" data-act="mv-planned">Planlı İşlemler</button></div></div>
      <div class="hof-bank-filters" data-mv-filters>${filters}${filtered(s) && !s.planned ? '<button type="button" class="hof-link-button" data-act="mv-clear">Süzgeçleri Temizle</button>' : ""}${s.planned ? "" : movesExportHtml(s)}</div>
      <div class="hof-bank-moves-wrap" data-moves="main" data-account="${esc(s.account)}">${movesListHtml(s)}</div>
      <p class="hof-rep-note">${s.planned ? "Planlı işlemler deftere kendiliğinden yazılmaz; bankada gerçekleşince “Gerçekleştir” ile planlı ya da gerçek tarihle kaydedilir." : "Yürüyen bakiye tek hesap seçiliyken ve başka süzgeç yokken görünür. Satıra tıklayınca İşlem Kartı açılır."}</p>`;
  }
  // 2.3.0 İz 5.1 (müşteri isteği): Hareketler'in PDF / Excel düğmeleri — ekrandaki süzgeçlerle (hesap, tür, yön, durum, POS, tarih, tutar, arama)
  // sunucunun aynı listesi, alt TOPLAM (routes/bank.mjs movements.pdf / .xlsx; Rapor Merkezi'nin üreticisi). bank.view yeter: kullanıcı yalnız
  // ekranda gördüğü satırları indirir.
  function movesExportHtml(state) {
    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(state.filter)) if (String(value ?? "").trim()) query.set(key, String(value).trim());
    const qs = String(query);
    return `<span class="hof-rep-export hof-bank-export" role="group" aria-label="Dışa aktar" data-mv-export>
      ${HOF.outputButton({ kind: "pdf", href: `${BASE}/movements.pdf${qs ? `?${qs}` : ""}`, what: "Banka Hareketleri", tip: "Süzgeçteki hareketleri PDF olarak aç", attrs: 'target="_blank" rel="noopener"' })}
      ${HOF.outputButton({ kind: "xlsx", href: `${BASE}/movements.xlsx${qs ? `?${qs}` : ""}`, what: "Banka Hareketleri", tip: "Süzgeçteki hareketleri Excel olarak indir", attrs: "download" })}</span>`;
  }
  let searchTimer = 0;
  // 2.4.3 (C7): tarih alanı klavyeyle yazılırken her geçerli ara değerde (yıl "0002", "0020", "0202") change verir; önceden her hanede istek
  // gidiyordu (ikisi 400). Artık yalnız makul tarih (yıl 1900–2999) süzer ve son tuştan 700 ms sonra; Enter ya da alandan çıkınca hemen.
  let dateTimer = 0;
  const DATE_FILTERS = new Set(["from", "to"]);
  const plausibleDate = value => /^(19|2\d)\d{2}-\d{2}-\d{2}$/.test(value);
  /**
   * Süzgeç değişti: ekrandaki bütün süzgeç alanları birlikte okunur (bekleyen arama yazısı da kaybolmaz), liste baştan yüklenir (imleç
   * bırakılır; HOF.listGate eski yanıtı yok sayar). Hiçbir değer değişmediyse yeniden yüklenmez.
   */
  function applyFilters() {
    clearTimeout(searchTimer);
    clearTimeout(dateTimer);
    let changed = false;
    for (const node of root()?.querySelectorAll("[data-mv-filters] [data-mv]") || []) {
      const key = node.dataset.mv;
      const clean = String(node.value ?? "").trim();
      if (!Object.hasOwn(moves.filter, key) || moves.filter[key] === clean) continue;
      // Yazımı süren (yarım) tarih süzgece girmez; boş tarih (temizlendi) girer.
      if (DATE_FILTERS.has(key) && clean && !plausibleDate(clean)) continue;
      moves.filter[key] = clean;
      changed = true;
    }
    if (!changed) return;
    moves.cursor = null;
    const clear = root()?.querySelector('[data-act="mv-clear"]');
    if (!clear && filtered(moves)) root()?.querySelector("[data-mv-filters]")?.insertAdjacentHTML("beforeend", '<button type="button" class="hof-link-button" data-act="mv-clear">Süzgeçleri Temizle</button>');
    loadMoves(moves);
  }
  /** Hareketler sekmesini (ya da Planlı İşlemler'i) bir hesapla açar. */
  function openMovements({ account = moves.filter.account, planned = false, pos = "" } = {}) {
    moves.filter = { ...newMoves("main").filter, account: account || "", pos: pos || "" };
    moves.planned = planned;
    moves.cursor = null;
    moves.rows = [];
    moves.plans = [];
    moves.loaded = false;
    setTab("movements");
  }

  // ---------- İşlem Kartı (§8.6) ----------
  // Transfer Yapma yetkisi isteyen türler (§9.1): bankalar arası transfer (Aşama 9), kredi kullanımı ve geri ödemesi.
  const TRANSFER_KINDS = new Set(["transfer", "loan_draw", "loan_repay"]);
  const LOAN_KINDS = new Set(["loan_draw", "loan_repay"]);
  const PERM_NAMES = { "bank.cancel": "Banka Hareketi Silme, İptal ve Ters Kayıt", "bank.move": "Banka Hareketi Girme ve Bankadan Çıkış", "bank.transfer": "Transfer Yapma", "invoices.manage": "Fatura Yönetimi" };
  /** Yetki nedeni (pasif düğmenin yanında yazılır): eksik yetkilerin adları. */
  const permWhy = (action, list) => {
    const missing = list.filter(permission => !HOF.can(permission));
    return missing.length ? `${action} için ${missing.map(permission => PERM_NAMES[permission] || permission).join(" ve ")} yetkisi gerekir.` : "";
  };
  // İşlem Kartı'ndaki İşlem Geçmişi'nin adları (Yönetim → İşlem Geçmişi'yle aynı türler; cümle düzeninde).
  const HISTORY_LABELS = {
    "bank.voucher.created": "Fiş kaydedildi",
    "bank.transfer.created": "Transfer kaydedildi",
    "bank.voucher.reversed": "Ters kaydedildi",
    "bank.voucher.corrected": "Düzeltildi (ters kayıt ve yeni fiş)",
    "bank.event.info": "Açıklama düzeltildi",
    "bank.plan.created": "Planlı işlem eklendi",
    "bank.plan.executed": "Planlı işlem gerçekleştirildi",
    "bank.plan.skipped": "Planlı işlemin bu dönemi atlandı",
    "bank.plan.cancelled": "Planlı işlem silindi",
    "bank.account.created": "Hesap açıldı",
    "bank.account.opening.entered": "Açılış bakiyesi girildi",
    "bank.account.opening.corrected": "Açılış düzeltildi",
    "bank.legacy.assigned": "Hesaba atandı",
    "bank.legacy.reclassed": "Eski bakiye aktarıldı",
    "bank.setup": "Kurulum Sihirbazı çalıştı",
    "bank.setup.undone": "Kurulum geri alındı",
  };
  const isVat = tax => tax === "vat_incl" || tax === "vat_excl";
  /** İşlemin tutarı: faturalı (KDV'li) masrafın başlığı satırsızdır (parası faturanın havalesinde); tutarı faturanın ödenecek tutarıdır. */
  // Bankalar arası transferde tutar alıcıya giren tutardır (ücret ayrı satırda; gönderenden çıkan = tutar + ücret).
  const eventAmount = c => (c?.transfer ? c.transfer.amountMinor : c?.fee?.taxKind === "vat" && !c.source ? c.fee.totalMinor : c?.tryMinor || 0);
  /** "Kaynak → Hedef" (ABC Ltd. (Cari) → Ziraat · Ana TL Hesabı (Banka)). */
  function flowText(c) {
    if (!c.account) return "";
    const account = `${c.account.label} (Banka)`;
    const counter = c.counterAccount ? `${c.counterAccount.label} (${kindLabel(c.counterAccount.kind)})` : "";
    const party = c.party?.name ? `${c.party.name} (Cari)` : "";
    const line = role => c.lines.find(item => item.role === role);
    const other = party || counter || (c.direction === "in" ? (line("income") ? `${line("income").gl} ${line("income").glName}` : "") : line("expense") ? `${line("expense").gl} ${line("expense").glName}` : "");
    return c.direction === "in" ? `${other || "—"} → ${account}` : `${account} → ${other || "—"}`;
  }
  const backLabel = () => (view.eventBack === "account" ? "Hesap" : view.eventBack === "overview" ? "Genel Bakış" : "Hareketler");
  /**
   * 2.2.0 (İz 3.3; plan §8.6, kabul 23–28): İşlem Kartı'nın POS bölümü (sunucu movements card → pos.eventInfo). POS satışı/iadesinde POS, taksit,
   * provizyon, son 4 hane, valör açıklaması ("12.10.2026 (08.10 Perşembe + 2 iş günü)"), komisyon ve net, valör kalemleri; iadede asıl satış ve asıl
   * fatura. Gün sonu fişinde bağlı kalemler (valör, rol, brüt, net, satışın İşlem No'su) ve KDV'li kipte sağlayıcıya yazılan kesinti satırları.
   */
  const ITEM_ROLES = { sale: "Satış", refund: "İade", fee: "Komisyon Tahsili" };
  function posEventHtml(p) {
    if (!p) return "";
    const link = (no, label = no) => (no ? `<button type="button" class="hof-link-button" data-event-link="${esc(no)}">${esc(label)}</button>` : "");
    if (p.kind === "settlement") {
      const rows = (p.items || []).map(item => `<tr>${td("Valör", esc(dateText(item.valueDate)))}${td("Kalem", esc(ITEM_ROLES[item.role] || item.role))}${td("Satış", `${link(item.saleEventNo) || "—"}<small>${esc(dateText(item.saleDate))}</small>`)}${td("Brüt", esc(fmt(item.grossMinor)), "num")}${td("Net", esc(fmt(item.plannedNetMinor)), "num")}</tr>`).join("");
      const fees = (p.fees || []).map(row => `<li>${esc(row.note || "")} · ${esc(fmt(Math.round(Number(row.amount) * 100)))}</li>`).join("");
      return `<section class="hof-bank-linked" data-event-pos="settlement"><h4 class="hof-bank-subtitle">POS Gün Sonu Kalemleri</h4>${p.explain?.length ? `<p class="hof-rep-note" data-pos-explain>Valör: ${esc(p.explain.join(" · "))}</p>` : ""}
        <div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table"><thead><tr><th>Valör</th><th>Kalem</th><th>Satış</th><th class="num">Brüt</th><th class="num">Net</th></tr></thead><tbody>${rows}</tbody></table></div>${fees ? `<ul class="hof-bank-links">${fees}</ul>` : ""}</section>`;
    }
    const fact = (label, value) => (value ? `<div><dt>${esc(label)}</dt><dd>${value}</dd></div>` : "");
    const items = (p.items || []).map(item => `<li>${esc(dateText(item.valueDate))} · ${esc(ITEM_ROLES[item.role] || item.role)} · brüt ${esc(fmt(item.grossMinor))} · net ${esc(fmt(item.plannedNetMinor))}${item.blocked ? " · Blokeli" : ""} · ${esc(item.status === "settled" ? `bankaya geçti${item.voucherNo ? ` (${item.voucherNo})` : ""}` : item.status === "void" ? "iptal" : "bekliyor")}</li>`).join("");
    return `<section class="hof-bank-linked" data-event-pos="${esc(p.kind)}"><h4 class="hof-bank-subtitle">${esc(p.kindLabel || "POS")}</h4><dl class="hof-chq-facts">
        ${fact("POS", esc(p.posName))}
        ${fact("Durum", esc(p.statusLabel))}
        ${p.kind === "sale" ? fact("POS Taksit Sayısı", esc(p.installmentLabel)) : ""}
        ${fact("Provizyon No", esc(p.authCode || ""))}
        ${fact("Kartın Son 4 Hanesi", p.cardLast4 ? `•••• ${esc(p.cardLast4)}` : "")}
        ${fact("Valör", p.explain ? `<span data-pos-explain>${esc(p.explain)}</span>` : "")}
        ${fact("Komisyon", p.kind === "sale" ? `%${esc(pctText(p.rate))} ·${esc(fmt(p.commissionMinor))} <small>${esc(p.taxLabel || "")}</small>` : p.commissionRefundMinor ? `${esc(fmt(p.commissionRefundMinor))} iade` : "")}
        ${fact("Bankaya Geçecek (Net)", esc(fmt(p.netMinor)))}
        ${p.kind === "sale" && p.refundedMinor ? fact("İade Edilen", esc(fmt(p.refundedMinor))) : ""}
        ${fact("Asıl POS Satışı", p.origin ? `${link(p.origin.eventNo) || esc(dateText(p.origin.date))} <small>${esc(dateText(p.origin.date))} · ${esc(fmt(p.origin.grossMinor))}</small>` : "")}
        ${fact("Asıl Fatura", p.originInvoice ? `<button type="button" class="hof-link-button" data-open-invoice="${esc(p.originInvoice.id)}">${esc(p.originInvoice.number)}</button>` : "")}
      </dl>${items ? `<ul class="hof-bank-links" data-pos-items>${items}</ul>` : ""}</section>`;
  }
  function eventHtml() {
    const back = `<button type="button" class="hof-plan-back" data-act="ev-back">← ${esc(backLabel())}</button>`;
    const c = view.event;
    if (!c) return `<div class="hof-bank-detail-head">${back}</div>${HOF.listPending(view.error)}`;
    const feeHeader = c.fee?.taxKind === "vat" && !c.source;
    const extra = [...(TRANSFER_KINDS.has(c.type) ? ["bank.transfer"] : []), ...(feeHeader ? ["invoices.manage"] : [])];
    const reverseWhy = (c.actions?.reverse?.allowed === false && c.actions.reverse.reason) || permWhy("Ters Kaydet", ["bank.cancel", ...extra]);
    const correctWhy = (c.actions?.correct?.allowed === false && c.actions.correct.reason) || permWhy("Düzelt", ["bank.move", "bank.cancel", ...extra]);
    // GG2 (düşük): modülden gelen harekette açıklama kendi penceresinde (sunucu actions.info kapalı ve nedeni).
    const infoWhy = (c.actions?.info?.allowed === false && c.actions.info.reason) || permWhy("Açıklamayı Düzelt", ["bank.move"]);
    const blocks = [];
    if (reverseWhy && reverseWhy === correctWhy) blocks.push(["Ters Kaydet ve Düzelt", reverseWhy]);
    else {
      if (reverseWhy) blocks.push(["Ters Kaydet", reverseWhy]);
      if (correctWhy) blocks.push(["Düzelt", correctWhy]);
    }
    if (infoWhy) blocks.push(["Açıklamayı Düzelt", infoWhy]);
    const button = (act, label, why, cls = "hof-button-ghost") => `<button type="button" class="hof-button hof-button-small ${cls}" data-act="${act}" ${why ? `disabled aria-disabled="true" title="${esc(why)}"` : ""}>${esc(label)}</button>`;
    const toolbar = HOF.can("bank.move") || HOF.can("bank.cancel") ? `<div class="hof-chq-actions" role="toolbar" aria-label="İşlem işlemleri">${button("ev-reverse", "Ters Kaydet", reverseWhy, "hof-button-danger-ghost")}${button("ev-correct", "Düzelt", correctWhy)}${button("ev-info", "Açıklamayı Düzelt", infoWhy)}</div>` : "";
    const fact = (label, value) => (value ? `<div><dt>${esc(label)}</dt><dd>${value}</dd></div>` : "");
    const link = (item, label = item.no) => `<button type="button" class="hof-link-button" data-event-link="${esc(item.id)}">${esc(label)}</button>`;
    const fee = c.fee;
    const rate = ppm => String((Number(ppm) || 0) / 10_000).replace(".", ",");
    const relations = [
      c.reversal?.by ? `<li>Ters Kaydı: ${link(c.reversal.by)} · ${esc(dateText(c.reversal.by.date))}</li>` : "",
      c.reversal?.of ? `<li>Ters Kaydettiği İşlem: ${link(c.reversal.of)} · ${esc(dateText(c.reversal.of.date))}</li>` : "",
      c.linkedFee ? `<li>Masrafın İşlem Kartı: ${link(c.linkedFee)}</li>` : "",
      c.payment ? `<li>Bankadan Ödeme: ${link(c.payment)}</li>` : "",
    ].filter(Boolean);
    const debit = c.lines.filter(line => line.side === "D").reduce((sum, line) => sum + line.tryMinor, 0);
    const credit = c.lines.filter(line => line.side === "C").reduce((sum, line) => sum + line.tryMinor, 0);
    const lines = c.lines.length
      ? `<div class="hof-bank-table-wrap"><table class="hof-table hof-bank-table hof-bank-lines"><thead><tr><th>Hesap</th><th>Alt Hesap</th><th>Açıklama</th><th class="num">Borç</th><th class="num">Alacak</th></tr></thead><tbody>${c.lines
          .map(line => `<tr data-gl="${esc(line.gl)}" data-side="${esc(line.side)}" data-minor="${Number(line.tryMinor) || 0}">${td("Hesap", `<b>${esc(line.gl)}</b> ${esc(line.glName)}`)}${td("Alt Hesap", line.sub ? `${esc(line.sub)}${line.subName ? `<small>${esc(line.subName)}</small>` : ""}` : "—")}${td("Açıklama", esc(line.memo || "—"))}${td("Borç", line.side === "D" ? esc(fmt(line.tryMinor)) : "", "num")}${td("Alacak", line.side === "C" ? esc(fmt(line.tryMinor)) : "", "num")}</tr>`)
          .join("")}</tbody><tfoot><tr class="hof-bank-total"><td colspan="3" data-label="Toplam">Toplam</td>${td("Borç", esc(fmt(debit)), "num")}${td("Alacak", esc(fmt(credit)), "num")}</tr></tfoot></table></div>`
      : '<p class="hof-empty">Bu işlemin yevmiye satırı yok.</p>';
    const history = (c.history || []).map(item => `<li><b>${esc(HISTORY_LABELS[item.type] || item.type)}</b> <small>${esc([item.actorName, HOF.formatDateTime(item.at)].filter(Boolean).join(" · "))}</small></li>`).join("");
    return `<div data-bank-event><div class="hof-bank-detail-head">${back}
        <div class="hof-plan-title"><h3>${esc(c.typeLabel)} <span class="hof-plan-refno" data-event-no>${esc(c.no)}</span> <span class="hof-plan-badge ${c.status === "active" ? "is-done" : "is-muted"}" data-event-status>${esc(c.statusLabel)}</span></h3><small>${esc(flowText(c))}</small></div>
        <div class="hof-chq-amount"><span>Tutar</span><strong data-event-amount>${esc(fmt(eventAmount(c)))}</strong></div>
      </div>
      ${c.locked ? `<p class="hof-bank-confirm is-warn">Bu işlem kilitli dönemde (${esc(dateText(c.lockedUntil))} ve öncesi); kendisi değişmez. Ters Kaydet ve Düzelt'te ters kaydı bugün tarihli yazılır, kilitli dönem aynı kalır.</p>` : ""}
      <dl class="hof-chq-facts">
        ${fact("İşlem No", `<span class="hof-plan-refno">${esc(c.no)}</span>`)}
        ${fact("Tür", esc(c.typeLabel))}
        ${fact("Tarih", esc(dateText(c.date)))}
        ${c.valueDate && c.valueDate !== c.date ? fact("Valör", esc(dateText(c.valueDate))) : ""}
        ${fact("Durum", esc(c.statusLabel))}
        ${fact(c.transfer ? "Gönderen Hesap" : "Hesap", c.account ? `${esc(c.account.label)} <small>${esc(c.account.glSub)}</small>` : "")}
        ${fact(c.transfer ? "Alıcı Hesap" : "Karşı Hesap", c.counterAccount ? `${esc(c.counterAccount.label)} <small>${esc(c.counterAccount.glSub)}</small>` : "")}
        ${c.transfer ? fact("Ücret", c.transfer.feeMinor ? `<span data-transfer-fee="${c.transfer.feeMinor}">${esc(fmt(c.transfer.feeMinor))}</span> <small>${esc([c.transfer.feeTypeName, c.transfer.feeTaxMinor ? `${fmt(c.transfer.feeBaseMinor)} + BSMV ${fmt(c.transfer.feeTaxMinor)}` : "", c.transfer.gl].filter(Boolean).join(" · "))}</small>` : "Yok") : ""}
        ${c.transfer ? fact("Gönderenden Çıkan", `<span data-transfer-out="${c.transfer.outMinor}">${esc(fmt(c.transfer.outMinor))}</span>`) : ""}
        ${fact("Cari", c.party?.name ? (HOF.can("accounts.view") ? `<button type="button" class="hof-link-button" data-open-party="${esc(c.party.id)}">${esc(c.party.name)}</button>` : esc(c.party.name)) : "")}
        ${fact("Fatura", c.invoice ? `<button type="button" class="hof-link-button" data-open-invoice="${esc(c.invoice.id)}">${esc(c.invoice.number)}</button>` : "")}
        ${fee ? fact("Masraf Türü", `${esc(fee.feeTypeName || "—")} <small>${esc(fee.gl)} ${esc(view.meta?.glNames?.[fee.gl] || "")}</small>`) : ""}
        ${fee ? fact("Matrah", esc(fmt(fee.baseMinor))) : ""}
        ${fee && fee.taxKind === "bsmv" ? fact("BSMV", `${esc(fmt(fee.taxMinor))} <small>%${esc(rate(fee.ratePpm))}</small>`) : ""}
        ${fee && fee.taxKind === "vat" ? fact("KDV", `${esc(fmt(fee.vatMinor))} <small>%${esc(rate(fee.ratePpm))}</small>`) : ""}
        ${fact("Referans", esc(c.reference))}
        ${fact("Açıklama", esc(c.description))}
        ${fact("Kanal", esc(c.channel))}
        ${fact("Kaynak", c.source ? esc(c.source.label) : "")}
        ${fact("Giren", esc([c.createdByName, HOF.formatDateTime(c.createdAt)].filter(Boolean).join(" · ")))}
        ${c.updatedAt ? fact("Son Değişiklik", esc(HOF.formatDateTime(c.updatedAt))) : ""}
      </dl>
      ${posEventHtml(c.pos)}
      ${relations.length ? `<ul class="hof-bank-links">${relations.join("")}</ul>` : ""}
      ${toolbar}
      ${blocks.length ? `<ul class="hof-inv-blocks" data-bank-event-blocks>${blocks.map(([name, why]) => `<li><b>${esc(name)} kapalı:</b> ${esc(why)}</li>`).join("")}</ul>` : ""}
      <h4 class="hof-bank-subtitle">${c.linesSource === "voucher" ? "Fiş Satırları" : "Yevmiye Satırları"}</h4>
      ${lines}
      ${history ? `<h4 class="hof-bank-subtitle">İşlem Geçmişi</h4><ol class="hof-bank-history">${history}</ol>` : ""}
      </div>`;
  }

  // ---------- Fiş formları (masraf, faiz, diğer, kart borcu, kredi; Düzelt; Planlı İşlem) ----------
  const VOUCHER_GROUPS = {
    // Aşama 9: Bankalar Arası Transfer ayrı uçtan (POST /bank/transfers; Transfer Yapma yetkisi); Düzelt ve Planlı İşlem aynı formdan.
    transfer: { title: "Bankalar Arası Transfer", types: ["transfer"] },
    fee: { title: "Banka Masrafı", types: ["fee"] },
    interest: { title: "Faiz", types: ["interest_in", "interest_out"] },
    other: { title: "Diğer İşlem", types: ["other_in", "other_out", "card_payment", "loan_draw", "loan_repay"] },
  };
  const ALL_TYPES = ["fee", "interest_in", "interest_out", "other_in", "other_out", "card_payment", "loan_draw", "loan_repay", "transfer"];
  const TYPE_NAMES = { transfer: "Bankalar Arası Transfer", fee: "Banka Masrafı", interest_in: "Faiz Geliri", interest_out: "Faiz Gideri", other_in: "Diğer Gelir", other_out: "Diğer Gider", card_payment: "Kart Borcu Ödemesi", loan_draw: "Kredi Kullanımı", loan_repay: "Kredi Geri Ödemesi" };
  const mainKinds = type => (type === "interest_in" || type === "transfer" ? ["demand", "commercial", "other", "time"] : ["demand", "commercial", "other"]);
  // Sunucunun alan adı (HttpError field) → formdaki alan; alanı yazmayan hatalar koddan.
  const VOUCHER_FIELD = { toAccountId: "toAccountId", channel: "channel", valueDate: "valueDate", feeAmount: "feeAmount", Ücret: "feeAmount", feeTax: "feeTax", feeRate: "feeRate", amount: "amount", Tutar: "amount", "Stopaj Tutarı": "stoppageRate", stoppageAmount: "stoppageRate", "Stopaj Oranı": "stoppageRate", stoppageRate: "stoppageRate", "BSMV / KKDF": "taxAmount", taxAmount: "taxAmount", Faiz: "interestAmount", interestAmount: "interestAmount", "BSMV Oranı": "taxRate", "KDV Oranı": "taxRate", taxRate: "taxRate", vatRate: "taxRate", date: "date", plannedDate: "plannedDate", accountId: "accountId", cardAccountId: "cardAccountId", loanAccountId: "loanAccountId", feeType: "feeType", tax: "tax", gl: "gl", invoiceNo: "invoiceNo", "Fatura No": "invoiceNo", partyId: "partyId", type: "type", Açıklama: "description", Referans: "reference", repeat: "repeat" };
  const VOUCHER_CODE = { "bank-value-date": "valueDate", "bank-channel": "channel", "date-future": "date", "date-invalid": "date", "date-missing": "date", "period-locked": "date", "bank-before-opening": "date", "bank-fee-party": "partyId", "bank-party-missing": "partyId", "bank-fee-invoice": "invoiceNo", "invoice-duplicate": "invoiceNo", "bank-stoppage": "stoppageRate", "bank-gl-forbidden": "gl" };
  /** "1.234,56" / "1.000" / "10,5" → kuruş (yalnız önizleme; kural ve yuvarlama sunucuda). Geçersizse null. */
  function previewMinor(value) {
    let text = String(value ?? "").replace(/[\s₺]/g, "");
    if (!text) return null;
    if (text.includes(",")) text = text.replace(/\./g, "").replace(",", ".");
    else if (/^\d{1,3}(\.\d{3})+$/.test(text)) text = text.replace(/\./g, "");
    if (!/^\d+(\.\d{1,2})?$/.test(text)) return null;
    return Math.round(Number(text) * 100);
  }
  const previewPpm = value => {
    const text = String(value ?? "").trim().replace(",", ".");
    if (!text || !/^\d+(\.\d+)?$/.test(text)) return null;
    return Math.round(Number(text) * 10_000);
  };
  // round(a × b / c), yarım birim yukarı (sunucunun mulDiv'i gibi; BigInt).
  const mulDiv = (a, b, c) => Number((2n * BigInt(a) * BigInt(b) + BigInt(c)) / (2n * BigInt(c)));
  function activeTlAccounts() {
    return (view.list?.accounts || []).filter(account => account.status === "active" && account.currency === "TRY");
  }
  const accountOption = account => ({ value: account.id, label: `${account.bankName} · ${account.name} (${account.code})` });
  /**
   * Fiş formu. mode: create (yeni fiş), correct (Düzelt: tür değişmez, ön değerler İşlem Kartı'ndan), plan (+ Planlı İşlem; KDV'li masraf
   * planlanmaz). group: fee | interest | other. Benzer İşlem (409 bank-similar) → "Yine de Kaydet" aynı istek kimliğiyle similarOk:true.
   */
  async function voucherForm({ mode = "create", group = "fee", accountId = "", counterId = "", type = "", card = null } = {}) {
    // Aşama 9: bankalar arası transfer yalnız Transfer Yapma ister (§3.7 #11); Düzelt ve plan sunucudaki gibi Banka Hareketi Girme de ister.
    if (group === "transfer" && mode === "create") {
      if (!HOF.can("bank.transfer")) return HOF.toast("Bankalar arası transfer Transfer Yapma yetkisi ister.", { type: "error" });
    } else if (!HOF.can("bank.move")) return HOF.toast("Banka hareketi girmek Banka Hareketi Girme ve Bankadan Çıkış yetkisi ister.", { type: "error" });
    let meta;
    try {
      meta = await voucherMeta();
      view.meta = meta;
    } catch (error) {
      return HOF.toastError(error);
    }
    const accounts = activeTlAccounts();
    const cards = accounts.filter(account => account.kind === "card");
    const loans = accounts.filter(account => account.kind === "loan");
    let types = mode === "correct" ? [card.type] : mode === "plan" ? ALL_TYPES : VOUCHER_GROUPS[group].types;
    const transferable = accounts.filter(account => mainKinds("transfer").includes(account.kind));
    if (mode !== "correct") types = types.filter(item => (item !== "card_payment" || cards.length) && (!LOAN_KINDS.has(item) || (loans.length && HOF.can("bank.transfer"))) && (item !== "transfer" || (transferable.length > 1 && HOF.can("bank.transfer"))) && accounts.some(account => mainKinds(item).includes(account.kind)));
    if (!types.length) return HOF.toast(group === "transfer" ? "Transfer için en az iki etkin TL banka hesabı (Vadesiz, Ticari, Vadeli ya da Diğer) gerekir. Önce Hesaplar'dan hesap açın." : "Bu işlem için uygun, etkin bir TL banka hesabı yok. Önce Hesaplar'dan hesap açın.", { type: "error" });
    const form0 = mode === "correct" ? card.form || {} : {};
    const initialType = type && types.includes(type) ? type : form0.type || types[0];
    const canVat = mode !== "plan" && HOF.can("invoices.manage");
    const taxes = (meta.taxes || []).filter(item => !item.invoice || canVat);
    const defaultTax = taxes.some(item => item.key === (form0.tax || meta.defaults.tax)) ? form0.tax || meta.defaults.tax : taxes[0]?.key || "none";
    const requestId = HOF.requestId();
    const glLabel = code => `${code} · ${meta.glNames?.[code] || code}`;
    const fields = [
      types.length > 1 || mode === "correct" ? { name: "type", label: "İşlem Türü", type: "select", value: initialType, options: types.map(item => ({ value: item, label: TYPE_NAMES[item] || item })), readonly: mode === "correct", help: mode === "correct" ? "Düzelt'te işlemin türü değişmez; başka türde işlem için Ters Kaydet ile iptal edip yeni işlem girin." : "" } : null,
      { name: "accountId", label: "Banka Hesabı", type: "select", required: true, value: "", options: [] },
      { name: "toAccountId", label: "Alıcı Hesap", type: "select", value: form0.toAccountId || counterId || "", options: [] },
      { name: "cardAccountId", label: "Kredi Kartı", type: "select", value: form0.cardAccountId || counterId || cards[0]?.id || "", options: cards.map(accountOption) },
      { name: "loanAccountId", label: "Kredi Hesabı", type: "select", value: form0.loanAccountId || counterId || loans[0]?.id || "", options: loans.map(accountOption) },
      mode === "plan" ? { name: "plannedDate", label: "Planlı Tarih", type: "date", required: true, value: HOF.localToday(), help: "Planlı işlem deftere kendiliğinden yazılmaz; günü gelince Vadesi Gelen Planlı İşlemler'de görünür." } : { name: "date", label: "İşlem Tarihi", type: "date", required: true, max: "today", value: mode === "correct" ? (card.locked ? HOF.localToday() : card.date) : HOF.localToday() },
      mode === "plan" ? { name: "repeat", label: "Tekrar", type: "select", value: "none", options: (meta.repeats || []).map(item => ({ value: item.key, label: item.label })) } : null,
      mode === "plan" ? null : { name: "valueDate", label: "Valör", type: "date", value: form0.valueDate || "", help: `Paranın alıcı hesaba geçtiği gün (EFT mesai dışında ertesi iş günü); boşsa işlem tarihi. En çok ${meta.valueDateMaxDays || 30} gün sonra.` },
      { name: "channel", label: "Kanal", type: "select", value: form0.channel || "", options: [{ value: "", label: "Belirtilmedi" }, ...(meta.channels || []).map(item => ({ value: item.key, label: item.label }))] },
      { name: "feeType", label: "Masraf Türü", type: "select", value: form0.feeType || (meta.feeTypes || []).find(item => item.key === "eft")?.key || meta.feeTypes?.[0]?.key || "", options: (meta.feeTypes || []).map(item => ({ value: item.key, label: `${item.name} (${item.gl})` })) },
      { name: "tax", label: "Vergi", type: "select", value: defaultTax, options: taxes.map(item => ({ value: item.key, label: item.label })) },
      { name: "taxRate", label: "BSMV Oranı (%)", value: form0.taxRate || "", inputmode: "decimal" },
      { name: "invoiceNo", label: "Fatura No", value: form0.invoiceNo || "", maxlength: 40, placeholder: "Bankanın kestiği masraf faturasının numarası" },
      { name: "amount", label: "Tutar", required: true, value: form0.amount || "", inputmode: "decimal", placeholder: "ör. 1.250,00" },
      { name: "feeAmount", label: "Ücret", value: form0.feeAmount && form0.feeAmount !== "0" && form0.feeAmount !== "0,00" ? form0.feeAmount : "", inputmode: "decimal", placeholder: "Bankanın kestiği EFT / havale ücreti; yoksa boş", help: "Ücret gönderen hesaptan ayrıca düşer ve Banka Masrafları'na (770) yazılır." },
      { name: "feeTax", label: "Ücret Vergisi", type: "select", value: form0.feeTax || meta.transferFeeTax || "bsmv_incl", options: (meta.transferFeeTaxes || []).map(item => ({ value: item.key, label: item.label })) },
      { name: "feeRate", label: "BSMV Oranı (%)", value: form0.feeRate || "", inputmode: "decimal", placeholder: "5" },
      { name: "stoppageRate", label: "Stopaj Oranı (%)", value: mode === "correct" ? form0.stoppageRate || "" : meta.defaults?.stoppageRate || "", inputmode: "decimal", help: "Bankanın kestiği mevduat stopajı; son kullanılan oran önerilir." },
      { name: "taxAmount", label: "BSMV / KKDF Tutarı", value: form0.taxAmount && form0.taxAmount !== "0,00" ? form0.taxAmount : "", inputmode: "decimal" },
      { name: "interestAmount", label: "Faiz Tutarı", value: form0.interestAmount && form0.interestAmount !== "0,00" ? form0.interestAmount : "", inputmode: "decimal" },
      { name: "description", label: "Açıklama", value: form0.description || "", maxlength: 500 },
      { name: "reference", label: "Referans", value: form0.reference || "", maxlength: 100, placeholder: "Dekont ya da talimat no" },
    ].filter(Boolean);
    const hiddenType = types.length === 1 && mode !== "correct" ? `<input type="hidden" name="type" value="${esc(initialType)}">` : "";
    const extraHtml = `${hiddenType}<details class="hof-bank-adv" data-adv><summary>Gelişmiş Seçenekler</summary><div class="hof-bank-adv-body">${HOF.fieldHtml({ name: "gl", label: "Gelir Hesabı", type: "select", value: form0.gl || "", options: [] })}<p class="hof-rep-note" data-gl-note></p></div></details><p class="hof-bank-preview-line" data-voucher-preview aria-live="polite"></p>`;
    let formNode = null;
    let picker = null;
    const rateTouched = { value: Boolean(form0.taxRate) };
    HOF.formModal({
      title: mode === "correct" ? "İşlemi Düzelt" : mode === "plan" ? "Planlı İşlem" : VOUCHER_GROUPS[group].title,
      eyebrow: mode === "correct" ? card.no : moduleName().toLocaleUpperCase("tr-TR"),
      intro: mode === "correct" ? `${card.no} ters kaydedilir ve düzeltilmiş hâliyle yeni işlem yazılır (tek işlemde); ikisi de hareketlerde ve İşlem Geçmişi'nde kalır.${card.locked ? " Asıl işlem kilitli dönemde; ters kaydı bugün tarihli yazılır." : ""}` : mode === "plan" ? "Kira, kredi taksiti, kart borcu ya da masraf talimatı gibi tekrar eden işlemleri planlayın. Planlı işlem bakiyeyi değiştirmez; bankada gerçekleşince “Gerçekleştir” ile kaydedilir." : "",
      size: "wide",
      fields,
      extraHtml,
      submitLabel: mode === "correct" ? "Düzelt ve Kaydet" : mode === "plan" ? "Planla" : "Kaydet",
      onOpen: dialog => {
        formNode = dialog.querySelector("form");
        formNode.classList.add("hof-bank-form", "hof-bank-voucher");
        const field = name => formNode.querySelector(`[name="${name}"]`);
        if (mode === "correct") field("type")?.setAttribute("disabled", "");
        // Faturayı kesen cari (KDV'li masraf): Cari seçicisi (Fatura formundaki gibi "+ Yeni Cari" ile).
        const invoiceField = field("invoiceNo")?.closest(".hof-field");
        if (invoiceField) {
          picker = HOF.can("accounts.view") && HOF.accounts?.picker ? HOF.accounts.picker({ name: "partyId", label: "Faturayı Kesen (Cari)", required: true, prefer: "supplier", allowNew: { type: "supplier" }, value: form0.partyId ? { id: form0.partyId, name: card?.party?.name || "" } : {}, help: "Masraf faturasını kesen banka ya da ödeme kuruluşu." }) : null;
          if (picker) invoiceField.before(picker);
          else invoiceField.insertAdjacentHTML("beforebegin", '<p class="hof-rep-note" data-party-note>Faturalı masrafta cari seçmek için Carileri Görme yetkisi gerekir.</p>');
        }
        const target = field("toAccountId");
        if (target) target.dataset.initial = form0.toAccountId || counterId || "";
        // Transfer formunda alan sırası: Tutar → Ücret → Ücret Vergisi → Ücret Türü → BSMV Oranı (masraf formunda Masraf Türü baştadır).
        const feeTaxBox = field("feeTax")?.closest(".hof-field");
        const feeTypeBox = field("feeType")?.closest(".hof-field");
        if (initialType === "transfer" && feeTaxBox && feeTypeBox) feeTaxBox.after(feeTypeBox);
        wireVoucher(formNode, { meta, accounts, initialType, accountId: accountId || form0.accountId || "", defaultTax, rateTouched, glLabel, picker, mode });
      },
      onSubmit: async data => {
        const kind = data.type || initialType;
        const body = { type: kind, accountId: data.accountId, amount: data.amount, description: data.description, reference: data.reference };
        if (mode === "plan") Object.assign(body, { kind, plannedDate: data.plannedDate, repeat: data.repeat });
        else body.date = data.date;
        if (kind === "fee") {
          Object.assign(body, { feeType: data.feeType, tax: data.tax });
          if (data.tax !== "none" && String(data.taxRate || "").trim()) body.taxRate = data.taxRate;
          if (isVat(data.tax)) Object.assign(body, { partyId: data.partyId || "", invoiceNo: data.invoiceNo });
        }
        if (kind === "interest_in" && String(data.stoppageRate || "").trim()) body.stoppageRate = data.stoppageRate;
        if (kind === "interest_out") body.taxAmount = String(data.taxAmount || "").trim() || "0";
        if (kind === "loan_repay") body.interestAmount = String(data.interestAmount || "").trim() || "0";
        if (kind === "other_in" || kind === "other_out") body.gl = data.gl;
        if (kind === "card_payment") body.cardAccountId = data.cardAccountId;
        if (LOAN_KINDS.has(kind)) body.loanAccountId = data.loanAccountId;
        if (kind === "transfer") {
          Object.assign(body, { toAccountId: data.toAccountId, channel: data.channel || "" });
          if (mode !== "plan" && String(data.valueDate || "").trim()) body.valueDate = data.valueDate;
          const fee = String(data.feeAmount || "").trim();
          body.feeAmount = fee || "0";
          if (fee) Object.assign(body, { feeTax: data.feeTax, feeType: data.feeType, ...(data.feeTax !== "none" && String(data.feeRate || "").trim() ? { feeRate: data.feeRate } : {}) });
        }
        try {
          if (kind === "fee" && isVat(data.tax) && !body.partyId) throw new HOF.ApiError("Faturalı masrafta faturayı kesen cariyi seçin.", 400, { code: "bank-fee-party", field: "partyId" });
          const send = flags => {
            const payload = { ...body, ...flags };
            if (mode === "plan") return api("/plans", { method: "POST", body: payload });
            if (mode === "correct") return api(`/events/${encodeURIComponent(card.id)}/correct`, { method: "POST", body: payload, requestId });
            return api(kind === "transfer" ? "/transfers" : "/vouchers", { method: "POST", body: payload, requestId });
          };
          const result = await withConfirms(send);
          afterWrite();
          if (mode === "plan") {
            HOF.toast("Planlı işlem eklendi. Bakiye değişmedi; bankada gerçekleşince “Gerçekleştir” ile kaydedin.", { type: "success" });
            openMovements({ account: moves.filter.account, planned: true });
          } else if (mode === "correct") {
            HOF.toast(result.replayed ? "Bu düzeltme zaten kaydedildi; ikinci kez yazılmadı." : `Düzeltildi: ${card.no} ters kaydedildi, yeni işlem ${result.next?.no || ""}.`, { type: "success" });
            if (result.next?.id) openEvent(result.next.id);
          } else {
            HOF.toast(result.replayed ? `Bu işlem zaten kaydedildi (${result.no}); ikinci kez yazılmadı.` : `Kaydedildi: ${result.no} · ${result.typeLabel} ${fmt(eventAmount(result))}`, { type: "success" });
            await reload();
          }
        } catch (error) {
          markVoucherField(formNode, error, mode);
          throw error;
        }
      },
    });
  }
  /** Benzer İşlem (409 bank-similar): önceki işlemin İşlem No'su ve gireniyle sorar; "Yine de Kaydet" aynı istek kimliğiyle similarOk. */
  /**
   * Benzer İşlem (409 bank-similar) ve banka hesabının eksi bakiye uyarısı (409 cash-negative + accountId, K7; GG2; hakem K5) aynı kalıpla
   * sorulur: "Yine de Kaydet" aynı istek kimliğiyle similarOk / negativeOk (sunucuda cashForce'un eşanlamlısı) gönderir. Engelle (409
   * cash-blocked + accountId) sorulmaz, nedeni formda görünür. send(flags) gövdeye flags'i ekler.
   */
  // Yargıç (2.1.0): soru ve "Vazgeç" bildirimi işlemin adıyla (İptal Et / Sil / Geri Yükle); Vazgeç kırmızı hata değil, bilgi (2.0.26 İ6 kalıbı).
  const CONFIRM_VERBS = {
    save: { yes: "Yine de Kaydet", no: "Kaydedilmedi", ask: "Yine de kaydedilsin mi?" },
    cancel: { yes: "Yine de İptal Et", no: "İptal edilmedi", ask: "Yine de iptal edilsin mi?" },
    delete: { yes: "Yine de Sil", no: "Silinmedi", ask: "Yine de silinsin mi?" },
    restore: { yes: "Yine de Geri Yükle", no: "Geri yüklenmedi", ask: "Yine de geri yüklensin mi?" },
  };
  async function withConfirms(send, { verb = "save" } = {}) {
    const words = CONFIRM_VERBS[verb] || CONFIRM_VERBS.save;
    const flags = {};
    for (let round = 0; round < 3; round += 1) {
      try {
        return await send({ ...flags });
      } catch (error) {
        const code = error?.data?.code;
        if (code === "bank-similar" && !flags.similarOk) {
          const go = await HOF.confirm({ title: "Benzer İşlem", message: error.message, confirmLabel: "Yine de Kaydet", cancelLabel: "Vazgeç" });
          if (!go) throw new HOF.ApiError("Kaydedilmedi: aynı gün aynı tutarda benzer işlem kayıtlı. Gerçekten ikinci bir işlemse yeniden kaydedip “Yine de Kaydet”i seçin.", 409, { code: "bank-similar-cancelled" });
          flags.similarOk = true;
          continue;
        }
        // Hakem K5 (plan §7): banka hesabının eksi bakiye reddi cash-negative + accountId (Kasa'nınki accountId'siz; onu HOF.api sorar).
        if (code === "cash-negative" && error?.data?.accountId && !flags.negativeOk) {
          const go = await HOF.confirm({ title: "Eksi Bakiye", message: String(error.message || "").replace(/Yine de kaydedilsin mi\?\s*$/, words.ask), confirmLabel: words.yes, cancelLabel: "Vazgeç" });
          if (!go) throw new HOF.ApiError(`${words.no}: işlem hesabın bakiyesini eksiye düşürüyor.`, 409, { code: "bank-negative-cancelled", field: "amount" });
          flags.negativeOk = true;
          continue;
        }
        throw error;
      }
    }
    throw new HOF.ApiError("Kaydedilemedi; yeniden deneyin.", 409, {});
  }
  function markVoucherField(form, error, mode) {
    if (!form) return;
    form.querySelectorAll(".is-invalid").forEach(node => {
      node.classList.remove("is-invalid");
      node.removeAttribute("aria-invalid");
    });
    let name = VOUCHER_FIELD[error?.data?.field] || VOUCHER_CODE[error?.data?.code] || "";
    if (name === "date" && mode === "plan") name = "plannedDate";
    const node = name === "partyId" ? form.querySelector("[data-acc-query]") : name ? form.querySelector(`[name="${name}"]`) : null;
    if (!node) return;
    node.classList.add("is-invalid");
    node.setAttribute("aria-invalid", "true");
    node.closest("details")?.setAttribute("open", "");
    node.closest(".hof-field")?.removeAttribute("hidden");
    node.focus?.();
  }
  /** Türe ve vergiye göre alanları açar/kapatır, hesap listesini kurar, önizlemeyi günceller (yalnız gösterir; kural sunucuda). */
  function wireVoucher(form, { meta, accounts, initialType, accountId, defaultTax, rateTouched, glLabel, picker, mode }) {
    const field = name => form.querySelector(`[name="${name}"]`);
    const show = (name, visible) => {
      const node = name === "partyId" ? picker || form.querySelector("[data-party-note]") : field(name)?.closest(".hof-field");
      if (node) node.hidden = !visible;
    };
    const label = (name, text) => {
      const span = field(name)?.closest(".hof-field")?.querySelector(":scope > span");
      if (span && span.firstChild) span.firstChild.textContent = `${text}${/\s$/.test(span.firstChild.textContent) ? " " : ""}`;
    };
    const typeNow = () => field("type")?.value || initialType;
    let lastType = "";
    // Aşama 9: alıcı hesap listesi gönderen dışındaki transfer hesaplarıdır (aynı hesaba transfer seçilemez; sunucu da 400 verir).
    const syncTarget = () => {
      const target = field("toAccountId");
      if (!target) return;
      const from = field("accountId")?.value || "";
      const allowed = accounts.filter(account => mainKinds("transfer").includes(account.kind) && account.id !== from);
      const current = target.value || target.dataset.initial || "";
      const pick = allowed.find(account => account.id === current) || allowed[0];
      target.innerHTML = allowed.map(account => `<option value="${esc(account.id)}" ${account.id === pick?.id ? "selected" : ""}>${esc(accountOption(account).label)}</option>`).join("");
    };
    const sync = () => {
      const kind = typeNow();
      const select = field("accountId");
      if (select && kind !== lastType) {
        const allowed = accounts.filter(account => mainKinds(kind).includes(account.kind));
        const current = select.value || accountId;
        const pick = allowed.find(account => account.id === current) || allowed.find(account => account.kind === "demand") || allowed[0];
        select.innerHTML = allowed.map(account => `<option value="${esc(account.id)}" ${account.id === pick?.id ? "selected" : ""}>${esc(accountOption(account).label)}</option>`).join("");
        const gl = field("gl");
        const options = kind === "other_in" ? meta.gl?.income || [] : kind === "other_out" ? meta.gl?.expense || [] : [];
        if (gl) {
          const wanted = gl.value || (kind === "other_in" ? meta.defaults.otherIncome : meta.defaults.otherExpense);
          gl.innerHTML = options.map(code => `<option value="${esc(code)}" ${code === wanted ? "selected" : ""}>${esc(glLabel(code))}</option>`).join("");
          if (!options.includes(gl.value)) gl.value = kind === "other_in" ? meta.defaults.otherIncome : meta.defaults.otherExpense;
        }
        lastType = kind;
      }
      const transfer = kind === "transfer";
      if (transfer) syncTarget();
      label("accountId", transfer ? "Gönderen Hesap" : "Banka Hesabı");
      show("toAccountId", transfer);
      show("channel", transfer);
      show("valueDate", transfer);
      show("feeAmount", transfer);
      const transferFee = transfer && previewMinor(field("feeAmount")?.value) > 0;
      show("feeTax", transferFee);
      show("feeRate", transferFee && field("feeTax")?.value !== "none");
      show("cardAccountId", kind === "card_payment");
      show("loanAccountId", LOAN_KINDS.has(kind));
      const fee = kind === "fee";
      show("feeType", fee || transferFee);
      label("feeType", transfer ? "Ücret Türü" : "Masraf Türü");
      show("tax", fee);
      const tax = field("tax")?.value || defaultTax;
      const vat = fee && isVat(tax);
      show("taxRate", fee && tax !== "none");
      label("taxRate", vat ? "KDV Oranı (%)" : "BSMV Oranı (%)");
      if (!rateTouched.value && field("taxRate")) field("taxRate").value = vat ? meta.defaults.vatRate || "20" : meta.defaults.bsmvRate || "5";
      show("partyId", vat);
      show("invoiceNo", vat);
      show("stoppageRate", kind === "interest_in");
      show("taxAmount", kind === "interest_out");
      show("interestAmount", kind === "loan_repay");
      label("amount", fee ? (tax === "none" ? "Tutar" : tax.endsWith("_excl") ? "Tutar (Vergi Hariç)" : "Tutar (Vergi Dahil)") : kind === "interest_in" ? "Brüt Faiz" : kind === "interest_out" ? "Faiz Tutarı" : kind === "loan_repay" ? "Anapara" : transfer ? "Tutar (Alıcıya Giren)" : "Tutar");
      if (transfer) label("feeAmount", field("feeTax")?.value === "bsmv_excl" ? "Ücret (BSMV Hariç)" : field("feeTax")?.value === "none" ? "Ücret" : "Ücret (BSMV Dahil)");
      const glNode = field("gl")?.closest(".hof-field");
      if (glNode) glNode.hidden = !(kind === "other_in" || kind === "other_out");
      label("gl", kind === "other_in" ? "Gelir Hesabı" : "Gider Hesabı");
      const note = form.querySelector("[data-gl-note]");
      if (note) {
        const feeType = (meta.feeTypes || []).find(item => item.key === field("feeType")?.value);
        const code = fee ? (feeType?.gl === "653" ? meta.defaults.commission : meta.defaults.fee) : kind === "interest_in" ? meta.defaults.interestIncome : kind === "interest_out" || kind === "loan_repay" ? meta.defaults.interestExpense : "";
        note.textContent = transfer ? `Şirketin kendi hesapları arasında: gelir ya da gider hesabı yoktur; ücret ${glLabel(meta.defaults.fee)} hesabına yazılır.` : code ? `Hesap: ${glLabel(code)} (Banka Ayarları → Hesap Eşlemeleri).${kind === "interest_in" ? " Stopaj 193 Peşin Ödenen Vergiler ve Fonlar." : ""}` : kind === "card_payment" || TRANSFER_KINDS.has(kind) ? "Şirketin kendi hesapları arasında: gelir ya da gider hesabı yoktur." : "Gelir ve gider hesabı yalnız Banka Ayarları'ndaki izinli hesaplardan seçilir.";
      }
      preview();
    };
    // 2.4.3 (C3): hesapların bakiye satırı (öbür seçicilerdeki "Bakiye (gün) · İşlemden Sonra"; HOF.bank.balanceLine, K7 kuralı ekranda). Etki
    // önizlemeyle aynı hesaptan: masrafta Bankadan Çıkan, transferde gönderenden tutar + ücret çıkar ve alıcıya tutar girer, kart borcu ödemesinde
    // kart borcu azalır. Düzelt'te yalnız bakiye (eski işlem bakiyede; fark sunucuda), Planlı İşlem'de satır yok (bakiye değişmez).
    // Bakiye yalnız Banka Görüntüleme yetkisine gelir (choices.balances); gelmezse satır yok.
    let balanceData = null;
    let effect = {};
    const BALANCE_FIELDS = ["accountId", "toAccountId", "cardAccountId"];
    const syncBalanceLines = () => {
      for (const name of ["accountId", "toAccountId", "cardAccountId", "loanAccountId"]) {
        const select = field(name);
        if (select) select.title = select.selectedOptions?.[0]?.textContent.trim() || "";
      }
      for (const name of BALANCE_FIELDS) {
        const box = field(name)?.closest(".hof-field");
        const slot = box?.nextElementSibling?.matches?.("[data-balance-slot]") ? box.nextElementSibling : null;
        if (!slot) continue;
        const visible = Boolean(balanceData?.balances) && !box.hidden && mode !== "plan";
        slot.hidden = !visible;
        swapLine(slot, "[data-bank-balance]", visible ? balanceLine(balanceData, field(name).value, mode === "correct" ? { only: true } : { change: effect[name] || 0 }) : "");
      }
    };
    // 2.4.3 (C12): hesap seçicileri satırın tamamını kaplar (uzun banka ve hesap adı kesilmez; "Türkiye Vakıflar Bankası T.A.O. · Kurumsal …").
    for (const name of ["accountId", "toAccountId", "cardAccountId", "loanAccountId"]) field(name)?.closest(".hof-field")?.classList.add("hof-bank-wide-field");
    if (mode !== "plan") {
      for (const name of BALANCE_FIELDS) field(name)?.closest(".hof-field")?.insertAdjacentHTML("afterend", `<div class="hof-bank-balance-slot" data-balance-slot="${name}" hidden></div>`);
      choices(true, field("date")?.value || "")
        .then(data => {
          if (!form.isConnected) return;
          balanceData = data;
          syncBalanceLines();
        })
        .catch(() => null);
      let balanceSeq = 0;
      field("date")?.addEventListener("change", async () => {
        if (!balanceData?.balances) return;
        const seq = (balanceSeq += 1);
        const fresh = await balances(field("date")?.value || "");
        if (seq !== balanceSeq || !form.isConnected || !fresh.balances) return;
        balanceData = { ...balanceData, balances: fresh.balances };
        syncBalanceLines();
      });
    }
    const preview = () => {
      const node = form.querySelector("[data-voucher-preview]");
      if (!node) return;
      effect = {};
      const kind = typeNow();
      const amount = previewMinor(field("amount")?.value);
      if (amount === null) {
        syncBalanceLines();
        return (node.textContent = "");
      }
      const tax = field("tax")?.value || defaultTax;
      const parts = [];
      if (kind === "transfer") {
        const feeIn = previewMinor(field("feeAmount")?.value) || 0;
        const feeTax = field("feeTax")?.value || "none";
        const ppm = previewPpm(field("feeRate")?.value) ?? previewPpm(meta.defaults.bsmvRate) ?? 50_000;
        let base = feeIn;
        let taxMinor = 0;
        if (feeIn && feeTax === "bsmv_incl") {
          base = mulDiv(feeIn, 1_000_000, 1_000_000 + ppm);
          taxMinor = feeIn - base;
        } else if (feeIn && feeTax === "bsmv_excl") taxMinor = mulDiv(feeIn, ppm, 1_000_000);
        const feeTotal = base + taxMinor;
        parts.push(`Alıcıya Giren ${fmt(amount)}`);
        if (feeTotal) parts.push(`Ücret ${fmt(feeTotal)}${taxMinor ? ` (${fmt(base)} + BSMV ${fmt(taxMinor)})` : ""}`);
        parts.push(`Gönderenden Çıkan ${fmt(amount + feeTotal)}`);
        effect = { accountId: -(amount + feeTotal), toAccountId: amount };
        node.textContent = parts.join(" · ");
        return syncBalanceLines();
      }
      if (kind === "fee") {
        const feeType = (meta.feeTypes || []).find(item => item.key === field("feeType")?.value);
        const gl = feeType?.gl === "653" ? meta.defaults.commission : meta.defaults.fee;
        const ppm = previewPpm(field("taxRate")?.value) ?? previewPpm(isVat(tax) ? meta.defaults.vatRate : meta.defaults.bsmvRate) ?? 0;
        let base = amount;
        let taxMinor = 0;
        if (tax.endsWith("_incl")) {
          base = mulDiv(amount, 1_000_000, 1_000_000 + ppm);
          taxMinor = amount - base;
        } else if (tax.endsWith("_excl")) taxMinor = mulDiv(amount, ppm, 1_000_000);
        effect = { accountId: -(base + taxMinor) };
        if (isVat(tax)) parts.push(`Matrah ${fmt(base)}`, `KDV ${fmt(taxMinor)}`, `Bankadan Çıkan ${fmt(base + taxMinor)}`, "Hizmet ve Gider Alışı faturası kaydedilir");
        else parts.push(`Gider ${fmt(base)}`, ...(taxMinor ? [`BSMV ${fmt(taxMinor)}`] : []), `Bankadan Çıkan ${fmt(base + taxMinor)}`, `Hesap ${glLabel(gl)}`);
      } else if (kind === "interest_in") {
        const ppm = previewPpm(field("stoppageRate")?.value) ?? 0;
        const stoppage = mulDiv(amount, ppm, 1_000_000);
        effect = { accountId: amount - stoppage };
        parts.push(`Bankaya Giren (Net) ${fmt(amount - stoppage)}`, `Stopaj ${fmt(stoppage)} (193)`, `Faiz Geliri ${fmt(amount)}`);
      } else if (kind === "interest_out") {
        const extra = previewMinor(field("taxAmount")?.value) || 0;
        effect = { accountId: -(amount + extra) };
        parts.push(`Bankadan Çıkan ${fmt(amount + extra)}`, `Faiz ${fmt(amount)}`, ...(extra ? [`BSMV / KKDF ${fmt(extra)}`] : []));
      } else if (kind === "loan_repay") {
        const interest = previewMinor(field("interestAmount")?.value) || 0;
        effect = { accountId: -(amount + interest) };
        parts.push(`Bankadan Çıkan ${fmt(amount + interest)}`, `Anapara ${fmt(amount)}`, ...(interest ? [`Faiz ${fmt(interest)}`] : []));
      } else if (kind === "card_payment") {
        // Kart hesabının bakiyesi borçtur (eksi): ödeme borcu azaltır (+).
        effect = { accountId: -amount, cardAccountId: amount };
        parts.push(`Bankadan Çıkan ${fmt(amount)}`, "Kart borcu azalır");
      } else if (kind === "loan_draw") {
        effect = { accountId: amount };
        parts.push(`Bankaya Giren ${fmt(amount)}`, "Kredi borcu artar");
      } else {
        effect = { accountId: kind === "other_in" ? amount : -amount };
        parts.push(`${kind === "other_in" ? "Bankaya Giren" : "Bankadan Çıkan"} ${fmt(amount)}`, `Hesap ${glLabel(field("gl")?.value || "")}`);
      }
      node.textContent = parts.join(" · ");
      syncBalanceLines();
    };
    // Vergi kipi BSMV ↔ KDV değişince oran o kipin varsayılanına döner (Düzelt'te BSMV %5'in KDV'ye taşınmaması için).
    let lastVat = isVat(field("tax")?.value || defaultTax);
    // v2.2.0 (İz 2.3): Kart Borcu Ödemesi'nde ödeyen hesap kartın bağlı olduğu banka hesabıyla dolu gelir (kullanıcı hesabı kendisi
    // değiştirmediyse; Düzelt'te asıl işlemin hesabı korunur). Bağlı banka pasif ya da seçilemiyorsa önceki varsayılan kalır.
    let payerTouched = mode === "correct";
    const syncPayer = () => {
      if (typeNow() !== "card_payment" || payerTouched) return;
      const card = accounts.find(account => account.id === field("cardAccountId")?.value);
      const select = field("accountId");
      if (card?.parentId && select && [...select.options].some(option => option.value === card.parentId)) select.value = card.parentId;
    };
    form.addEventListener("change", event => {
      if (event.target.matches?.('[name="accountId"]')) payerTouched = true;
      if (event.target.matches?.('[name="taxRate"]')) rateTouched.value = true;
      if (event.target.matches?.('[name="tax"]')) {
        const vatNow = isVat(event.target.value);
        if (vatNow !== lastVat) rateTouched.value = false;
        lastVat = vatNow;
      }
      sync();
      if (event.target.matches?.('[name="cardAccountId"], [name="type"]')) syncPayer();
    });
    form.addEventListener("input", event => {
      if (event.target.matches?.('[name="taxRate"]')) rateTouched.value = true;
      // Ücret yazılınca vergi ve tür alanları açılır (Aşama 9).
      if (event.target.matches?.('[name="feeAmount"]')) return sync();
      preview();
    });
    // Salt okunur açılır liste (Düzelt'te işlem türü): değer değişmesin.
    for (const select of form.querySelectorAll("select[readonly]")) {
      const value = select.value;
      select.addEventListener("change", () => (select.value = value));
    }
    void mode;
    sync();
    syncPayer();
  }
  /** Yerel yazımdan sonra: form seçenekleri (son stopaj oranı) ve menü rozeti yenilenir. */
  function afterWrite() {
    metaCache = null;
    HOF.emit("bank-changed");
  }
  function reverseForm(c) {
    const feeHeader = c.fee?.taxKind === "vat" && !c.source;
    const requestId = HOF.requestId();
    // GG2: kullanıcı verisi (Fatura No, hesap adı) kaçışlı; intro HTML olarak basılır.
    const parts = [`${esc(c.no)} (${esc(c.typeLabel)}, ${esc(fmt(eventAmount(c)))}) ters kaydedilir: aynı tutarda ters fiş yazılır, hesabın bakiyesi işlemden önceki hâline döner. İşlem silinmez; asıl işlem ve ters kaydı hareketlerde ve İşlem Geçmişi'nde kalır.`];
    if (feeHeader && c.locked) parts.push(`Masrafın faturası (${esc(c.invoice?.number || "")}) kilitli dönemde (${esc(dateText(c.lockedUntil))} ve öncesi) olduğu için iptal edilmez: bugün (${esc(dateText(HOF.localToday()))}) tarihli Alıştan İade faturası kesilir ve tutar bu hesaba iade girişi olarak yazılır; kilitli dönem değişmez.`);
    else if (feeHeader) parts.push(`Masrafın faturası (${esc(c.invoice?.number || "")}) iptal edilir; KDV ve cari etkisi de geri alınır.`);
    else if (c.locked) parts.push(`İşlem kilitli dönemde (${esc(dateText(c.lockedUntil))} ve öncesi); ters fiş bugün (${esc(dateText(HOF.localToday()))}) tarihli yazılır, kilitli dönem değişmez.`);
    HOF.formModal({
      title: "Ters Kaydet",
      eyebrow: c.no,
      intro: parts.join(" "),
      fields: [{ name: "reason", label: "Neden", maxlength: 300, placeholder: "İsteğe bağlı; İşlem Geçmişi'ne yazılır" }],
      submitLabel: "Ters Kaydet",
      onSubmit: async data => {
        const result = await withConfirms(flags => api(`/events/${encodeURIComponent(c.id)}/reverse`, { method: "POST", body: { reason: data.reason, ...flags }, requestId }));
        afterWrite();
        HOF.toast(result.replayed ? "Bu işlem zaten ters kaydedilmişti; ikinci kez yazılmadı." : result.reversal?.invoice?.kind === "purchase_return" ? `Ters kaydedildi: ${result.reversal.no} · İade Faturası ${result.reversal.invoice.number}` : result.reversal ? `Ters kaydedildi: ${result.reversal.no}` : `Masraf ve faturası iptal edildi (${c.no}).`, { type: "success" });
        await reload();
      },
    });
  }
  function infoForm(c) {
    HOF.formModal({
      title: "Açıklamayı Düzelt",
      eyebrow: c.no,
      intro: "Açıklama ve referans tutarı değiştirmez; kilitli dönemdeki işlemde de düzeltilir ve İşlem Geçmişi'ne yazılır.",
      fields: [
        { name: "description", label: "Açıklama", type: "textarea", rows: 3, value: c.description || "", maxlength: 500 },
        { name: "reference", label: "Referans", value: c.reference || "", maxlength: 100 },
      ],
      submitLabel: "Kaydet",
      onSubmit: async data => {
        await api(`/events/${encodeURIComponent(c.id)}/info`, { method: "PUT", body: { description: data.description, reference: data.reference } });
        HOF.toast("Açıklama kaydedildi.", { type: "success" });
        await reload();
      },
    });
  }

  // ---------- Planlı İşlemler (K3; §3.7 #23) ----------
  const planOf = id => moves.plans.find(plan => plan.id === id) || null;
  function planRunForm(plan) {
    const today = HOF.localToday();
    const requestId = HOF.requestId();
    HOF.formModal({
      title: "Planlı İşlemi Gerçekleştir",
      eyebrow: plan.typeLabel.toLocaleUpperCase("tr-TR"),
      intro: `${esc(plan.accountLabel)}${plan.toAccountLabel ? ` → ${esc(plan.toAccountLabel)}` : ""} · ${esc(fmt(plan.amountMinor))} · planlı tarih ${esc(dateText(plan.plannedDate))}. Bankada gerçekleşen tarih ve tutarla kaydedin.${plan.repeat !== "none" ? " Plan bir sonraki döneme geçer." : ""}`,
      fields: [
        { name: "date", label: "İşlem Tarihi", type: "date", required: true, max: "today", value: plan.plannedDate <= today ? plan.plannedDate : today },
        { name: "amount", label: "Tutar", required: true, value: amountInput(plan.amountMinor), inputmode: "decimal" },
        { name: "description", label: "Açıklama", value: plan.description || "", maxlength: 500 },
      ],
      submitLabel: "Gerçekleştir",
      onSubmit: async data => {
        // expectedDate (GG2): ekrandaki planlı tarih; plan bu arada ilerlediyse sunucu 409 bank-plan-moved verir (ikinci kez işlenmez).
        const result = await withConfirms(flags => api(`/plans/${encodeURIComponent(plan.id)}/execute`, { method: "POST", body: { date: data.date, amount: data.amount, description: data.description, expectedDate: plan.plannedDate, ...flags }, requestId }));
        afterWrite();
        HOF.toast(result.replayed ? "Bu planlı işlem zaten gerçekleştirildi; ikinci kez yazılmadı." : `Gerçekleştirildi: ${result.event?.no || ""}${result.plan?.status === "planned" ? ` · sonraki ${dateText(result.plan.plannedDate)}` : ""}`, { type: "success" });
        await reload();
      },
    });
  }
  /**
   * Atla (GG2): satırın düğmeleri istek bitene kadar pasif (çift tık ikinci isteği göndermez); ekranda görülen planlı tarih (expectedDate)
   * gönderilir — plan bu arada ilerlediyse (başka pencere) sunucu 409 bank-plan-moved verir, liste yenilenir.
   */
  async function planSkip(plan, button = null) {
    const row = button?.closest("tr") || null;
    const buttons = row ? [...row.querySelectorAll("button[data-act]")] : button ? [button] : [];
    if (buttons.some(node => node.disabled)) return;
    buttons.forEach(node => {
      node.disabled = true;
      node.setAttribute("aria-busy", "true");
    });
    try {
      const next = await api(`/plans/${encodeURIComponent(plan.id)}/skip`, { method: "POST", body: { expectedDate: plan.plannedDate } });
      afterWrite();
      HOF.toast(`Bu dönem atlandı; sonraki tarih ${dateText(next.plannedDate)}.`, { type: "success" });
    } catch (error) {
      HOF.toastError(error);
    } finally {
      buttons.forEach(node => {
        node.disabled = false;
        node.removeAttribute("aria-busy");
      });
    }
    await reload();
  }
  async function planCancel(plan) {
    const go = await HOF.confirm({ title: "Planlı İşlemi Sil", message: `${plan.typeLabel} · ${fmt(plan.amountMinor)} (${dateText(plan.plannedDate)}) planı silinsin mi? Bu plandan daha önce gerçekleşmiş işlemler değişmez.`, confirmLabel: "Sil", danger: true });
    if (!go) return;
    try {
      await api(`/plans/${encodeURIComponent(plan.id)}`, { method: "DELETE" });
      afterWrite();
      HOF.toast("Planlı işlem silindi.", { type: "success" });
      await reload();
    } catch (error) {
      HOF.toastError(error);
    }
  }

  // ---------- Olaylar ----------
  function onClick(event) {
    const tab = event.target.closest("[data-tab]")?.dataset.tab;
    if (tab && event.target.closest(".hof-bank-tabs")) {
      if (view.dirty && view.tab === "settings" && tab !== "settings") {
        HOF.confirm({ title: "Kaydedilmemiş Değişiklik", message: "Banka ayarlarında kaydedilmemiş değişiklik var. Kaydetmeden çıkılsın mı?", confirmLabel: "Kaydetmeden Çık", danger: true }).then(go => go && setTab(tab));
        return;
      }
      return setTab(tab);
    }
    const status = event.target.closest("[data-status]")?.dataset.status;
    if (status) {
      view.status = status;
      return render();
    }
    const act = event.target.closest("[data-act]");
    if (act && !act.disabled) {
      event.preventDefault();
      const account = view.account;
      switch (act.dataset.act) {
        case "retryList":
          return reload();
        case "wizard":
          return openWizard();
        case "legacy":
          enterLegacy();
          render();
          return reload();
        case "back":
          return setTab("accounts");
        case "back-overview":
          return setTab("overview");
        case "new":
          return accountForm();
        case "subtrial":
          return openSubTrial();
        case "edit":
          return account && accountForm(account);
        // v2.2.0 (İz 2.3): kart bankanın içinden; eski bağsız kartı önerilen bankaya bağlama.
        case "card-add":
          return account && cardForm({ parentId: account.id });
        case "link-card":
          return linkCard(act.dataset.card, act.dataset.parent);
        case "opening":
          return account && openingForm(account);
        case "status":
          return account && toggleStatus(account);
        case "delete":
          return account && removeAccount(account);
        case "assign":
          return assignSelected();
        case "reclass-bank":
          return reclassForm("bank");
        case "reclass-card":
          return reclassForm("card");
        case "undo":
          return undoRun(act.dataset.run);
        case "advanced":
          view.advanced = !view.advanced;
          root()?.querySelector("[data-advanced]")?.toggleAttribute("hidden", !view.advanced);
          act.textContent = view.advanced ? "Gelişmiş Ayarları Gizle" : "Gelişmiş Ayarları Göster";
          act.setAttribute("aria-expanded", String(view.advanced));
          return;
        case "save-settings":
          return saveSettings(act.closest("form"));
        case "reset-section":
          return resetSettings(act.dataset.section);
        case "reset-all":
          return resetSettings();
        case "fee-add": {
          const box = act.closest(".hof-bank-fees");
          act.insertAdjacentHTML("beforebegin", feeRow({ key: "", name: "", gl: "770" }, true));
          view.dirty = true;
          box.querySelector("[data-fee]:last-of-type [data-fee-name]")?.focus();
          return;
        }
        case "fee-remove": {
          // Dar kontrol 2.4.3 (ek 4): kaldırılan türden sonra odak kaybolmaz ve başka türün ×'ine gitmez: sonraki (yoksa önceki) türün adı,
          // tür kalmadıysa "+ Tür Ekle".
          const row = act.closest("[data-fee]");
          const box = act.closest(".hof-bank-fees");
          const nextRow = row?.nextElementSibling?.matches?.("[data-fee]") ? row.nextElementSibling : row?.previousElementSibling?.matches?.("[data-fee]") ? row.previousElementSibling : null;
          row?.remove();
          view.dirty = true;
          (nextRow?.querySelector("[data-fee-name]") || box?.querySelector('[data-act="fee-add"]'))?.focus({ preventScroll: true });
          return;
        }
        // ----- Aşama 4: Hareketler, İşlem Kartı, fiş formları, Planlı İşlemler -----
        case "mv-more":
          return loadMoves(act.dataset.movesKey === "account" ? accountMoves : moves, { more: true });
        case "mv-planned":
          moves.planned = !moves.planned;
          moves.loaded = false;
          render();
          return loadMoves(moves);
        case "mv-clear":
          moves.filter = { ...newMoves("main").filter, account: moves.filter.account };
          moves.loaded = false;
          render();
          return loadMoves(moves);
        case "mv-open":
          return openMovements({ account: "" });
        case "mv-account":
          return openMovements({ account: view.accountId });
        case "plans-due":
          return openMovements({ account: "", planned: true });
        case "v-fee":
          return voucherForm({ group: "fee", accountId: contextAccount() });
        case "v-interest":
          return voucherForm({ group: "interest", accountId: contextAccount() });
        case "v-other":
          return voucherForm({ group: "other", accountId: contextAccount() });
        case "v-transfer":
          return voucherForm({ group: "transfer", accountId: contextAccount() });
        case "v-tax":
          return HOF.taxPayment?.({ way: "bank", accountId: contextAccount(), onDone: () => reload() });
        case "v-card":
          return voucherForm({ group: "other", type: "card_payment", counterId: view.accountId });
        case "v-loan":
          return voucherForm({ group: "other", type: "loan_draw", counterId: view.accountId });
        case "plan-new":
          return voucherForm({ mode: "plan", accountId: contextAccount() });
        case "ev-back":
          return goBack();
        case "ev-reverse":
          return view.event && reverseForm(view.event);
        case "ev-correct":
          return view.event && voucherForm({ mode: "correct", card: view.event });
        case "ev-info":
          return view.event && infoForm(view.event);
        case "plan-run":
        case "plan-skip":
        case "plan-cancel": {
          const plan = planOf(act.dataset.plan);
          if (!plan) return;
          return act.dataset.act === "plan-run" ? planRunForm(plan) : act.dataset.act === "plan-skip" ? planSkip(plan, act) : planCancel(plan);
        }
        default:
          return;
      }
    }
    const link = event.target.closest("[data-event-link]");
    if (link) return openEvent(link.dataset.eventLink);
    const accountLink = event.target.closest("[data-open-account]");
    if (accountLink) return openAccount(accountLink.dataset.openAccount);
    const party = event.target.closest("[data-open-party]");
    if (party) return HOF.accounts?.open?.(party.dataset.openParty);
    const moveRow = event.target.closest("tr[data-event]");
    if (moveRow) return openEvent(moveRow.dataset.event);
    const row = event.target.closest("tr[data-account]");
    if (row) openAccount(row.dataset.account);
  }
  /** Formun hesabı: Hesap Detayı'ndan açılırsa o hesap; Hareketler'den açılırsa süzgeçteki hesap (yoksa varsayılan). */
  const contextAccount = () => (view.mode === "account" ? view.accountId : moves.filter.account);
  function onKey(event) {
    if (event.key !== "Enter") return;
    const input = event.target.closest?.("input[data-mv]");
    if (input) {
      event.preventDefault();
      return applyFilters();
    }
    const moveRow = event.target.closest?.("tr[data-event]");
    if (moveRow && event.target === moveRow) return openEvent(moveRow.dataset.event);
    const row = event.target.closest?.("tr[data-account]");
    if (row) openAccount(row.dataset.account);
  }
  function onChange(event) {
    const target = event.target;
    if (target.matches('input[type="date"][data-mv]')) {
      clearTimeout(dateTimer);
      if (!target.value || plausibleDate(target.value)) dateTimer = setTimeout(applyFilters, 700);
      return;
    }
    if (target.matches("[data-mv]")) return applyFilters();
    if (target.matches("[data-pick]")) {
      if (target.checked) view.selected.add(target.dataset.pick);
      else view.selected.delete(target.dataset.pick);
      return render();
    }
    if (target.matches("[data-legacy-target]")) {
      view.legacyTarget = target.value;
      view.selected = new Set([...view.selected].filter(id => (view.legacy?.rows || []).some(row => rowKey(row) === id && canPick(row))));
      return render();
    }
    if (target.matches("[data-pick-all]")) {
      const keys = (view.legacy?.rows || []).filter(row => canPick(row)).map(rowKey);
      view.selected = target.checked ? new Set(keys) : new Set();
      return render();
    }
    if (target.closest("[data-settings]")) markDirty();
  }
  function onInput(event) {
    // Arama yazdıkça (300 ms bekleyerek) süzülür; tutar ve tarih alanları Enter'da ya da alandan çıkınca.
    if (event.target.matches?.('input[data-mv="q"]')) {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(applyFilters, 300);
      return;
    }
    if (event.target.closest("[data-settings]")) markDirty();
  }
  function markDirty() {
    if (view.dirty) return;
    view.dirty = true;
    const form = root()?.querySelector("[data-settings]");
    if (form && !form.querySelector(".hof-bank-dirty") && HOF.can("bank.settings")) form.insertAdjacentHTML("beforeend", '<p class="hof-bank-dirty">Kaydedilmemiş değişiklik var.</p>');
  }
  // 2.4.3 (C12): seçicide kesilen uzun ad (hesap, kart, POS) üzerine gelince ya da odaklanınca ipucunda tam görünür (bütün banka seçicileri).
  const fullTitle = event => {
    const select = event.target?.closest?.("select");
    if (!select || !select.closest(".hof-bank-form, .hof-bank-pick, [data-pos-pick], [data-cheque-pick], .hof-bank-modal, .hof-bank-balance-slot")) return;
    const text = select.selectedOptions?.[0]?.textContent.trim() || "";
    if (select.title !== text) select.title = text;
  };
  document.addEventListener("mouseover", fullTitle);
  document.addEventListener("focusin", fullTitle);
  document.addEventListener("change", fullTitle);
  document.addEventListener("submit", event => {
    const form = event.target.closest?.("[data-settings]");
    if (!form || !modal?.dialog.contains(form)) return;
    event.preventDefault();
    saveSettings(form);
  });

  // ---------- Ortak hesap seçici (K13; §8.9) ----------
  /**
   * Form seçicileri (bakiyesiz). force: sunucudan taze liste (form açılışında). Önbellek yalnız aynı anda kurulan seçiciler içindir; banka
   * değişikliğinde (canlı olay) boşalır.
   * İkinci küçük bulgular m1 (10.10.2026): önbellek YALNIZ canlı olayla boşalıyordu; başka oturum ikinci kurumsal kartı (ya da ikinci banka
   * hesabını) açtıktan sonra olay gelmeden açılan formda tek-kart görünümü kalıyor, gizli alan birinci kartın kimliğini gönderiyor ve ödeme
   * sessizce birinci karta yazılıyordu. Artık (1) her form açılışında liste tazelenir, (2) tek hesap/kart görünümü kimlik GÖNDERMEZ (sunucu
   * yalnız gerçekten tek hesap varsa kendisi seçer, birden çoksa 400 bank-account-required), (3) o yanıt gelince açık formların seçicileri
   * taze listeyle yeniden kurulur (HOF olayı "bank-choices-stale", hof-core sendApi).
   */
  // v2.2.0 (İz 2.7): date — formun tarihi; yanıt o günün bakiyeleriyle gelir (seçici açılırken TEK istek: hesaplar + bakiyeler).
  const dayQuery = date => (/^\d{4}-\d{2}-\d{2}$/.test(date || "") ? `?date=${date}` : "");
  function choices(force = false, date = "") {
    if (!choicesCache || force)
      choicesCache = HOF.api(`${BASE}/choices${dayQuery(date)}`).catch(error => {
        choicesCache = null;
        throw error;
      });
    return choicesCache;
  }

  // ---------- v2.2.0 (İz 2.7): seçicilerde bakiye ----------
  /**
   * choices yanıtında (yalnız Banka Görüntüleme yetkisine) balances: { date, accounts: { id: { atMinor, totalMinor, limitMinor, policy, confirmed,
   * guarded, currency } } }; Kasa Görüntüleme yetkisine cash: { date, atMinor, totalMinor, policy }. Yetkisi olmayana alan gelmez → ekran hiçbir
   * bakiye göstermez. Seçenek adında her hesabın SEÇİLEN TARİHTEKİ bakiyesi; seçilenin altında "Bakiye (gün) · İşlemden Sonra" (tutar yazıldıkça).
   * Eksi kuralı sunucunun K7'siyle aynı (plan §3.9): min(o günkü, bütün hareketlerle) + değişim + limit < 0 → kırmızı + hesabın kuralı (Uyar:
   * kaydederken sorulur; Engelle: kaydedilmez; Kontrol Yok / Bakiye Doğrulanmadı: denetlenmez). Ekran yalnız gösterir; karar yine sunucuda.
   */
  const parseTl = value => {
    let raw = String(value ?? "").trim().replace(/[₺$€\s]|tl|try/gi, "");
    if (!raw) return 0;
    if (raw.includes(",")) raw = raw.replace(/\./g, "").replace(",", ".");
    else if (/^-?\d{1,3}(\.\d{3})+$/.test(raw)) raw = raw.replace(/\./g, "");
    return /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : 0;
  };
  const toMinor = value => Math.round((Number(value) || 0) * 100);
  const plainMoney = (minor, currency = "TRY") => `${minor < 0 ? "−" : ""}${fmt(Math.abs(minor), currency)}`;
  const debtText = (minor, currency = "TRY") => (minor > 0 ? `Alacak ${fmt(minor, currency)}` : `Borç ${fmt(-minor, currency)}`);
  const balanceOf = (data, id) => (id && id !== "none" ? data?.balances?.accounts?.[id] || null : null);
  const accountOf = (data, id) => data?.accounts?.find(account => account.id === id) || null;
  /** Seçenek adı: "Ziraat Bankası · Ana TL (ZIR-TL) — 18.160,00 ₺"; kartta "Yapı Kredi · World •••• 1234 (YK-K1) — Borç 3.000,00 ₺". */
  function optionText(account, data) {
    const base = `${account.label}${account.cardLast4 ? ` •••• ${account.cardLast4}` : ""} (${account.code})`;
    const b = balanceOf(data, account.id);
    if (!b) return base;
    return `${base} — ${account.kind === "card" ? debtText(b.atMinor, b.currency) : plainMoney(b.atMinor, b.currency)}`;
  }
  /** Seçeneklerin adı tarih değişince yerinde güncellenir (seçim ve odak kaybolmaz). */
  function refreshOptionTexts(scope, data) {
    scope?.querySelectorAll?.("select option[value]").forEach(option => {
      const account = option.value && option.value !== "none" ? accountOf(data, option.value) : null;
      if (account) option.textContent = optionText(account, data);
    });
  }
  const dayLabel = iso => (iso ? HOF.formatDate(`${iso}T12:00:00`) : "");
  /**
   * Seçilen hesabın bakiye satırı (HTML; bakiye yoksa ""). change: işlemin bu hesaba etkisi (kuruş; giriş +, çıkış −); original: düzeltilen
   * hareketin bu hesaptaki etkisi { minor, date } (bakiyede zaten var; sunucunun "değişim"i yeni − eski). only: yalnız bakiye (verilen çekin
   * hesabı gibi para o an hareket etmiyorsa).
   */
  function balanceLine(data, id, { change = 0, original = null, only = false } = {}) {
    const b = balanceOf(data, id);
    if (!b) return "";
    const card = accountOf(data, id)?.kind === "card";
    const show = minor => (card ? debtText(minor, b.currency) : plainMoney(minor, b.currency));
    const head = `${card ? "Kart" : "Bakiye"} (${esc(dayLabel(data.balances.date))}): <b>${esc(show(b.atMinor))}</b>`;
    if (only) return `<small class="hof-bank-balance" data-bank-balance="${esc(id)}">${head}</small>`;
    const own = original?.minor || 0;
    const at = b.atMinor - (own && (!original.date || original.date <= data.balances.date) ? own : 0);
    const total = b.totalMinor - own;
    const lowest = Math.min(at, total) + change;
    // Sunucu yalnız bakiyeyi AZALTAN işlemi denetler (değişim = yeni etki − düzeltilen hareketin etkisi).
    const negative = change - own < 0 && lowest + b.limitMinor < 0;
    const parts = [head, `İşlemden Sonra: <b>${esc(show(at + change))}</b>`];
    if (total < at && change) parts.push(`İleri tarihli hareketlerle: ${esc(show(total + change))}`);
    if (b.limitMinor && (card || lowest < 0)) parts.push(`${card ? "Kart Limiti" : "KMH Limiti"}: ${esc(fmt(b.limitMinor, b.currency))}`);
    let rule = "";
    if (negative) {
      const what = card ? "Kart limiti aşılıyor" : "Hesap eksiye düşüyor";
      if (!b.guarded) rule = `${what}.`;
      else if (b.policy === "block") rule = `${what}; bu hesapta eksi bakiyeye izin verilmiyor (Engelle), kaydedilmez.`;
      else if (b.policy === "warn") rule = `${what}; kaydederken onay istenir (Uyar).`;
      else rule = b.confirmed ? `${what}; eksi bakiye denetimi kapalı (Kontrol Yok).` : `${what}; açılış bakiyesi doğrulanmadığı için denetlenmez.`;
    }
    return `<small class="hof-bank-balance${negative ? " is-negative" : ""}" data-bank-balance="${esc(id)}"${negative ? ` data-negative="${esc(b.policy)}"` : ""}>${parts.join(" · ")}${rule ? ` <span class="hof-bank-balance-rule">${esc(rule)}</span>` : ""}</small>`;
  }
  /** Nakit Kasa satırı (Kasa ↔ Banka): change kuruş (Kasa'ya giriş +, çıkış −). Kasa Görüntüleme yetkisi yoksa "". */
  function cashLine(data, change = 0) {
    const c = data?.cash;
    if (!c) return "";
    const negative = change < 0 && Math.min(c.atMinor, c.totalMinor) + change < 0;
    const rule = !negative ? "" : c.policy === "block" ? "Nakit Kasa eksiye düşüyor; eksi bakiyeye izin verilmiyor (Engelle), kaydedilmez." : c.policy === "warn" ? "Nakit Kasa eksiye düşüyor; kaydederken onay istenir (Uyar)." : "Nakit Kasa eksiye düşüyor (Kontrol Yok).";
    const parts = [`Nakit Kasa (${esc(dayLabel(c.date))}): <b>${esc(plainMoney(c.atMinor))}</b>`, `İşlemden Sonra: <b>${esc(plainMoney(c.atMinor + change))}</b>`];
    if (c.totalMinor < c.atMinor && change) parts.push(`İleri tarihli hareketlerle: ${esc(plainMoney(c.totalMinor + change))}`);
    return `<small class="hof-bank-balance${negative ? " is-negative" : ""}" data-cash-balance${negative ? ` data-negative="${esc(c.policy)}"` : ""}>${parts.join(" · ")}${rule ? ` <span class="hof-bank-balance-rule">${esc(rule)}</span>` : ""}</small>`;
  }
  /** Tarih değişince yalnız bakiyeler (seçici yeniden kurulmaz). Yetkisi yoksa (403) ya da hata: {}. */
  async function balances(date = "") {
    try {
      return await HOF.api(`${BASE}/balances${dayQuery(date)}`);
    } catch {
      return {};
    }
  }

  // ---------- v2.2.0 (İz 2.4): "… Tanımla" — tek kural, bütün seçiciler ----------
  /**
   * Seçicide hesap yoksa düğme: "Banka Hesabı Tanımla" / "Kredi Kartı Tanımla" / "Çek Hesabı Tanımla" (POS izi "POS Tanımla"yı registerDefine ile
   * ekler). Düğme tanım penceresini formun ÜSTÜNE açar (form kapanmaz, girilenler kaybolmaz); kaydedince yeni tanım formda seçili gelir.
   * Tanımlama yetkisi yoksa düğme yerine yazı: "… tanımlı değil, yöneticinize başvurun." (sunucu yine 403 verir).
   *   HOF.bank.registerDefine(kind, { button, missing, permission, open })  open(): söz → kaydedilen kayıt ({ id, … }) ya da null
   *   HOF.bank.defineHtml(kind)  → kutu (düğme ya da yazı); düğmede data-bank-define="kind"
   *   HOF.bank.define(kind)      → söz (kayıt | null); seçici listesi tazelenir
   * Düğmeye basılıp kayıt yapılınca düğmenin yerinden "hof-bank-defined" olayı (detail: { kind, account }) kabarır; attachPicker ve fatura
   * peşin hücresi bunu dinleyip seçiciyi yeni tanımla kurar.
   */
  const DEFINES = new Map();
  function registerDefine(kind, spec) {
    DEFINES.set(String(kind), { permission: "bank.accounts", ...spec });
  }
  const canDefine = spec => Boolean(spec) && HOF.can(spec.permission) && HOF.license?.writable !== false;
  function defineHtml(kind) {
    const spec = DEFINES.get(String(kind));
    if (!spec) return "";
    const inner = canDefine(spec) ? `<button type="button" class="hof-button hof-button-small hof-button-ghost" data-bank-define="${esc(kind)}">${esc(spec.button)}</button>` : `<p class="hof-bank-define-missing" data-bank-define-missing="${esc(kind)}">${esc(spec.missing)}</p>`;
    return `<div class="hof-bank-define" data-bank-define-box="${esc(kind)}">${inner}${spec.hint ? `<small class="hof-bank-pick-note">${esc(spec.hint)}</small>` : ""}</div>`;
  }
  const defining = new Set();
  async function define(kind) {
    const spec = DEFINES.get(String(kind));
    if (!canDefine(spec) || defining.has(kind)) return null;
    defining.add(kind);
    try {
      const saved = await spec.open();
      if (saved) {
        choicesCache = null;
        HOF.emit("bank-changed");
      }
      return saved || null;
    } finally {
      defining.delete(kind);
    }
  }
  /**
   * Çek Hesabı Tanımla (2.5): çek karnesi olan hesap çoğunlukla zaten tanımlıdır — Çek Kullan işaretsiz havale hesabı varsa onu işaretlemek
   * önerilir ("+ Yeni Banka Hesabı" da seçilebilir); hiç hesap yoksa doğrudan Çek Kullan işaretli yeni hesap formu.
   */
  async function flagDefine(flag, { title, intro, submit }) {
    const data = await choices(true).catch(() => null);
    const candidates = (data?.forms?.bank?.ids || []).map(id => data.accounts.find(account => account.id === id)).filter(account => account && !account[flag]);
    if (!candidates.length) return accountForm(null, { inline: true, preset: { [flag]: true } });
    return new Promise(resolve => {
      let saved = null;
      HOF.formModal({
        title,
        eyebrow: moduleName().toLocaleUpperCase("tr-TR"),
        intro,
        fields: [{ name: "accountId", label: "Banka Hesabı", type: "select", required: true, value: candidates[0].id, options: [...candidates.map(account => ({ value: account.id, label: `${account.label} (${account.code})` })), { value: "new", label: "+ Yeni Banka Hesabı" }] }],
        submitLabel: submit,
        onClose: () => resolve(saved),
        onSubmit: async form => {
          if (form.accountId === "new") {
            saved = await accountForm(null, { inline: true, preset: { [flag]: true } });
            return saved ? undefined : true;
          }
          saved = await api(`/accounts/${encodeURIComponent(form.accountId)}`, { method: "PUT", body: { [flag]: true } });
          choicesCache = null;
          HOF.toast(`${saved.label} hesabında “${FLAG_FIELDS.find(([key]) => key === flag)?.[1].replace(/\s*\(.*$/, "") || flag}” işaretlendi.`, { type: "success" });
        },
      });
    });
  }
  // hint: tanımlamadan kaydedilirse ne olur (plan §3.5/1: hiç uygun hesap yoksa satır bugünkü gibi hesapsız — Hesabı Atanmamış).
  const UNASSIGNED_HINT = "Tanımlamadan kaydederseniz hareket Hesabı Atanmamış Eski Hareketler'de kalır.";
  registerDefine("bank", { button: "Banka Hesabı Tanımla", missing: "Banka hesabı tanımlı değil, yöneticinize başvurun.", hint: UNASSIGNED_HINT, open: () => accountForm(null, { inline: true }) });
  registerDefine("card", { button: "Kredi Kartı Tanımla", missing: "Kredi kartı tanımlı değil, yöneticinize başvurun.", hint: UNASSIGNED_HINT, open: () => cardForm({ inline: true }) });
  registerDefine("cheque", {
    button: "Çek Hesabı Tanımla",
    missing: "Çek hesabı tanımlı değil, yöneticinize başvurun.",
    open: () => flagDefine("useCheque", { title: "Çek Hesabı Tanımla", intro: "Çek karnesi olan banka hesabını seçin; hesapta “Çek Kullan” işaretlenir ve verilen çekte Çek Hesabı olarak seçilir. Hesap tanımlı değilse “+ Yeni Banka Hesabı”.", submit: "Çek Kullan'ı İşaretle" }),
  });
  // v2.2.0 (İz 2.6, İz 4.1 ekranı): Bankaya Tahsile Ver — alınan çek yalnız "Çek Kullan", alınan senet yalnız "Senet Kullan" işaretli hesaba
  // (sunucu: lib/bank/collections.mjs depositEligibility). Uygun hesap yoksa "Banka Hesabı Tanımla": işaretsiz havale hesabı varsa onu işaretlemek
  // önerilir, yoksa (ya da "+ Yeni Banka Hesabı") evrak türünün işareti dolu yeni hesap formu; kaydedilen hesap tahsile verme formunda seçili gelir.
  for (const [kind, flag, name, what] of [["cheque", "useCheque", "Çek Kullan", "Çeki"], ["note", "useNote", "Senet Kullan", "Senedi"]]) {
    registerDefine(`deposit-${kind}`, {
      button: "Banka Hesabı Tanımla",
      missing: "Banka hesabı tanımlı değil, yöneticinize başvurun.",
      open: () => flagDefine(flag, { title: "Banka Hesabı Tanımla", intro: `${what} tahsile vereceğiniz banka hesabını seçin; hesapta “${name}” işaretlenir ve tahsile verme formunda seçili gelir. Hesap tanımlı değilse “+ Yeni Banka Hesabı” (“${name}” işaretli gelir).`, submit: `${name}'ı İşaretle` }),
    });
  }
  // Formdaki "… Tanımla" düğmesi (her formda aynı; olay belgede tek dinleyiciyle).
  document.addEventListener("click", async event => {
    const button = event.target.closest?.("[data-bank-define]");
    if (!button || button.disabled) return;
    event.preventDefault();
    const kind = button.dataset.bankDefine;
    const form = button.closest("form") || button.closest(".hof-modal");
    button.disabled = true;
    let saved = null;
    try {
      saved = await define(kind);
    } catch (error) {
      HOF.toastError(error);
    } finally {
      button.disabled = false;
    }
    if (!saved?.id) return;
    const target = button.isConnected ? button : form;
    target?.dispatchEvent(new CustomEvent("hof-bank-defined", { bubbles: true, detail: { kind, account: saved } }));
  });

  /**
   * Hesap seçici: hiç uygun hesap yoksa (define verilmişse) "… Tanımla" kutusu, yoksa boş (bugünkü görünüm; satır hesapsız yazılır), tek hesapta
   * bilgi satırı (alan yok; sunucu o hesabı kendisi seçer), birden çokta zorunlu seçim (varsayılan: Banka Ayarları'ndaki Varsayılan Tahsilat
   * Hesabı, yoksa ilk vadesiz). form: bank | card | fx | cheque | note. Dönüş: { mode: "none" | "define" | "single" | "many", accountId, html }.
   */
  // keepLabel (Aşama 5–6, düzeltme formları): hesabı atanmamış eski hareketin düzeltmesinde ilk seçenek "değiştirme" (boş değer); sunucu yalnız
  // açıklama değişiyorsa satırı bağsız bırakır, tutar/tarih/yol değişiyorsa hesap ister (plan §3.5 kural 4). value: satırın mevcut hesabı.
  // K2 (plan §3.5, §4.6, §8.9 "'Kredi Kartı' seçilince Kurumsal Kart"): form "card" = Kurumsal Kredi Kartı hesapları. Kartta varsayılan ön seçim
  // yoktur (preselect false): birden çok kartta kullanıcı kartı kendisi seçer (çokta seçim zorunlu); tek kartta bilgi satırı.
  // none (2.5): "Hesapsız (Açılıştan Önce)" seçeneği (para satırı formları; çek hesabında yok). required (2.6): senet önerisi zorunlu değil.
  function pickerHtml(data, { form = "bank", value = "", name = "bankAccountId", label = "Banka Hesabı", keepLabel = "", note = null, choose = "Hesap Seçin", preselect = true, define: defineKind = "", none: noneOption = true, required = true } = {}) {
    const meta = data?.forms?.[form];
    const accounts = (meta?.ids || []).map(id => data.accounts.find(account => account.id === id)).filter(Boolean);
    const current = value ? data?.accounts?.find(account => account.id === value) : null;
    if (!accounts.length && !current) return defineKind && DEFINES.has(defineKind) ? { mode: "define", accountId: "", html: defineHtml(defineKind) } : { mode: "none", accountId: "", html: "" };
    // Tek hesap: yalnız bilgi satırı; kimlik GÖNDERİLMEZ (m1: ekranın eski görünümü sunucunun seçimini ezmesin). Düzeltmede satırın bağı
    // sunucuda korunur (pickRef: önceki bağ), yeni satırda sunucu tek uygun hesabı kendisi seçer.
    const shown = account => `${account.label}${account.cardLast4 ? ` •••• ${account.cardLast4}` : ""}`;
    if (accounts.length === 1 && !keepLabel && (!value || value === accounts[0].id) && required) return { mode: "single", accountId: accounts[0].id, html: `<p class="hof-bank-pick-note" data-bank-single="${esc(accounts[0].id)}">${esc(note ? note(shown(accounts[0])) : `${shown(accounts[0])} hesabına yazılır.`)}</p>` };
    // Satırın hesabı artık seçilemiyorsa (pasif) seçenek olarak kalır: değiştirilmeden kaydedilebilsin.
    const list = current && !accounts.some(account => account.id === current.id) ? [current, ...accounts] : accounts;
    const selected = value && list.some(account => account.id === value) ? value : keepLabel || !preselect ? "" : meta?.defaultId || "";
    const first = keepLabel ? { value: "", label: keepLabel } : { value: "", label: choose };
    // Yargıç B1 (plan §3.5 kural 1): hareket seçilecek hesabın açılışından önceyse (o gün tutulan hesap yok) satır hesapsız kalır; sunucu bu seçimi
    // yalnız tarih bir hesabın açılışından önceyse kabul eder. Tek hesapta seçici yoktur, sunucu açılıştan önceki tarihi kendisi hesapsız yazar.
    const none = noneOption ? [{ value: "none", label: "Hesapsız (Açılıştan Önce)" }] : [];
    // 2.7: seçenek adında hesabın seçilen tarihteki bakiyesi (yalnız Banka Görüntüleme yetkisine gelir; yoksa yalnız ad).
    return { mode: "many", accountId: selected, html: HOF.fieldHtml({ name, label, type: "select", required: required && !keepLabel, value: selected, options: [first, ...list.map(account => ({ value: account.id, label: optionText(account, data) })), ...none] }) };
  }
  /** Kurumsal kart seçicisinin ayarları (form "card"; alan cardAccountId — gönderimde accountBody bankAccountId'ye taşır). */
  const CARD_PICKER = Object.freeze({ form: "card", name: "cardAccountId", label: "Kredi Kartı", choose: "Kart Seçin", preselect: false, define: "card", note: label => `${label} kredi kartına yazılır.` });
  /** Seçiciyi anchor öğesinin ardına yerleştirir (data: choices yanıtı); dönüş mode. Zorunluluk data-required'da saklanır (yol gizleyince geri gelsin). */
  function insertPicker(anchor, options, data) {
    if (!anchor) return "none";
    const picked = pickerHtml(data, options);
    if (!picked.html) return picked.mode;
    anchor.insertAdjacentHTML("afterend", `<div class="hof-bank-pick" data-bank-pick="${options.form === "card" ? "card" : ""}" data-bank-form="${esc(options.form || "bank")}">${picked.html}</div>`);
    const select = anchor.nextElementSibling?.querySelector("select");
    if (select) select.dataset.required = select.required ? "1" : "";
    return picked.mode;
  }
  /** Seçiciyi anchor öğesinin ardına yerleştirir (taze listeyle); dönüş mode. Yükleme hatasında seçici yoktur (sunucu yine hesap ister). */
  async function mountPicker(anchor, options = {}) {
    if (!anchor) return "none";
    try {
      return insertPicker(anchor, options, await choices(true));
    } catch {
      return "none";
    }
  }

  /**
   * Modül formuna hesap seçici (Aşama 5–6; §8.9): yol alanı (methodName) "Havale / EFT" olduğunda görünür, başka yolda gizli ve gönderilmez
   * (zorunlu işareti kalkar). methodName verilmezse (Kasa ↔ Banka transferi) hep görünür. Hiç hesap yoksa "Banka Hesabı Tanımla" (2.4; tanımlama
   * yetkisi yoksa "tanımlı değil, yöneticinize başvurun" yazısı); tanımlanmadan kaydedilirse satır bugünkü gibi hesapsız yazılır (plan §3.5/1).
   * K2: card verilirse ({ value, keepLabel }) yol "Kredi Kartı" olduğunda Kurumsal Kart seçicisi (yalnız ödeme ve kurumsal karta iade formları:
   * cari ödeme, alış faturası ödemesi, stok alımı; tahsilatta kart yolu POS'tur, seçici yoktur). Yol değişince alan yeniden çizilmez; yalnız
   * gösterilir/gizlenir (Tab ile ilerlerken odak ve seçim kaybolmaz). m1: liste form açılışında tazelenir; sunucu "seçim zorunlu" derse
   * (bank-account-required) seçiciler taze listeyle yeniden kurulur (refreshPickers).
   */
  const pickerForms = new Map();
  function placePickers(form, setup, data, force = {}) {
    // Yeniden kurulumda kullanıcının seçtiği hesap/kart korunur (yeni listede hâlâ varsa); force: yeni tanımlanan hesap seçili gelir.
    const kept = {};
    form.querySelectorAll("[data-bank-pick] select").forEach(select => {
      if (select.value) kept[select.name] = select.value;
    });
    Object.assign(kept, force);
    form.querySelectorAll("[data-bank-pick]").forEach(node => node.remove());
    const { place, card, options } = setup;
    const bankName = options.name || "bankAccountId";
    // suggest (2.6): değer yoksa o seçici türünün ilk hesabı önerilir (verilen senedin ödemesinde Senet Kullan işaretli hesap).
    const suggested = options.suggest ? data?.forms?.[options.suggest]?.ids?.find(id => data?.forms?.bank?.ids?.includes(id)) || "" : "";
    const mode = insertPicker(place, { define: "bank", ...options, value: kept[bankName] || options.value || suggested || "" }, data);
    const box = form.querySelector('[data-bank-pick]:not([data-bank-pick="card"])');
    if (card) insertPicker(box || place, { ...CARD_PICKER, value: kept[CARD_PICKER.name] || card.value || "", keepLabel: card.keepLabel || "" }, data);
    return mode;
  }
  /**
   * "Hesapsız (Açılıştan Önce)" seçiliyken seçicinin altında not (11.10.2026): formun açıklaması "seçilen banka hesabına girer" gibi okunmasın;
   * hareket hiçbir hesaba yazılmaz, Hesabı Atanmamış Eski Hareketler'de kalır (yargıç B1, plan §3.5 kural 1). Fatura peşin satırı da aynı metni kullanır.
   */
  const noneNote = card => `${card ? "Kredi kartının" : "Banka hesabının"} açılışından önceki hareket: hiçbir hesaba yazılmaz, Hesabı Atanmamış Eski Hareketler'de kalır.`;
  function syncNone(form) {
    form.querySelectorAll("[data-bank-pick]").forEach(node => {
      const on = node.querySelector("select")?.value === "none";
      const note = node.querySelector("[data-bank-none]");
      if (on && !note) node.insertAdjacentHTML("beforeend", `<p class="hof-bank-pick-note" data-bank-none>${esc(noneNote(node.dataset.bankPick === "card"))}</p>`);
      else if (!on && note) note.remove();
    });
  }
  function syncPickers(form, setup) {
    syncNone(form);
    const { methodNode } = setup;
    // 2.3.0 (İz 3.2): tahsilat formunda kart seçicisi yalnız "Kredi Kartına İade" (cardRefund) işaretliyken (aksi hâlde kart yolu POS alanıdır).
    const refundToggle = form.querySelector('input[name="cardRefund"]');
    if (methodNode)
      form.querySelectorAll("[data-bank-pick]").forEach(node => {
        const on = methodNode.value === (node.dataset.bankPick === "card" ? "card" : "bank") && (node.dataset.bankPick !== "card" || !refundToggle || refundToggle.checked);
        node.hidden = !on;
        node.querySelectorAll("[name]").forEach(input => {
          input.disabled = !on;
        });
        const select = node.querySelector("select");
        if (select) select.required = on && select.dataset.required === "1";
      });
    syncBalances(form, setup);
  }
  /**
   * 2.7 bakiye seçenekleri: direction — işlemin seçilen hesaba etkisi ("in" giriş, "out" çıkış; kartta "out" = kartla ödeme, borç artar);
   * amount — tutarı veren işlev (verilmezse formun "amount" alanı); original — düzeltilen hareket { ref, amount, date } (hesabı, TL tutarı, günü;
   * bakiyede zaten var); cash — Kasa ↔ Banka'da Nakit Kasa satırı ("in" Kasa'ya giriş, "out" çıkış); dateName — işlemin tarih alanı.
   */
  // 2.2.0 (İz 3.2): pos — tahsilat formunda kart yolu POS'tur (cari tahsilatı, kayıt/taksit tahsilatı, stok satışı) ya da POS İadesidir (taksit
  // iadesi, stok müşteri iadesi): { value (düzeltmede satırın POS'u), row ("tablo:kimlik"; düzeltmede taksit/provizyon/son 4 hane), refund,
  // origin: { partyId, planId } }. Yol "POS" iken POS alanı (hof-bank-pos.js posField): tekse bilgi satırı, çoksa seçim, yoksa "POS Tanımla".
  async function attachPicker(form, { methodName = "", anchor = null, card = null, pos = null, direction = "in", amount = null, original = null, cash = "", dateName = "date", ...options } = {}) {
    if (!form) return "none";
    const methodNode = methodName ? form.querySelector(`[name="${methodName}"]`) : null;
    const place = anchor || methodNode?.closest(".hof-field") || form.querySelector(".hof-field:last-of-type");
    if (!place) return "none";
    const dateNode = dateName ? form.querySelector(`[name="${dateName}"]`) : null;
    let data;
    try {
      data = await choices(true, dateNode?.value || "");
    } catch {
      return "none";
    }
    if (!form.isConnected) return "none";
    const amountNode = form.querySelector('[name="amount"]');
    const setup = {
      place,
      methodNode,
      card: card && methodNode ? card : null,
      options,
      data,
      dateNode,
      sign: direction === "out" ? -1 : 1,
      amountOf: typeof amount === "function" ? amount : () => parseTl(amountNode?.value),
      original: original?.ref ? original : null,
      cash: cash === "out" ? -1 : cash === "in" ? 1 : 0,
      cashPlace: amountNode?.closest(".hof-field") || place,
      balanceSeq: 0,
    };
    const mode = placePickers(form, setup, data);
    pickerForms.set(form, setup);
    // POS alanı (yalnız yol alanı olan formda; seçiciden ayrı kutu, data-pos-pick): POS betiği yüklüyse.
    if (pos && methodNode && posField?.attach) setup.posField = posField.attach(form, { methodNode, direction, data, dateNode, amountOf: setup.amountOf, ...pos });
    if (methodNode) methodNode.addEventListener("change", () => syncPickers(form, setup));
    // Seçici yeniden kurulsa da (refreshPickers) dinleyici formda: seçim değişince not yerleşir/kalkar.
    form.addEventListener("change", event => {
      if (event.target.closest?.("[data-bank-pick]")) syncNone(form);
      if (event.target.name === "cardRefund") syncPickers(form, setup);
      // 2.7: tarih değişince o günün bakiyeleri (tek istek; seçici yeniden kurulmaz); başka alan değişince satır yeniden hesaplanır.
      if (dateNode && event.target === dateNode) reloadBalances(form, setup);
      else syncBalances(form, setup);
    });
    form.addEventListener("input", event => {
      if (event.target !== dateNode) syncBalances(form, setup);
    });
    // 2.4: "… Tanımla" ile kaydedilen hesap/kart seçicide seçili gelir (alan yeniden kurulur; formun öbür alanları yerinde kalır).
    form.addEventListener("hof-bank-defined", async event => {
      const { kind, account } = event.detail || {};
      if (!account?.id || !["bank", "card", "pos"].includes(kind)) return;
      let fresh;
      try {
        fresh = await choices(true, setup.dateNode?.value || "");
      } catch {
        return;
      }
      if (!form.isConnected) return;
      setup.data = fresh;
      // 2.2.0 (İz 3.2): "POS Tanımla" ile kaydedilen POS, POS alanında seçili gelir (banka/kart seçicisi yerinde kalır).
      if (kind === "pos") return setup.posField?.refresh(fresh, account.id);
      placePickers(form, setup, fresh, { [kind === "card" ? CARD_PICKER.name : setup.options.name || "bankAccountId"]: account.id });
      syncPickers(form, setup);
      const box = form.querySelector(kind === "card" ? '[data-bank-pick="card"]' : '[data-bank-pick]:not([data-bank-pick="card"])');
      (box?.querySelector("select") || form.querySelector('button[type="submit"]'))?.focus();
    });
    syncPickers(form, setup);
    return mode;
  }
  /** 2.7: seçilen hesabın "Bakiye · İşlemden Sonra" satırı (seçici kutusunun altında) ve Kasa ↔ Banka'da Nakit Kasa satırı (tutarın altında). */
  function syncBalances(form, setup) {
    const data = setup?.data;
    if (!form?.isConnected || (!data?.balances && !data?.cash)) return;
    const amountMinor = Math.max(0, toMinor(setup.amountOf()));
    form.querySelectorAll("[data-bank-pick]").forEach(box => {
      const select = box.querySelector("select");
      const id = select ? select.value : box.querySelector("[data-bank-single]")?.dataset.bankSingle || "";
      const original = setup.original && setup.original.ref === id ? { minor: setup.sign * toMinor(setup.original.amount), date: setup.original.date || "" } : null;
      swapLine(box, "[data-bank-balance]", box.hidden ? "" : balanceLine(data, id, { change: setup.sign * amountMinor, original }));
    });
    if (setup.cash && setup.cashPlace?.isConnected) swapLine(setup.cashPlace, "[data-cash-balance]", cashLine(data, setup.cash * amountMinor));
  }
  function swapLine(container, selector, html) {
    const line = [...container.children].find(node => node.matches(selector));
    if (!html) return line?.remove();
    if (!line) return container.insertAdjacentHTML("beforeend", html);
    if (line.outerHTML !== html) line.outerHTML = html;
  }
  async function reloadBalances(form, setup) {
    if (!setup.data?.balances && !setup.data?.cash) return;
    const seq = (setup.balanceSeq += 1);
    const fresh = await balances(setup.dateNode?.value || "");
    // Yanıt gelmediyse (ağ hatası) eski bakiyeler kalır; satır boşalmaz.
    if (seq !== setup.balanceSeq || !form.isConnected || (!fresh.balances && !fresh.cash)) return;
    setup.data = { ...setup.data, balances: fresh.balances, cash: fresh.cash };
    form.querySelectorAll("[data-bank-pick]").forEach(box => refreshOptionTexts(box, setup.data));
    syncBalances(form, setup);
  }
  /**
   * v2.2.0 (İz 2.5–2.6): verilen çek/senet formunda hesap. Çek → "Çek Hesabı" (yalnız Çek Kullan işaretli etkin TL hesaplar; tekse bilgi satırı,
   * çoksa seçim zorunlu, hiç yoksa "Çek Hesabı Tanımla" ve "Banka / Şube" metni bugünkü gibi). Hesap varken "Banka / Şube" metni gizlenir
   * (sunucu hesabın adını yazar). Senet → "Ödeme Hesabı (Öneri)" (Senet Kullan işaretli; zorunlu değil; ödemede bu hesap gelir). Eski çekte
   * (hesapsız) ilk seçenek "Değiştirme (Mevcut: <metin>)": dokunulmazsa metin ve hesapsızlık korunur. Evrak türü değişince alan yeniden kurulur.
   * cheque: düzeltilen evrak (bankAccountId, bank) ya da null. Dönüş: söz.
   */
  async function attachChequePicker(form, { cheque = null, instrumentName = "instrument", bankName = "bank", dateName = "issueDate" } = {}) {
    if (!form) return;
    const textField = form.querySelector(`[name="${bankName}"]`)?.closest(".hof-field");
    if (!textField) return;
    const dateNode = form.querySelector(`[name="${dateName}"]`);
    let data;
    try {
      data = await choices(true, dateNode?.value || "");
    } catch {
      return;
    }
    let forced = "";
    // 2.7: seçilen hesabın bakiyesi (verilen çekte para o gün hareket etmez — "İşlemden Sonra" yok; ödemede gösterilir).
    const syncLine = () => {
      const box = form.querySelector("[data-cheque-pick]");
      if (!box) return;
      const select = box.querySelector("select");
      const id = select ? select.value : box.querySelector("[data-bank-single]")?.dataset.bankSingle || "";
      swapLine(box, "[data-bank-balance]", balanceLine(data, id, { only: true }));
    };
    let seq = 0;
    form.addEventListener("change", async event => {
      if (event.target.closest?.("[data-cheque-pick]")) return syncLine();
      if (event.target !== dateNode || !data?.balances) return;
      const mine = (seq += 1);
      const fresh = await balances(dateNode.value);
      if (mine !== seq || !form.isConnected || !fresh.balances) return;
      data = { ...data, balances: fresh.balances };
      const box = form.querySelector("[data-cheque-pick]");
      refreshOptionTexts(box, data);
      syncLine();
    });
    const render = () => {
      if (!form.isConnected) return;
      form.querySelectorAll("[data-cheque-pick]").forEach(node => node.remove());
      const instrument = form.querySelector(`[name="${instrumentName}"]`)?.value || cheque?.instrument || "cheque";
      const note = instrument === "note";
      const value = forced || (cheque && cheque.instrument === instrument ? cheque.bankAccountId || "" : "");
      // Çok hesapta ön seçim yok (kart gibi): kullanıcı çekin hangi karneden verildiğini kendisi seçer.
      const keepLabel = cheque && !cheque.bankAccountId && !forced && !note ? `Değiştirme (Mevcut: ${cheque.bank || "—"})` : "";
      const picked = pickerHtml(data, note ? { form: "note", name: "bankAccountId", label: "Ödeme Hesabı (Öneri)", choose: "Önerilmez", required: false, none: false, value } : { form: "cheque", name: "bankAccountId", label: "Çek Hesabı", define: "cheque", none: false, preselect: false, value, keepLabel, note: label => `${label} hesabının karnesinden verilir.` });
      const input = textField.querySelector("input");
      // Çek hesabı seçilebiliyorsa "Banka / Şube" metni gizlenir ve gönderilmez (sunucu hesabın adını yazar); senette metin kalır.
      const hideText = !note && (picked.mode === "single" || picked.mode === "many");
      textField.hidden = hideText;
      if (input) input.disabled = hideText;
      if (!picked.html) return;
      textField.insertAdjacentHTML("afterend", `<div class="hof-bank-pick" data-cheque-pick="${note ? "note" : "cheque"}">${picked.html}</div>`);
      syncLine();
    };
    render();
    form.querySelector(`[name="${instrumentName}"]`)?.addEventListener("change", () => {
      forced = "";
      render();
    });
    form.addEventListener("hof-bank-defined", async event => {
      if (event.detail?.kind !== "cheque" || !event.detail.account?.id) return;
      try {
        data = await choices(true, dateNode?.value || "");
      } catch {
        return;
      }
      forced = event.detail.account.id;
      render();
      (form.querySelector('[data-cheque-pick] select') || form.querySelector('button[type="submit"]'))?.focus();
    });
  }
  /** m1: sunucu "hesap/kart seçin" dedi (ekranın listesi eskiydi) → açık formların seçicileri taze listeyle yeniden kurulur. */
  async function refreshPickers() {
    for (const form of pickerForms.keys()) if (!form.isConnected) pickerForms.delete(form);
    if (!pickerForms.size) return;
    for (const [form, setup] of pickerForms) {
      if (!form.isConnected) {
        pickerForms.delete(form);
        continue;
      }
      // 2.7: her form kendi tarihinin bakiyeleriyle (seçici listesi aynı).
      let data;
      try {
        data = await choices(true, setup.dateNode?.value || "");
      } catch {
        return;
      }
      if (!form.isConnected) continue;
      setup.data = data;
      placePickers(form, setup, data);
      syncPickers(form, setup);
      setup.posField?.refresh(data);
    }
  }
  /**
   * Gönderilecek gövdenin hesap alanı (K2): havalede Banka Hesabı (bankAccountId), kurumsal kart yolunda Kurumsal Kart (cardAccountId →
   * bankAccountId), başka yolda hiçbiri. Form verisi gizli (pasif) alanları da taşıdığı için gönderimden önce çağrılır. method: gövdenin yolu.
   */
  // 2.2.0 (İz 3.2): POS alanları (posId, posInstallments, authCode, cardLast4, posRefundOf, posSourceless) yalnız kart yolunda ve kredi kartı
  // seçilmemişse (tahsilat / POS İadesi) gönderilir; başka yolda gizli alanlar düşer.
  const POS_FIELDS = ["posId", "posInstallments", "authCode", "cardLast4", "posRefundOf", "posSourceless"];
  function accountBody(body, method = body?.method) {
    if (!body) return body;
    // 2.3.0 (İz 3.2): tahsilat formunda "Kredi Kartına İade" kutusu — işaretli değilse kart seçicisinin (gizli) değeri gönderilmez (kart yolu POS'tur);
    // işaretliyse POS alanları gönderilmez. Kutusu olmayan formlar (ödeme) eskisi gibi.
    const refundToggle = "cardRefund" in body;
    const cardRefund = body.cardRefund === true;
    if (refundToggle && !cardRefund) delete body.cardRefund;
    const cardId = refundToggle && !cardRefund ? "" : body.cardAccountId;
    delete body.cardAccountId;
    if (method === "card" && cardId) body.bankAccountId = cardId;
    else if (method !== "bank") delete body.bankAccountId;
    if (method !== "card" || cardId || cardRefund) for (const key of POS_FIELDS) delete body[key];
    else {
      if (body.posSourceless === false || body.posSourceless === "") delete body.posSourceless;
      for (const key of POS_FIELDS) if (body[key] === "") delete body[key];
    }
    return body;
  }
  // POS alanı (hof-bank-pos.js registerPosField): attachPicker'ın kart yolu POS alanını kurar.
  let posField = null;

  // 2.3.0 İz 5.5 Hızlı Arama: sekmeler tabList()'ten (POS sekmesi hof-bank-pos.js'nin eklediğiyle gelir), işlemler yetkiye göre; fiş
  // penceresi Hareketler sekmesi açıldıktan sonra açılır.
  HOF.search?.register(() => {
    if (!HOF.can("bank.view")) return [];
    const withMoves = fn => open({ tab: "movements" }).then(fn);
    const tabs = tabList().map(([id, label]) => ({ group: id === "settings" ? "Ayar" : "Sayfa", label: id === "settings" ? `${moduleName()} Ayarları` : label, path: moduleName(), keywords: ["Banka", id === "accounts" ? "Banka Hesapları" : id === "movements" ? "Banka Hareketleri" : ""], run: () => open({ tab: id }) }));
    const acts = [];
    if (HOF.can("bank.move")) {
      acts.push(
        { group: "İşlem", label: "+ Masraf", path: moduleName(), keywords: ["Banka Masrafı", "Masraf Fişi", "Komisyon"], run: () => withMoves(() => voucherForm({ group: "fee" })) },
        { group: "İşlem", label: "+ Faiz", path: moduleName(), keywords: ["Faiz Geliri", "Faiz Gideri"], run: () => withMoves(() => voucherForm({ group: "interest" })) },
        { group: "İşlem", label: "+ Diğer İşlem", path: moduleName(), keywords: ["Banka Fişi"], run: () => withMoves(() => voucherForm({ group: "other" })) },
      );
    }
    if (HOF.can("bank.transfer")) acts.push({ group: "İşlem", label: "Bankalar Arası Transfer", path: moduleName(), keywords: ["Virman", "Havale"], run: () => withMoves(() => voucherForm({ group: "transfer" })) });
    if (canAccounts()) {
      acts.push(
        { group: "İşlem", label: "Yeni Banka Hesabı", path: moduleName(), keywords: ["Hesap Aç", "Banka Hesabı Tanımla"], run: () => open({ tab: "accounts" }).then(() => accountForm(null)) },
        { group: "İşlem", label: "Kurulum Sihirbazı", path: moduleName(), keywords: ["Banka Kurulumu"], run: () => open({ tab: "accounts" }).then(() => openWizard()) },
      );
    }
    return [...tabs, ...acts];
  });
  HOF.bank = {
    open,
    // 2.3.0 İz 3.3: zildeki planlı banka işlemi kalemi → Hareketler → Planlı İşlemler görünümü.
    openPlans: () => Promise.resolve(open({ tab: "movements" })).then(() => (modal ? openMovements({ account: "", planned: true }) : null)),
    openWizard,
    openEvent: ref => (modal ? openEvent(ref) : open().then(() => openEvent(ref))),
    choices,
    pickerHtml,
    mountPicker,
    attachPicker,
    accountBody,
    withConfirms,
    noneNote,
    // v2.2.0 (İz 2.2): hesap ayrıntısına bölüm ekleme (POS izi "POS'lar" bölümünü buradan doldurur): fn(account) → HTML (boşsa yer tutucu).
    addAccountSection: (key, fn) => {
      accountSections.set(String(key), fn);
      if (modal && view.mode === "account") render();
    },
    accountForm,
    cardForm,
    // v2.2.0 (İz 2.4): "… Tanımla" bileşeni (POS izi registerDefine("pos", { button: "POS Tanımla", missing: "POS tanımlı değil, yöneticinize
    // başvurun.", permission: "bank.pos", open }) ile ekler; seçicide pickerHtml/attachPicker'a define: "pos").
    registerDefine,
    defineHtml,
    define,
    attachChequePicker,
    // v2.2.0 (İz 2.7): seçicide bakiye (fatura peşin satırı da kullanır): seçenek adı, seçilenin bakiye satırı, Nakit Kasa satırı, tarihe göre bakiye.
    optionText,
    balanceLine,
    cashLine,
    balances,
    // v2.2.0 (İz 3): POS betiğinin (hof-bank-pos.js) pencereye bağlandığı yerler — sekme (Ayarlar'dan önce), yenileme kancası (çizimden önce
    // veri), yeniden çizim, pencerenin o anki görünümü, Hareketler'i bir POS'la açma, hesap işareti tanımı ("POS Kullan"), POS alanı.
    addTab: (id, spec) => {
      extraTabs.set(String(id), spec);
      if (modal) render();
    },
    addReloadHook: fn => reloadHooks.add(fn),
    rerender: () => (modal ? render() : null),
    reloadView: (options = {}) => (modal ? reload(options) : Promise.resolve()),
    current: () => ({ open: Boolean(modal), mode: view.mode, tab: view.tab, accountId: view.accountId, account: view.account, list: view.list }),
    setTab: tab => (modal ? setTab(tab) : open({ tab })),
    openAccount: id => (modal ? openAccount(id) : open({ accountId: id })),
    openMovements: (filter = {}) => (modal ? openMovements(filter) : open().then(() => openMovements(filter))),
    flagDefine,
    registerPosField: spec => {
      posField = spec;
    },
    fmt,
    dateText,
    pctText,
  };
  HOF.on("bank-choices-stale", () => {
    choicesCache = null;
    refreshPickers();
  });
  HOF.whenReady(() => {
    // Canlı yenileme (v2.0.22 kuralı): başka bilgisayardaki banka değişikliği ve para gösteren modüllerin değişikliği açık pencereyi tek
    // yenileme kapısından yeniler; bu penceredeki banka yazımı zaten kendini yeniler.
    const refreshOpen = HOF.refresher(() => (modal ? reload({ quiet: true }) : null));
    HOF.on("live:workspace.changed", change => {
      if (change?.kind !== "bank") return;
      choicesCache = null;
      metaCache = null;
      if (modal) refreshOpen();
    });
    HOF.onLedger(["bank", "cash", "accounts", "invoices", "plans", "cheques"], detail => {
      if ((detail.kinds || []).includes("bank") || !detail.kinds) choicesCache = null;
      if (!modal || (detail.local && detail.path?.startsWith(BASE))) return;
      if (detail.local) refreshOpen.now();
      else refreshOpen();
    }, 350);
  });
})();
