/* DestekOfis — lisans durumu (v2.0.0).
 * Ekranın altında küçük bir lisans şeridi gösterir (deneme süresi, geçiş dönemi, bitişe yakın lisans, salt okunur mod).
 * Program salt okunurken (süre doldu, engellendi, doğrulanamadı, saat hatası) açılışta ve yazma denendiğinde açıklayıcı
 * bir pencere gösterir; yönetici için Lisans ekranına bağlantı verir. Sunucu her yazma isteğini zaten reddeder; bu dosya
 * yalnızca durumu anlaşılır kılar. */
(() => {
  "use strict";
  const HOF = window.HOF;
  if (!HOF) return;
  const html = document.documentElement;
  const SNOOZE_KEY = "hof-license-snooze";
  let license = null;
  let lastModalAt = 0;

  const isAdmin = () => HOF.can("license.manage");
  // Deneme/lisans bitişi, engel ve taşıma durumlarında gösterilen iletişim bilgisi (sunucudan gelir).
  const FALLBACK_CONTACT = { name: "Destek Ofis", label: "Teknik Destek ve Satın Alımlar İçin", phone: "0536 771 50 55", phoneHref: "tel:+905367715055", email: "destek@destekofis.net" };
  const contactOf = status => ({ ...FALLBACK_CONTACT, ...(status?.contact || {}) });
  const needsContact = status => Boolean(status) && (!status.writable || status.severity === "warn" || ["trial", "expired", "blocked"].includes(status.state));
  const contactCard = status => {
    const c = contactOf(status);
    return `<div class="hof-license-contact"><strong>${HOF.esc(c.label || `${c.name} ile iletişim`)}</strong><span>Kullanmaya devam etmek, lisans almak veya yenilemek için bize ulaşın.</span><div class="hof-license-contact-links"><a class="hof-button hof-button-small" href="${HOF.esc(c.phoneHref)}">${HOF.esc(c.phone)}</a><a class="hof-button hof-button-ghost hof-button-small" href="mailto:${HOF.esc(c.email)}?subject=${encodeURIComponent("Destek Ofis lisans")}">${HOF.esc(c.email)}</a></div></div>`;
  };
  const adminLink = () => (isAdmin() ? '<a class="hof-button hof-button-small" href="/admin.html#license">Lisans Ekranını Aç</a>' : "");

  function snoozed(status) {
    try {
      return sessionStorage.getItem(SNOOZE_KEY) === `${status.state}:${status.daysLeft}`;
    } catch {
      return false;
    }
  }

  function render(status) {
    license = status;
    HOF.license = status;
    html.classList.toggle("hof-read-only", Boolean(status && !status.writable));
    document.getElementById("hof-license-bar")?.remove();
    if (!status) return;
    // Lisanslı ve sorunsuz: şerit yok.
    if (status.writable && status.severity === "ok") return;
    if (status.writable && snoozed(status)) return;
    // Bilgi niteliğindeki deneme şeridi yalnızca yöneticiye; uyarı ve salt okunur durum herkese gösterilir.
    if (status.writable && status.severity === "info" && !isAdmin()) return;
    const tone = status.writable ? (status.severity === "warn" ? "warn" : "info") : "error";
    const bar = HOF.el(
      "aside",
      { id: "hof-license-bar", class: `hof-license-bar is-${tone}`, role: status.writable ? "status" : "alert", "aria-live": "polite" },
      `<div class="hof-license-text"><strong>${HOF.esc(status.title)}</strong><span>${HOF.esc(status.writable ? status.message : "Program salt okunur: kayıtları görebilir, dışa aktarabilir ve yedekleyebilirsiniz; yeni işlem yapılamaz.")}</span></div>
       <div class="hof-license-actions">${needsContact(status) && status.severity !== "info" ? `<a class="hof-license-phone" href="${HOF.esc(contactOf(status).phoneHref)}">${HOF.esc(contactOf(status).phone)}</a>` : ""}${status.writable ? "" : '<button type="button" class="hof-button hof-button-ghost hof-button-small" data-license-more>Ayrıntı</button>'}${adminLink()}${status.writable ? '<button type="button" class="hof-license-close" aria-label="Şeridi gizle" data-license-close>×</button>' : ""}</div>`,
    );
    bar.addEventListener("click", event => {
      if (event.target.closest("[data-license-close]")) {
        try {
          sessionStorage.setItem(SNOOZE_KEY, `${status.state}:${status.daysLeft}`);
        } catch {
          // gizli pencerede depolama kapalı olabilir
        }
        bar.remove();
      } else if (event.target.closest("[data-license-more]")) explain(status);
    });
    document.body.appendChild(bar);
  }

  function explain(status = license, { attempted = false } = {}) {
    if (!status || HOF.hasOpenModal()) return;
    lastModalAt = Date.now();
    const lead = attempted ? "<p><b>Bu işlem yapılamadı.</b></p>" : "";
    const hint = isAdmin()
      ? "<p>Lisansı etkinleştirmek veya doğrulamak için Lisans ekranını açın.</p>"
      : "<p>Ofis yöneticinize haber verin: yönetici, Yönetim → Lisans ekranından lisansı etkinleştirebilir.</p>";
    HOF.modal({
      title: status.title,
      eyebrow: "LİSANS",
      size: "small",
      body: `<div class="hof-modal-text">${lead}<p>${HOF.esc(status.message)}</p>${hint}</div>${needsContact(status) ? contactCard(status) : ""}<div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-close>Tamam</button>${adminLink()}</div>`,
      onOpen: modal => modal.dialog.querySelector("[data-close]").addEventListener("click", () => modal.close()),
    });
  }

  // Denemenin 3. günü: programı hâlâ kullanan yöneticiden firma ve iletişim bilgisi istenir. "Daha sonra" denirse
  // bu tarayıcıda 3 gün sonra yeniden sorulur; bilgi gönderilince sunucu bir daha sormaz.
  const CONTACT_SNOOZE_KEY = "hof-contact-asked";
  const CONTACT_SNOOZE_MS = 3 * 86_400_000;
  let contactShown = false;
  function askContact(status = license) {
    if (!status?.askContact || !isAdmin() || contactShown || HOF.hasOpenModal()) return;
    try {
      const last = Number(localStorage.getItem(CONTACT_SNOOZE_KEY) || 0);
      if (Date.now() - last < CONTACT_SNOOZE_MS) return;
      localStorage.setItem(CONTACT_SNOOZE_KEY, String(Date.now()));
    } catch {
      // depolama kapalıysa oturum başına bir kez sorulur
    }
    contactShown = true;
    const c = contactOf(status);
    const modal = HOF.formModal({
      title: "DestekOfis'i kullanmaya devam ettiğiniz için teşekkürler",
      eyebrow: "DENEMENİN 3. GÜNÜ",
      intro: `Deneme süresince size destek olabilmemiz ve süre bitmeden sizi bilgilendirebilmemiz için firma bilgilerinizi bırakır mısınız? Deneme ${HOF.esc(String(status.daysLeft ?? ""))} gün daha sürecek.`,
      fields: [
        { name: "companyName", label: "Firma Adı", required: true, maxlength: 120, value: status.companyName || "", autocomplete: "organization" },
        { name: "contact", label: "Yetkili Kişi", maxlength: 120, autocomplete: "name" },
        { name: "phone", label: "Telefon", type: "tel", maxlength: 40, autocomplete: "tel" },
        { name: "email", label: "E-Posta", type: "email", maxlength: 160, autocomplete: "email" },
      ],
      extraHtml: `<p class="hof-inline-note">Telefon veya e-postadan en az birini yazın. Bilgileriniz yalnızca size ulaşmak için kullanılır (<a href="https://destekofis.net/kvkk.html" target="_blank" rel="noopener">KVKK Aydınlatma Metni</a>). Sorunuz olursa: ${HOF.esc(c.phone)} · ${HOF.esc(c.email)}</p>`,
      submitLabel: "Bilgileri Gönder",
      onSubmit: async data => {
        const next = await HOF.api("/api/license/contact", { method: "POST", body: data });
        render(next);
        HOF.toast?.("Teşekkürler! Bilgileriniz bize ulaştı.", { type: "success" });
      },
    });
    const cancel = modal?.dialog?.querySelector("[data-cancel]");
    if (cancel) cancel.textContent = "Daha Sonra";
  }

  async function refresh() {
    try {
      const status = await HOF.api("/api/license");
      const before = license;
      render(status);
      // Yazılabilirlik değiştiyse ekranlardaki yetkiler (düğmeler) eski kalır: yenileme önerilir.
      if (before && before.writable !== status.writable) HOF.showReloadBanner?.("Lisans durumu değişti. Güncel ekran için sayfayı yenileyin.");
    } catch (error) {
      if (error.status !== 401) console.warn("[DestekOfis] Lisans durumu alınamadı", error.message);
    }
  }

  HOF.whenReady(user => {
    render(user?.license || null);
    if (license && !license.writable) setTimeout(() => explain(license), 1200);
    else if (license?.askContact) setTimeout(() => askContact(license), 2500);
  });
  HOF.on("license-read-only", payload => {
    if (payload?.license) render({ ...license, ...payload.license });
    if (Date.now() - lastModalAt > 20_000) explain(license, { attempted: true });
  });
  HOF.on("live:license.changed", () => refresh());
  HOF.on("live:resync", () => refresh());
  // Kalan gün sayısı gün içinde değişebilir; saatte bir tazelenir.
  setInterval(() => HOF.isReady && !document.hidden && refresh(), 3_600_000);
  HOF.refreshLicense = refresh;
})();
