/* DestekOfis — kalıcı çalışma verisi arayüzü (v1.5.0).
 * - Veri yoksa panelin ortasında "başlayalım" kartı: Excel sürükle-bırak / seç ya da Google Sheets bağlantısı yapıştır.
 * - Ayarlar → Veri: özet, Excel yükleme, Sheet bağlama, eşitleme sıklığı, şimdi eşitle, geçmiş, Sheet'te olmayanlar,
 *   bağlantıyı/veriyi kaldırma. Yalnızca yönetici (sources.manage).
 * - Mevcut veri varken yeni dosya/bağlantı gelince önizleme sayılarıyla "devamı olarak ekle" / "yerine koy" sorulur.
 * - Arayüz paketinin kendi yükleme düğmeleri ("Yeni tablo yükle", "Tabloyu değiştir", "Kaynağı değiştir") gizlenir. */
(() => {
  "use strict";
  const HOF = window.HOF;
  const { esc } = HOF;
  const MAX_BYTES = 60 * 1024 * 1024;
  const SHEET_PATTERN = /^https:\/\/docs\.google\.com\/spreadsheets\//i;
  const number = value => new Intl.NumberFormat("tr-TR").format(Number(value) || 0);
  let summary = null; // sunucudaki çalışma verisi özeti
  let missingKeys = new Set();

  const canManage = () => HOF.can("sources.manage");
  const hasData = () => Boolean(HOF.settings && HOF.settings.sheetUrl);

  async function loadSummary() {
    try {
      summary = await HOF.api("/api/workspace/dataset");
      missingKeys = new Set(summary.missingKeys || []);
    } catch {
      // Özet alınamazsa arayüz yine çalışır; bir sonraki değişiklikte yeniden denenir.
    }
    return summary;
  }

  // ---------- Excel okuma (tarayıcıda, arka plan işçisiyle) ----------
  const parseInWorker = file =>
    new Promise((resolve, reject) => {
      let worker;
      try {
        worker = new Worker("/assets/hof-excel-worker.js", { type: "module" });
      } catch {
        reject(new Error("Tarayıcınız Excel okuma işlemini desteklemiyor. Chrome veya Edge'in güncel sürümünü kullanın."));
        return;
      }
      const timer = setTimeout(() => {
        worker.terminate();
        reject(new Error("Excel dosyası 90 saniyede okunamadı. Dosyayı sadeleştirip tekrar deneyin."));
      }, 90_000);
      worker.onmessage = event => {
        clearTimeout(timer);
        worker.terminate();
        if (event.data.ok) resolve(event.data);
        else reject(new Error(`Excel dosyası okunamadı: ${event.data.error}`));
      };
      worker.onerror = event => {
        clearTimeout(timer);
        worker.terminate();
        reject(new Error(event.message || "Excel dosyası okunamadı. XLSX, XLS veya CSV dosyası seçin."));
      };
      file.arrayBuffer().then(buffer => worker.postMessage({ buffer, name: file.name }, [buffer]), reject);
    });

  // ---------- İçeri alma akışı ----------
  // Okuma raporu (v2.0.2): sayfa hangi şekilde okundu, hangi satırlar kayıt sayılmadı, kapsam ne. Kullanıcı yüklemeden
  // önce görür; kapsam %90'ın altındaysa uyarı tonunda.
  const SKIP_LABELS = { title: "başlık", note: "not", footnote: "dipnot", group: "grup etiketi", "repeat-header": "yinelenen başlık", unnamed: "adsız kolon", "empty-record": "boş satır" };
  // Ön izleme ve eşleme (v2.0.2): kolonların ne sayıldığı (rol + kesinlik), ilk satırlar; biçimi uymayan hücreler ve
  // belirsiz kolonlar sarı. Kullanıcı kolonun rolünü seçebilir; seçim kaydetmede oturuma yazılır, analiz ve takvim uyar.
  const ROLE_OPTIONS = [["auto", "Otomatik"], ["id", "Kimlik / No"], ["person", "Kişi"], ["org", "Kurum"], ["phone", "Telefon"], ["email", "E-Posta"], ["address", "Adres"], ["money", "Tutar"], ["number", "Sayı (Tutar Değil)"], ["deadline", "Son Tarih / Vade"], ["date", "Tarih (olay)"], ["status", "Durum"], ["category", "Kategori"], ["note", "Not"], ["ignore", "Yok Say"]];
  const ROLE_TEXT = { id: "kimlik", person: "kişi", org: "kurum", money: "tutar", date: "tarih", status: "durum", category: "kategori", phone: "telefon", email: "e-posta", address: "adres", note: "not", tckn: "T.C. no", vkn: "vergi no", iban: "IBAN", city: "il", plate: "plaka", url: "bağlantı", number: "sayı", percent: "oran", sequence: "sıra", responsible: "sorumlu", text: "metin" };
  const roleText = item => (item.role === "date" ? (item.kind === "deadline" ? "son tarih" : item.kind === "event" ? "olay tarihi" : "tarih") : ROLE_TEXT[item.role] || item.role);
  function mappingHtml(mapping) {
    if (!mapping?.columns?.length) return "";
    const suspect = new Map();
    for (const item of mapping.suspicious || []) suspect.set(`${item.row}\u0000${item.column}`, item.reason);
    const head = mapping.columns
      .map(item => `<th class="is-${esc(item.certainty)}"><div class="hof-map-head"><b title="${esc(item.name)}">${esc(item.name)}</b><span class="hof-map-role">${esc(roleText(item))} · ${esc(item.certainty)}</span><select data-role-for="${esc(item.name)}" aria-label="${esc(item.name)} kolonunun rolü">${ROLE_OPTIONS.map(([value, label]) => `<option value="${value}">${label}</option>`).join("")}</select>${item.evidence?.length ? `<small>${item.evidence.map(esc).join(" · ")}</small>` : ""}</div></th>`)
      .join("");
    const body = (mapping.rows || [])
      .map((row, index) => `<tr class="${row.__hofFlag ? "is-flagged" : ""}">${mapping.columns.map(item => {
        const reason = suspect.get(`${index}\u0000${item.name}`) || (row.__hofFlag ? suspect.get(`${index}\u0000`) : "");
        return `<td class="${reason ? "is-suspect" : ""}" ${reason ? `title="${esc(reason)}"` : ""}>${esc(row[item.name] ?? "")}</td>`;
      }).join("")}</tr>`)
      .join("");
    const unsure = mapping.unsure ? `${number(mapping.unsure)} kolonun türü belirsiz (sarı başlık) — açılır listeden seçebilirsiniz.` : "Kolon türleri kendiliğinden tanındı.";
    const flagged = (mapping.rows || []).filter(row => row.__hofFlag).length;
    return `<details class="hof-mapping" open>
      <summary><b>Ön İzleme ve Eşleme</b> · ${number(mapping.total)} satırın ilk ${number((mapping.rows || []).length)}'i · ${esc(unsure)}${flagged ? ` · sarı satırlar “İşaretlenen hatalar”a gider` : ""}</summary>
      <p class="hof-inline-note">Program her kolonu ne saydığını başlıkta yazar (kesin / olası / belirsiz). Yanlışsa açılır listeden doğrusunu seçin; <b>Son Tarih / Vade</b> seçilen kolon takvime girer, <b>Yok Say</b> seçilen kolon uyarı üretmez. Sarı hücreler kolonun türüne uymayan değerlerdir; üzerine gelince neden yazar.</p>
      <div class="hof-mapping-scroll"><table class="hof-mapping-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
    </details>`;
  }
  function chosenRoles(dialog) {
    const roles = {};
    for (const select of dialog.querySelectorAll("select[data-role-for]")) if (select.value && select.value !== "auto") roles[select.dataset.roleFor] = select.value;
    return Object.keys(roles).length ? roles : undefined;
  }
  // İlk yükleme (henüz veri yok): ön izleme + tek düğme.
  function firstImport(staged) {
    const modal = HOF.modal({
      title: `Yeni veri: ${staged.label}`,
      eyebrow: "ÖN İZLEME",
      size: "wide",
      body: `<p class="hof-modal-text">${number(staged.rowCount)} kayıt okundu${staged.tabs.length ? ` (${number(staged.tabs.length)} sekme)` : ""}. Henüz hiçbir şey kaydedilmedi: aşağıda programın tabloyu nasıl anladığını görün, gerekirse kolon türlerini düzeltin, sonra <b>Yükle</b>'ye basın.</p>
        ${readingHtml(staged.reading)}
        ${mappingHtml(staged.mapping)}
        <p class="hof-inline-note">Yüklemeden önce veritabanının yedeği alınır; Excel dosyanız değişmez.</p>
        <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-cancel>Vazgeç</button><button type="button" class="hof-button" data-mode="replace" autofocus>Yükle</button></div>`,
    });
    modal.dialog.querySelector("[data-cancel]").onclick = () => modal.close();
    modal.dialog.querySelector('[data-mode="replace"]').addEventListener("click", async event => {
      const button = event.currentTarget;
      modal.dialog.querySelectorAll("button, select").forEach(item => (item.disabled = true));
      button.classList.add("is-busy");
      button.textContent = "Yükleniyor…";
      try {
        finish(await HOF.api("/api/workspace/dataset/commit", { method: "POST", body: { stageId: staged.stageId, mode: "replace", link: true, roles: chosenRoles(modal.dialog) }, timeoutMs: 180_000 }));
      } catch (error) {
        modal.close();
        HOF.toastError(error);
      }
    });
  }

  // Kolon eşleme (v2.0.2): dosyadaki kolon adları değiştiyse program hangi eski kolonla eşlediğini söyler; düzeltmeler,
  // adlar ve listeler eşlenen kolona taşınır. Eşleme yanlışsa kullanıcı dosyadaki başlığı eski adına döndürebilir.
  function schemaHtml(schema) {
    if (!schema || (!schema.renamed?.length && !schema.added?.length && !schema.removed?.length)) return "";
    const parts = [];
    if (schema.renamed?.length) parts.push(`<p><b>Yeniden Adlandırılan Kolonlar</b> (düzeltmeler ve ayarlar yeni ada taşınır): ${schema.renamed.map(item => `“${esc(item.from)}” → “${esc(item.to)}”<small> · ${esc(item.why)}</small>`).join(", ")}</p>`);
    if (schema.added?.length) parts.push(`<p><b>Yeni Kolonlar:</b> ${schema.added.map(esc).join(", ")}</p>`);
    if (schema.removed?.length) parts.push(`<p><b>Bu dosyada olmayan kolonlar:</b> ${schema.removed.map(esc).join(", ")}<small> · “devamı olarak” eklemede mevcut kayıtlarda kalır, “yerine koy”da kalkar</small></p>`);
    return `<div class="hof-reading hof-schema">${parts.join("")}</div>`;
  }
  function readingHtml(reading) {
    if (!reading || !reading.cells) return "";
    const percent = Math.round((reading.coverage ?? 1) * 100);
    const counts = new Map();
    for (const item of reading.skipped || []) counts.set(item.kind, (counts.get(item.kind) || 0) + 1);
    const summary = [...counts].map(([kind, count]) => `${count} ${SKIP_LABELS[kind] || kind}`).join(", ");
    const warn = percent < 90;
    const lines = (reading.skipped || []).map(item => `<li><b>${esc(item.sheet ? `${item.sheet} · ` : "")}${item.line}. satır</b> · ${esc(SKIP_LABELS[item.kind] || item.kind)}${item.text ? ` · <span>${esc(item.text)}</span>` : ""}</li>`).join("");
    return `<div class="hof-reading ${warn ? "is-warn" : ""}">
      <p><b>Okuma Raporu:</b> hücrelerin %${percent}'i kayda girdi${reading.skippedTotal ? ` · ${number(reading.skippedTotal)} satır kayıt sayılmadı (${esc(summary)})` : " · her satır kayıt oldu"}.${warn ? " <b>Dosyanın önemli bir bölümü kayda giremedi;</b> atlanan satırları kontrol edin, gerekirse Excel'de başlık satırını düzeltip yeniden yükleyin." : ""}</p>
      ${(reading.notes || []).map(note => `<p class="hof-reading-note">${esc(note)}</p>`).join("")}
      ${lines ? `<details><summary>Kayıt Sayılmayan Satırlar${reading.skippedTotal > (reading.skipped || []).length ? ` (ilk ${(reading.skipped || []).length})` : ""}</summary><ul>${lines}</ul></details>` : ""}
    </div>`;
  }
  function progress(title, text) {
    const modal = HOF.modal({ title, eyebrow: "VERİ", size: "small", dismissible: false, body: `<p class="hof-modal-text" data-status>${esc(text)}</p><div class="hof-progress"><span></span></div>` });
    return {
      set(next) {
        const node = modal.dialog.querySelector("[data-status]");
        if (node) node.textContent = next;
      },
      close: () => modal.close(),
    };
  }

  let afterFinish = null; // v2.0.17: dönüştürmede kaydettikten sonra (yenilemeden önce) koşan iş
  async function finish(result) {
    if (afterFinish) {
      const work = afterFinish;
      afterFinish = null;
      try {
        await work(result);
      } catch (error) {
        console.error("[DestekOfis]", error);
      }
    }
    const counts = result.counts || {};
    const name = `"${result.sourceLabel || result.label}"`;
    const parts = [];
    if (counts.added) parts.push(`${number(counts.added)} yeni`);
    if (counts.updated) parts.push(`${number(counts.updated)} güncellendi`);
    if (counts.removed) parts.push(`${number(counts.removed)} kaldırıldı`);
    const detail = parts.length ? parts.join(", ") : "değişiklik yok";
    const head =
      result.mode === "session" ? `${name} yeni sayfada açıldı: “${result.session?.name || ""}”, ${number(result.rowCount)} kayıt. Önceki veriler kendi sayfasında duruyor; ortadaki sayfa şeridinden geçebilirsiniz.`
      : result.mode === "initial" ? `${name} yüklendi: ${number(result.rowCount)} kayıt.`
      : result.mode === "merge" ? `${name} devamı olarak eklendi: ${detail}.`
      : `${name} mevcut verinin yerine kondu: ${detail}.`;
    HOF.applyClientState(result.state);
    sessionStorage.setItem("hof-flash", `${head}${result.mode === "session" ? "" : " Tüm bilgisayarlar aynı veriyi görür."}${result.linked ? " Google Sheets bağlı; değişiklikler kendiliğinden eklenir." : ""}`);
    // İlk yüklemede, "yerine koy"da ve yeni oturumda veri baştan değişti: sayfa açılınca akıllı analiz ekranı gösterilir.
    if (result.mode === "initial" || result.mode === "replace" || result.mode === "session") sessionStorage.setItem("hof-analyze", result.mode === "session" ? "initial" : result.mode);
    // Tablodan taksit kartına aktarma (v2.0.8): sayfa yenilenince, tabloda ödeme planı varsa yöneticiye sorulur.
    if (HOF.can?.("plans.manage")) sessionStorage.setItem("hof-plan-transfer-ask", "1");
    location.reload();
  }

  // options.session: kullanıcı "yeni oturum aç" dedi (oturum seçici); karar penceresinde yeni oturum önerilir.
  async function runImport(body, sourceLabel, options = {}) {
    if (!canManage()) {
      HOF.toast("Veri yükleme ve kaldırma yalnızca yöneticidedir.", { type: "error" });
      return;
    }
    const busy = progress("Veri okunuyor", body.kind === "sheets" ? "Google Sheets okunuyor…" : `"${sourceLabel}" okunuyor…`);
    let staged;
    try {
      if (body.kind === "excel" && body.sheets) {
        // v2.0.17: serbest sayfadan "Veri Sekmesine Dönüştür" — matris hazır gelir, aynı ön izleme/eşleme ekranından geçer.
        staged = await HOF.api("/api/workspace/dataset/stage", { method: "POST", body: { kind: "excel", fileName: body.fileName, sheets: body.sheets }, timeoutMs: 120_000 });
      } else if (body.kind === "excel" && body.file) {
        const parsed = await parseInWorker(body.file);
        if (!parsed.rowCount) throw new Error("Dosyada okunabilir kayıt bulunamadı. Tablonun kolon başlıklarıyla başladığından emin olun.");
        busy.set(`Yaklaşık ${number(parsed.rowCount)} satır mevcut veriyle karşılaştırılıyor…`);
        staged = await HOF.api("/api/workspace/dataset/stage", { method: "POST", body: { kind: "excel", fileName: body.file.name, sheets: parsed.sheets, ...(parsed.definedNames ? { definedNames: parsed.definedNames } : {}) }, timeoutMs: 180_000 });
      } else {
        staged = await HOF.api("/api/workspace/dataset/stage", { method: "POST", body: { kind: "sheets", url: body.url }, timeoutMs: 120_000 });
      }
    } catch (error) {
      busy.close();
      HOF.toastError(error);
      return;
    }
    if (!staged.hasData) {
      // v2.0.2: ilk yüklemede de veri doğrudan yazılmaz; ön izleme ve eşleme ekranı açılır, kullanıcı onaylar.
      busy.close();
      firstImport(staged);
      return;
    }
    if (false) {
      try {
        finish(await HOF.api("/api/workspace/dataset/commit", { method: "POST", body: { stageId: staged.stageId, mode: "replace", link: true }, timeoutMs: 180_000 }));
      } catch (error) {
        busy.close();
        HOF.toastError(error);
      }
      return;
    }
    busy.close();
    afterFinish = typeof options.onDone === "function" ? options.onDone : null;
    decide(staged, options);
  }

  // 31e B1–B3: kayda bağlı veriler (tahsilat, not, düzeltme, "Ödendi Say", cari bağı…). Sunucu güvenli eşleşeni yeni satıra taşır; eşleşmeyeni ve
  // Devamı olarak eklemede mevcut kayıtla aynı görünen satırı adlarıyla söyler, onay ister (onaysız uygulama 409).
  const bondNames = info => `${(info.names || []).join(", ")}${info.more ? ` ve ${number(info.more)} kayıt daha` : ""}`;
  function bondWarnings(bonds, mode) {
    const info = bonds?.[mode];
    if (!info) return { html: "", lines: [] };
    const lines = [];
    const html = [];
    if (info.unmatched?.count) {
      const text = info.unmatched.text || `${number(info.unmatched.count)} kaydın ${(info.unmatched.labels || []).join(" / ")} bu yüklemeyle eşleşmedi: ${bondNames(info.unmatched)}.`;
      lines.push(`${text} Bu bağlar silinmez, eski kayıtta kalır ama yeni satırlarda görünmez (ödemiş kişi Takvim'de ve raporlarda ödememiş görünür).`);
      html.push(`<p class="hof-alert" data-bond-unmatched="${mode}">${esc(text)} Silinmez, eski kayıtta kalır ama yeni satırlarda görünmez.</p>`);
    }
    if (mode === "merge" && info.duplicates?.count) {
      const text = `${number(info.duplicates.count)} satır mevcut kayıtlarla aynı görünüyor${info.duplicates.names?.length ? ` (${info.duplicates.names.join(", ")})` : ""}; aynı dosyanın yenisiyse Yerine Koy kullanın.`;
      lines.push(`${text} Devamı Olarak Ekle bunları ikinci kez ekler.`);
      html.push(`<p class="hof-alert" data-bond-duplicates>${esc(text)}</p>`);
    }
    if (mode === "merge" && info.samePerson?.count) {
      const text = `${number(info.samePerson.count)} yeni satır mevcut bir kaydın kişisini taşıyor${info.samePerson.names?.length ? ` (${info.samePerson.names.join(", ")})` : ""}; Devamı Olarak Ekle bunları ayrı kayıt olarak ekler, mevcut kaydı güncellemek için Yerine Koy kullanın.`;
      lines.push(text);
      html.push(`<p class="hof-alert" data-bond-same-person>${esc(text)}</p>`);
    }
    if (mode === "merge" && info.differentPerson) html.push(`<p class="hof-inline-note" data-bond-different>Aynı satırda kişisi değişen ${number(info.differentPerson)} satır mevcut kaydın yerine geçmez; yeni kayıt olarak eklenir.</p>`);
    if (info.moved?.count) html.push(`<p class="hof-inline-note" data-bond-moved="${mode}">${number(info.moved.count)} kaydın ${esc((info.moved.labels || []).join(" / "))} aynı kişinin yeni satırına taşınır.</p>`);
    return { html: html.join(""), lines };
  }

  // "Devamı olarak ekle" / "Yerine koy" kararı; sayılar sunucunun gerçek karşılaştırmasından gelir.
  function decide(staged, options = {}) {
    const { merge, replace, samples } = staged.preview;
    const mergeBonds = bondWarnings(staged.bonds, "merge");
    const replaceBonds = bondWarnings(staged.bonds, "replace");
    const sample = (label, list) => (list.length ? `<span><b>${esc(label)}:</b> ${list.map(esc).join(", ")}${list.length === 5 ? "…" : ""}</span>` : "");
    const samplesHtml = [sample("yeni", samples.added), sample("güncellenecek", samples.updated), sample("yeni dosyada olmayan", samples.removed)].filter(Boolean).join("");
    const minutes = Number(summary?.syncMinutes || HOF.settings.syncMinutes || 5);
    // v2.0.1: farklı konudaki dosya (kolonları mevcut veriyle az örtüşen) yeni oturumda açılmalı; veriler karışmaz.
    const different = Boolean(staged.differentTopic);
    const preferSession = different || Boolean(options.session);
    const defaultName = String(staged.label || "").replace(/\.(xlsx|xls|csv)$/i, "").trim() || "Yeni sayfa";
    const overlap = staged.similarity == null ? "" : ` (ortak kolon oranı %${Math.round(staged.similarity * 100)})`;
    const modal = HOF.modal({
      title: `Yeni veri: ${staged.label}`,
      eyebrow: "VERİ",
      size: "wide",
      body: `<p class="hof-modal-text">${number(staged.rowCount)} kayıt okundu${staged.tabs.length ? ` (${number(staged.tabs.length)} sekme)` : ""}. Şu anki sayfa: <b>${esc(staged.session?.current || staged.current.label || "Çalışma Verisi")}</b>, ${number(staged.current.rowCount)} kayıt. Nasıl açılsın?</p>
        ${readingHtml(staged.reading)}
        ${schemaHtml(staged.schema)}
        ${mappingHtml(staged.mapping)}
        ${different ? `<div class="hof-alert">Bu dosya şu anki veriden <b>farklı bir konuda</b> görünüyor${esc(overlap)}. Veriler birbirine karışmasın diye <b>yeni sayfada açmanızı</b> öneririz.</div>` : ""}
        <article class="hof-choice hof-choice-session ${preferSession ? "is-recommended" : ""}">
          <header><b>Yeni Sayfada Aç</b>${preferSession ? '<span class="hof-chip">Önerilen</span>' : ""}</header>
          <p>Dosya ayrı bir çalışma alanında açılır; şu anki veri, düzeltmeleri ve kayıtlarıyla olduğu gibi kalır. Sayfalar arasında ortadaki <b>sayfa şeridinden</b> geçilir; takvim, uyarılar ve raporlar bütün sayfaları kapsar.</p>
          <div class="hof-choice-session-row">
            <label class="hof-field"><span>Sayfanın Adı</span><input type="text" data-session-name maxlength="80" value="${esc(defaultName)}" ${preferSession ? "autofocus" : ""} placeholder="Ör. Taksit takibi 2026" autocomplete="off"></label>
            <button type="button" class="hof-button ${preferSession ? "" : "hof-button-ghost"}" data-mode="session">Yeni Sayfada Aç</button>
          </div>
        </article>
        <div class="hof-choice-grid">
          <article class="hof-choice ${preferSession ? "" : "is-recommended"}">
            <header><b>Mevcut Verinin Devamı Olarak Ekle</b>${preferSession ? "" : '<span class="hof-chip">Önerilen</span>'}</header>
            <ul>
              <li><b>${number(merge.added)}</b> yeni kayıt eklenir</li>
              <li><b>${number(merge.updated)}</b> kayıt yeni bilgilerle güncellenir</li>
              <li><b>${number(merge.unchanged)}</b> kayıt aynı kalır</li>
              <li>Yeni dosyada olmayan <b>${number(merge.kept)}</b> kayıt silinmez</li>
            </ul>
            <p>Ofiste yapılan düzeltmeler, notlar ve görevler korunur.</p>
            ${mergeBonds.html}
            <button type="button" class="hof-button ${preferSession ? "hof-button-ghost" : ""}" data-mode="merge" ${preferSession ? "" : "autofocus"}>Devamı Olarak Ekle</button>
          </article>
          <article class="hof-choice">
            <header><b>Mevcut Verinin Yerine Koy</b></header>
            <ul>
              <li><b>${number(replace.added)}</b> yeni, <b>${number(replace.updated)}</b> güncellenen, <b>${number(replace.unchanged)}</b> aynı kayıt</li>
              <li>Yeni dosyada olmayan <b>${number(replace.removed)}</b> kayıt tablodan kalkar</li>
            </ul>
            <p>Notlar, tahsilatlar, düzeltmeler ve cari bağları silinmez. Kayıt yeni dosyada da varsa (aynı dosya numarası ya da aynı kişi tek satırda) ona bağlı kalır; eşleşmeyen olursa burada adıyla yazar.</p>
            ${replaceBonds.html}
            <button type="button" class="hof-button hof-button-ghost" data-mode="replace">Yerine Koy</button>
          </article>
        </div>
        ${samplesHtml ? `<p class="hof-choice-samples">Örnek: ${samplesHtml}</p>` : ""}
        ${staged.kind === "sheets" ? `<label class="hof-check"><input type="checkbox" data-link checked><span>Bu Sheet'i bağlı tut; Sheet'teki değişiklikler her ${minutes} dakikada kendiliğinden eklensin</span></label>` : ""}
        <p class="hof-inline-note">Uygulamadan önce veritabanının tam yedeği alınır.</p>
        <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-cancel>Vazgeç</button></div>`,
    });
    modal.dialog.querySelector("[data-cancel]").onclick = () => modal.close();
    const sessionName = modal.dialog.querySelector("[data-session-name]");
    sessionName.addEventListener("keydown", event => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      modal.dialog.querySelector('[data-mode="session"]').click();
    });
    if (preferSession) setTimeout(() => sessionName.select(), 60);
    modal.dialog.addEventListener("click", async event => {
      const button = event.target.closest("[data-mode]");
      if (!button) return;
      const mode = button.dataset.mode;
      // 31e B2: onay metni gerçeği söyler — kalkan kayıt sayısı ve (varsa) yeni satırlara bağlanamayan tahsilat / not / bağ, adlarıyla.
      const warnings = mode === "replace" ? replaceBonds.lines : mode === "merge" ? mergeBonds.lines : [];
      let confirm = false;
      if ((mode === "replace" && replace.removed > 0) || warnings.length) {
        const head = mode === "replace" && replace.removed > 0 ? `Yeni dosyada olmayan ${number(replace.removed)} kayıt tablodan kalkacak.` : "";
        const message = [head, ...warnings, "İşlemden önce yedek alınır. Devam edilsin mi?"].filter(Boolean).join(" ");
        const label = mode === "replace" ? "Yerine Koy" : "Devamı Olarak Ekle";
        const ok = await HOF.confirm({ title: label, message, confirmLabel: label, danger: mode === "replace" || warnings.length > 0 });
        if (!ok) return;
        confirm = warnings.length > 0;
      }
      const link = staged.kind === "sheets" ? Boolean(modal.dialog.querySelector("[data-link]")?.checked) : true;
      const nameInput = modal.dialog.querySelector("[data-session-name]");
      const name = String(nameInput?.value || "").replace(/\s+/g, " ").trim();
      if (mode === "session" && !name) {
        nameInput.focus();
        return HOF.toast("Yeni sayfaya bir ad verin.", { type: "error" });
      }
      modal.dialog.querySelectorAll("button, input").forEach(item => (item.disabled = true));
      button.classList.add("is-busy");
      button.textContent = mode === "session" ? "Sayfa açılıyor…" : "Uygulanıyor…";
      try {
        finish(await HOF.api("/api/workspace/dataset/commit", { method: "POST", body: { stageId: staged.stageId, mode, link, name, roles: chosenRoles(modal.dialog), ...(confirm ? { confirm: true } : {}) }, timeoutMs: 180_000 }));
      } catch (error) {
        modal.close();
        HOF.toastError(error);
      }
    });
  }

  function importExcel(file, options = {}) {
    if (!/\.(xlsx|xls|csv)$/i.test(file.name)) {
      HOF.toast("Yalnızca .xlsx, .xls ve .csv dosyaları yüklenebilir.", { type: "error" });
      return;
    }
    if (file.size > MAX_BYTES) {
      HOF.toast("Dosya çok büyük (en fazla 60 MB).", { type: "error" });
      return;
    }
    runImport({ kind: "excel", file }, file.name, options);
  }

  function importSheet(url, options = {}) {
    const value = String(url || "").trim();
    if (!SHEET_PATTERN.test(value)) {
      HOF.toast("Google Sheets bağlantısını yapıştırın (https://docs.google.com/spreadsheets/… ile başlar).", { type: "error" });
      return;
    }
    runImport({ kind: "sheets", url: value }, "Google Sheets", options);
  }

  // Sürükle-bırak ve dosya seçimi olan bir alanı bağlar.
  function wireDrop(zone, options = {}) {
    const input = zone.querySelector("input[type=file]");
    input.addEventListener("change", () => {
      const file = input.files && input.files[0];
      input.value = "";
      if (file) importExcel(file, options);
    });
    zone.addEventListener("dragover", event => {
      event.preventDefault();
      zone.classList.add("is-over");
    });
    zone.addEventListener("dragleave", () => zone.classList.remove("is-over"));
    zone.addEventListener("drop", event => {
      event.preventDefault();
      zone.classList.remove("is-over");
      const file = event.dataTransfer?.files?.[0];
      if (file) importExcel(file, options);
    });
  }

  const dropHtml = compact => `<label class="hof-drop${compact ? " is-compact" : ""}">
      <span class="hof-drop-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M12 12v6"/><path d="m9.5 14.5 2.5-2.5 2.5 2.5"/></svg></span>
      <span><b>Excel Dosyası Seçin</b><small>veya buraya sürükleyip bırakın · .xlsx, .xls, .csv</small></span>
      <input type="file" accept=".xlsx,.xls,.csv" hidden>
    </label>`;
  const linkHtml = `<form class="hof-link-form" novalidate>
      <input type="url" name="url" inputmode="url" autocomplete="off" placeholder="Google Sheets bağlantısını yapıştırın" aria-label="Google Sheets bağlantısı">
      <button type="submit" class="hof-button">Bağla</button>
    </form>`;
  // Sektöre uygun taslak Excel (v2.0.9): Excel'i olmayan ofis sektörünü seçer, taslak indirilir; doldurup buradan yükler.
  const templateHtml = `<div class="hof-start-template"><span class="hof-start-template-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M3.5 9h17M9 3.5v17"/><path d="M14 14.5v4M12 16.5l2 2 2-2"/></svg></span><span><b>Exceliniz yok mu?</b><small>Sektörünüze uygun taslak Excel'i indirin, doldurun ve buradan yükleyin. Kolonlar hazırdır; başlığa tıklayınca ne yazılacağı görünür.</small></span><button type="button" class="hof-button hof-button-small" data-template>Taslak Excel'i İndir</button></div>`;
  async function downloadTemplate() {
    const current = HOF.profile?.()?.sector?.id || "";
    const pick = HOF.chooseSector || HOF.pickSector;
    if (!pick) return;
    const id = await pick({ title: "Taslak Excel: sektörünüzü seçin", suggested: current && current !== "genel" ? current : "", intro: "Seçtiğiniz sektöre uygun kolonlarla boş bir Excel indirilir. Doldurup açılış ekranından yüklediğinizde program sektörü, kişileri, tutarları ve ödeme günlerini kendiliğinden tanır." });
    if (!id) return;
    const link = document.createElement("a");
    link.href = `/api/workspace/templates/${encodeURIComponent(id)}/xlsx`;
    link.download = "";
    document.body.appendChild(link);
    link.click();
    link.remove();
    HOF.toast("Taslak Excel indirildi. Satırları doldurup kaydedin, sonra bu ekrandan yükleyin.", { type: "success", timeout: 8000 });
  }
  const wireTemplate = node => node?.querySelector("[data-template]")?.addEventListener("click", downloadTemplate);
  const wireLink = (form, options = {}) =>
    form.addEventListener("submit", event => {
      event.preventDefault();
      importSheet(form.elements.url.value, options);
    });

  // ---------- Başlangıç kartı (veri yokken) ----------
  function renderStart() {
    const wrap = document.querySelector(".main-shell .content-wrap");
    let card = document.getElementById("hof-start");
    const empty = Boolean(wrap) && HOF.isReady && !hasData();
    document.documentElement.classList.toggle("hof-no-data", empty);
    if (!empty) {
      card?.remove();
      return;
    }
    if (!card) {
      card = HOF.el("section", { id: "hof-start", class: "hof-start", "aria-labelledby": "hof-start-title" });
      card.innerHTML = `<div class="hof-start-card">
          <span class="hof-start-mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 9.5h18M9 9.5V20"/></svg></span>
          <h2 id="hof-start-title">Excelini yükle ya da Google Sheets linkini yapıştır, başlayalım</h2>
          <p>Veriler bu sunucuda saklanır ve ofisteki tüm bilgisayarlarda aynı görünür. Siz silmedikçe korunur; sonradan yapılan işlemlerle birlikte devam eder.</p>
          ${canManage()
            ? `<div class="hof-start-actions">${dropHtml(false)}<div class="hof-start-or"><span>veya</span></div>${linkHtml}<small class="hof-start-hint">Sheet paylaşımı "Bağlantıya sahip olan herkes görüntüleyebilir" olmalıdır.</small></div>${templateHtml}`
            : '<p class="hof-start-wait">Yöneticiniz veri yüklediğinde tablo burada görünecek.</p>'}
          <p class="hof-start-guide">İlk kez mi kullanıyorsunuz? <a href="/kilavuz/DestekOfis-Kullanim-Kilavuzu.pdf" target="_blank" rel="noopener">Resimli kullanım kılavuzunu açın</a>.<small>Teknik Destek ve Satın Alımlar İçin: <a href="tel:+905367715055">0536 771 50 55</a></small></p>
        </div>`;
      const zone = card.querySelector(".hof-drop");
      if (zone) wireDrop(zone);
      const form = card.querySelector(".hof-link-form");
      if (form) wireLink(form);
      wireTemplate(card);
    }
    const anchor = wrap.querySelector(":scope > .welcome-row");
    if (card.parentNode !== wrap) (anchor ? anchor.after(card) : wrap.prepend(card));
  }

  // ---------- Ayarlar → Veri ----------
  function sourceLine(data) {
    if (!data.rowCount && !data.linked) return "Henüz veri yok.";
    if (data.linked) {
      const last = data.lastSyncOkAt ? HOF.formatDateTime(data.lastSyncOkAt) : "henüz eşitlenmedi";
      return `Google Sheets'e bağlı · son eşitleme ${last} · her ${data.syncMinutes} dakikada`;
    }
    const lastImport = data.imports?.find(item => item.kind !== "remove");
    return `${lastImport?.kind === "sheets" ? "Google Sheets'ten alındı (bağlı değil)" : "Excel'den yüklendi"}${data.changedAt ? ` · ${HOF.formatDateTime(data.changedAt)}` : ""}`;
  }

  const MODE_LABELS = { initial: "ilk yükleme", merge: "devamı olarak eklendi", replace: "yerine konuldu", sync: "eşitlendi", migration: "kalıcı veriye geçiş", remove: "veri kaldırıldı", keep: "Sheet'te olmayanlar tutuldu" };
  function historyHtml(imports) {
    if (!imports?.length) return '<p class="hof-empty">Henüz içeri alma yok.</p>';
    return imports
      .map(item => {
        const counts = [item.added ? `${number(item.added)} yeni` : "", item.updated ? `${number(item.updated)} güncellendi` : "", item.removed ? `${number(item.removed)} kaldırıldı` : "", item.missing ? `${number(item.missing)} Sheet'te yok` : ""].filter(Boolean).join(", ");
        const what = item.kind === "missing" ? (item.mode === "remove" ? "Sheet'te olmayanlar kaldırıldı" : MODE_LABELS.keep) : `${item.label ? `"${item.label}" · ` : ""}${MODE_LABELS[item.mode] || item.mode}`;
        return `<li><span>${esc(HOF.formatDateTime(item.createdAt))}</span><b>${esc(what)}</b>${counts ? `<small>${esc(counts)}</small>` : ""}<em>${esc(item.actorName || "")}</em></li>`;
      })
      .join("");
  }

  // options.focus === "sessions": pencere "Oturumlar" bölümüne kaydırılarak açılır (oturum seçicideki bağlantı).
  async function openDataSettings(options = {}) {
    if (!canManage()) {
      HOF.toast("Veri ayarları yalnızca yöneticidedir.", { type: "error" });
      return;
    }
    const [summaryData, sessions] = await Promise.all([loadSummary(), HOF.sessions?.section?.().catch(() => null)]);
    const data = summaryData || {};
    const minutes = Number(data.syncMinutes || 5);
    // Diğer modüllerin bölümleri (ör. "Sektör ve görünüm", hof-insight.js) veri özetinin altına eklenir.
    // 2.4.6 madde 4 (baş mimar, kör nokta): bölüm veri yokken de görünür — tablosuz (yalnız cari kullanan) şirket de sektörünü seçebilsin
    // (Maliyet Hesap Kartı yalnız "Duşakabin Üretimi" sektöründe açılır; önceden boş şirkette sektör hiçbir yerden seçilemiyordu).
    const extensions = (HOF.settingsExtensions || []).map(extension => {
      try {
        return extension.html() || "";
      } catch (error) {
        console.error("[DestekOfis]", error);
        return "";
      }
    }).join("");
    const modal = HOF.modal({
      title: "Veri ve Eşitleme",
      eyebrow: "AYARLAR",
      size: "wide",
      body: `<section class="hof-data-summary">
          <div><b>${esc(data.label || (data.rowCount ? "Çalışma Verisi" : "Veri Yok"))}</b><span>${number(data.rowCount)} kayıt${data.tabs?.length ? ` · ${number(data.tabs.length)} sekme` : ""}${data.recordCount ? ` · uygulamada eklenen ${number(data.recordCount)} kayıt` : ""}</span><small>${esc(sourceLine(data))}</small></div>
          ${data.lastSyncError ? `<p class="hof-alert">Son eşitlemede Google Sheets'e ulaşılamadı: ${esc(data.lastSyncError)} Son eşitlenen veri kullanılmaya devam ediyor.</p>` : ""}
          ${data.syncHold ? `<p class="hof-alert" data-sync-hold="${esc(data.syncHold.reason || "structure")}">${data.syncHold.reason === "bonds" ? `${esc(data.syncHold.bonds?.text || "Sheet'teki değişiklik bazı kayıtların tahsilat, not ya da bağlarını yeni satırlara bağlayamıyor.")} Bağlar sessizce kopmasın diye otomatik eşitleme durduruldu.` : `Sheet'in yapısı değişmiş görünüyor (${number(data.syncHold.added)} yeni, ${number(data.syncHold.missing)} kayıp satır). Yanlışlıkla veri çoğalmasın diye otomatik eşitleme durduruldu.`} <button type="button" class="hof-button hof-button-small" data-review>İncele ve karar ver</button></p>` : ""}
          ${data.missingCount ? `<p class="hof-alert hof-alert-soft">${number(data.missingCount)} kayıt bağlı Sheet'te artık yok; tabloda duruyor. <button type="button" class="hof-button hof-button-small hof-button-ghost" data-missing>Listeyi Gör</button></p>` : ""}
        </section>
        ${sessions?.html || ""}
        ${extensions}
        <section class="hof-data-section">
          <h3>Veri Ekle veya Değiştir</h3>
          <div class="hof-data-import">${dropHtml(true)}${linkHtml}</div>${templateHtml}
          <p class="hof-modal-text hof-muted">Mevcut veri varsa önce ne değişeceği gösterilir; "yeni sayfada aç", "devamı olarak ekle" ya da "yerine koy" seçersiniz.</p>
        </section>
        ${data.linked
          ? `<section class="hof-data-section">
          <h3>Google Sheets Eşitlemesi</h3>
          <div class="hof-data-row">
            <label class="hof-field hof-field-inline"><span>Sıklık</span><select data-minutes>${[5, 15, 60].map(value => `<option value="${value}" ${value === minutes ? "selected" : ""}>${value === 60 ? "Saatte bir" : `${value} dakikada bir`}</option>`).join("")}</select></label>
            <button type="button" class="hof-button hof-button-small" data-sync>Şimdi Eşitle</button>
            <a class="hof-button hof-button-small hof-button-ghost" href="${esc(data.linkedSheetUrl)}" target="_blank" rel="noopener">Sheet'i Aç</a>
            <button type="button" class="hof-button hof-button-small hof-button-ghost" data-unlink>Bağlantıyı Kaldır</button>
          </div>
        </section>`
          : ""}
        <section class="hof-data-section">
          <h3>Geçmiş</h3>
          <ul class="hof-history">${historyHtml(data.imports)}</ul>
        </section>
        ${data.rowCount
          ? `<section class="hof-data-section hof-danger-zone">
          <div><b>Veriyi Kaldır</b><small>İçeri alınan tüm satırlar tablodan kalkar. Notlar, görevler ve işlem geçmişi silinmez; öncesinde yedek alınır.</small></div>
          <button type="button" class="hof-button hof-button-small hof-button-danger" data-remove>Veriyi Kaldır</button>
        </section>`
          : ""}`,
    });
    const dialog = modal.dialog;
    sessions?.wire?.(modal);
    if (options.focus === "sessions") dialog.querySelector("#hof-session-section")?.scrollIntoView({ block: "start" });
    for (const extension of HOF.settingsExtensions || []) {
      try {
        extension.wire?.(modal);
      } catch (error) {
        console.error("[DestekOfis]", error);
      }
    }
    wireTemplate(dialog);
    const zone = dialog.querySelector(".hof-drop");
    if (zone) {
      wireDrop(zone);
      zone.querySelector("input").addEventListener("change", () => modal.close(), { once: true });
      zone.addEventListener("drop", () => modal.close(), { once: true });
    }
    const form = dialog.querySelector(".hof-link-form");
    if (form) {
      if (data.linkedSheetUrl) form.elements.url.value = data.linkedSheetUrl;
      form.addEventListener("submit", () => SHEET_PATTERN.test(form.elements.url.value.trim()) && modal.close());
      wireLink(form);
    }
    dialog.querySelector("[data-minutes]")?.addEventListener("change", async event => {
      try {
        HOF.applyClientState(await HOF.api("/api/workspace/client-state", { method: "PUT", body: { key: "syncMinutes", value: event.target.value } }));
        HOF.toast("Eşitleme sıklığı kaydedildi.", { type: "success" });
      } catch (error) {
        HOF.toastError(error);
      }
    });
    dialog.querySelector("[data-sync]")?.addEventListener("click", async event => {
      const button = event.currentTarget;
      button.disabled = true;
      button.textContent = "Eşitleniyor…";
      try {
        const result = await HOF.api("/api/workspace/dataset/sync", { method: "POST", timeoutMs: 120_000 });
        modal.close();
        if (result.held) HOF.toast(result.hold?.reason === "bonds" ? `${result.hold.bonds?.text || "Sheet'teki değişiklik bazı kayıtların bağlarını yeni satırlara bağlayamıyor."} Eşitleme onayınızı bekliyor (Ayarlar → Veri → İncele ve karar ver).` : "Sheet'in yapısı değişmiş görünüyor; eşitleme onayınızı bekliyor (Ayarlar → Veri).", { type: "error", timeout: 10000 });
        else if (!result.ok) HOF.toast(result.message || "Google Sheets okunamadı.", { type: "error", timeout: 7000 });
        else {
          const counts = result.counts || {};
          const changed = counts.added + counts.updated + counts.missing;
          HOF.toast(changed ? `Eşitlendi: ${number(counts.added)} yeni, ${number(counts.updated)} güncellendi${counts.missing ? `, ${number(counts.missing)} Sheet'te yok` : ""}.` : "Eşitlendi; değişiklik yok.", { type: "success" });
          if (changed) HOF.refreshData();
        }
      } catch (error) {
        button.disabled = false;
        button.textContent = "Şimdi Eşitle";
        HOF.toastError(error);
      }
    });
    dialog.querySelector("[data-review]")?.addEventListener("click", () => {
      modal.close();
      importSheet(data.linkedSheetUrl);
    });
    dialog.querySelector("[data-missing]")?.addEventListener("click", () => {
      modal.close();
      openMissing();
    });
    dialog.querySelector("[data-unlink]")?.addEventListener("click", async () => {
      const ok = await HOF.confirm({ title: "Bağlantıyı Kaldır", message: "Google Sheets eşitlemesi durur. Şu ana kadar alınan veri tabloda kalır ve kullanılmaya devam eder.", confirmLabel: "Bağlantıyı Kaldır" });
      if (!ok) return;
      try {
        await HOF.api("/api/workspace/dataset/unlink", { method: "POST" });
        modal.close();
        HOF.toast("Sheet bağlantısı kaldırıldı; veri yerinde.", { type: "success" });
        await loadSummary();
      } catch (error) {
        HOF.toastError(error);
      }
    });
    dialog.querySelector("[data-remove]")?.addEventListener("click", async () => {
      const ok = await HOF.confirm({ title: "Veriyi Kaldır", message: `${number(data.rowCount)} kayıt tüm bilgisayarlarda tablodan kalkacak. Notlar, görevler ve işlem geçmişi silinmez; işlemden önce yedek alınır.`, confirmLabel: "Veriyi Kaldır", danger: true });
      if (!ok) return;
      try {
        const result = await withBondConfirm(confirm => HOF.api(`/api/workspace/dataset${confirm ? "?confirm=1" : ""}`, { method: "DELETE" }), "Veriyi Kaldır", "Veriyi Kaldır");
        if (!result) return;
        HOF.applyClientState(result.state);
        sessionStorage.setItem("hof-flash", `Veri kaldırıldı (${number(result.removed)} kayıt). Yedek: ${result.backupName || "—"}`);
        location.reload();
      } catch (error) {
        HOF.toastError(error);
      }
    });
  }

  // 31e tur 7 N5: kayıt kaldıran istek (Veriyi Kaldır, Sheet'te Olmayanları Kaldır) kalkacak kayıtlara bağlı veri varsa 409 bonds-unmatched döner; ileti
  // adları söyler, yönetici onaylarsa istek onayla yinelenir (sunucu her seferinde yeniden hesaplar).
  async function withBondConfirm(send, title, confirmLabel) {
    try {
      return await send(false);
    } catch (error) {
      if (error?.status !== 409 || error.data?.code !== "bonds-unmatched") throw error;
      const message = `${String(error.message || "").replace(/\s*Onaylayarak yeniden deneyin\.$/, "")} İşlemden önce yedek alınır. Devam edilsin mi?`;
      const ok = await HOF.confirm({ title, message, confirmLabel, danger: true });
      if (!ok) return null;
      return send(true);
    }
  }

  async function openMissing() {
    let rows;
    try {
      rows = await HOF.api("/api/workspace/dataset/missing");
    } catch (error) {
      HOF.toastError(error);
      return;
    }
    const modal = HOF.modal({
      title: "Sheet'te Artık Olmayan Kayıtlar",
      eyebrow: "VERİ",
      size: "wide",
      body: `<p class="hof-modal-text">Bu kayıtlar bağlı Google Sheets'ten silinmiş veya taşınmış. DestekOfis onları kendiliğinden silmez. <b>Tut</b> derseniz bir daha işaretlenmez; <b>Kaldır</b> derseniz tablodan çıkar (öncesinde yedek alınır). Tahsilatı, notu ya da düzeltmesi olan kayıtta “Bağlı:” yazar; bu bağlar silinmez ama kayıt kalkınca tabloda görünmez, kaldırmadan önce sorulur.</p>
        <label class="hof-check"><input type="checkbox" data-all checked><span>Tümünü Seç (${number(rows.length)})</span></label>
        <ul class="hof-missing-list">${rows.map(row => `<li><label class="hof-check"><input type="checkbox" value="${esc(row.rowId)}" checked><span><b>${esc(row.caseKey.startsWith("satir:") ? "Kimliksiz satır" : row.caseKey)}</b>${row.tab ? ` · ${esc(row.tab)}` : ""}<small>${esc(row.preview.join(" · "))}</small>${row.bonds?.length ? `<small class="hof-missing-bonds" data-missing-bonds>Bağlı: ${esc(row.bonds.join(", "))}</small>` : ""}</span></label></li>`).join("")}</ul>
        <div class="hof-actions"><button type="button" class="hof-button hof-button-ghost" data-action="keep">Seçilenleri Tut</button><button type="button" class="hof-button hof-button-danger" data-action="remove">Seçilenleri Kaldır</button></div>`,
    });
    const boxes = () => [...modal.dialog.querySelectorAll(".hof-missing-list input[type=checkbox]")];
    modal.dialog.querySelector("[data-all]").addEventListener("change", event => boxes().forEach(box => (box.checked = event.target.checked)));
    modal.dialog.addEventListener("click", async event => {
      const action = event.target.closest("[data-action]")?.dataset.action;
      if (!action) return;
      const rowIds = boxes().filter(box => box.checked).map(box => box.value);
      if (!rowIds.length) {
        HOF.toast("Önce kayıt seçin.", { type: "error" });
        return;
      }
      try {
        const result = await withBondConfirm(confirm => HOF.api("/api/workspace/dataset/missing", { method: "POST", body: { action, rowIds, ...(confirm ? { confirm: true } : {}) } }), "Seçilenleri Kaldır", "Kaldır");
        if (!result) return;
        modal.close();
        HOF.toast(action === "remove" ? `${number(result.changed)} kayıt tablodan kaldırıldı.` : `${number(result.changed)} kayıt tutuldu.`, { type: "success" });
        await loadSummary();
        HOF.refreshData();
      } catch (error) {
        HOF.toastError(error);
      }
    });
  }

  // ---------- Arayüz paketinin yükleme girişlerini yönlendirme ----------
  const navLabel = element => (element?.textContent || "").trim();
  // Kenar çubuğundaki "Ayarlar" bizim Veri penceremizi açar; paketin kendi kaynak penceresi açılmaz.
  document.addEventListener(
    "click",
    event => {
      const item = event.target.closest(".sidebar .nav-item, .banner-link, .button-row button, .detail-actions button");
      if (!item) return;
      const label = navLabel(item);
      const intercept = label === "Ayarlar" || label === "Tabloyu değiştir" || label.includes("Yeni tablo yükle") || label.includes("Kaynağı değiştir");
      if (intercept) {
        event.preventDefault();
        event.stopImmediatePropagation();
        openDataSettings();
      } else if (label.includes("Sheet'te aç")) {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (HOF.settings.linkedSheetUrl) window.open(HOF.settings.linkedSheetUrl, "_blank", "noopener");
      }
    },
    true,
  );
  // Paketin kaynak penceresi yine de açılırsa (klavye kısayolu vb.) kapatılır ve yerine Veri penceresi açılır.
  function replaceLegacyModal() {
    const legacy = document.querySelector(".settings-modal");
    if (!legacy) return;
    const cancel = [...legacy.querySelectorAll(".modal-actions button")].find(button => navLabel(button) === "Vazgeç");
    cancel?.click();
    if (!document.querySelector(".hof-modal-backdrop")) openDataSettings();
  }
  // Paketin Excel okuyucusu devre dışı: dosya bizim akışımıza gider.
  window.addEventListener(
    "change",
    event => {
      const input = event.target;
      if (!(input instanceof HTMLInputElement) || input.type !== "file" || !input.closest(".source-dropzone")) return;
      event.stopImmediatePropagation();
      event.stopPropagation();
      const file = input.files && input.files[0];
      input.value = "";
      if (file) importExcel(file);
    },
    true,
  );

  const setHidden = (element, hidden) => {
    const display = hidden ? "none" : "";
    if (element.style.display !== display) element.style.display = display;
  };
  // v2.0.11: "Ayarlar" kenar çubuğunun üstünden (oturum kartının altı) kullanıcı kartının altına taşındı. Paketin kendi
  // düğmesi React'e ait olduğundan taşınmaz, gizlenir; yerine bizim düğmemiz Operasyon merkezi kartının hemen altına
  // konur (paket yeniden çizse de yerinde kalır). Yetki kuralı aynı: yalnız veri yükleme yetkisi olan görür.
  const GEAR = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>';
  function placeSettings() {
    const card = document.getElementById("hof-sidecard");
    let button = document.getElementById("hof-side-settings");
    if (!card || !canManage()) {
      button?.remove();
      return;
    }
    if (!button) {
      button = HOF.el("button", { type: "button", id: "hof-side-settings", class: "hof-side-settings", title: "Veri yükleme, sayfalar ve bağlı tablo" }, `${GEAR}<span>Ayarlar</span>`);
      button.addEventListener("click", () => openDataSettings());
    }
    if (card.nextElementSibling !== button) card.after(button);
  }

  // 2.4.5 (ders 20, senaryo-211): paketin bu düğmeleri hof-ui.css'te ilk boyamadan önce gizli doğar; yalnız burada izin
  // verilen (data-hof-show) görünür. Önceden React çizdiği anda görünür, bu işlev bir kare sonra gizliyordu.
  const gate = (element, hidden) => {
    setHidden(element, hidden);
    if (hidden) element.removeAttribute("data-hof-show");
    else if (!element.hasAttribute("data-hof-show")) element.setAttribute("data-hof-show", "");
  };
  function gateControls() {
    document.querySelectorAll(".sidebar .nav-item").forEach(button => {
      const label = navLabel(button);
      gate(button, label === "Tabloyu değiştir" || label === "Ayarlar");
    });
    placeSettings();
    document.querySelectorAll(".button-row button").forEach(button => gate(button, navLabel(button).includes("Yeni tablo yükle")));
    document.querySelectorAll(".banner-link").forEach(link => gate(link, navLabel(link).includes("Tabloyu değiştir")));
    document.querySelectorAll(".detail-actions").forEach(row => {
      let visible = 0;
      row.querySelectorAll("button").forEach(button => {
        const label = navLabel(button);
        const hidden = label.includes("Kaynağı değiştir") || (label.includes("Sheet'te aç") && !HOF.settings.linkedSheetUrl);
        gate(button, hidden);
        if (!hidden) visible += 1;
      });
      setHidden(row, visible === 0);
    });
  }

  // Sheet'te artık olmayan kayıtlar tabloda soluk görünür; seçilince detayda kısa açıklama çıkar.
  function markMissing() {
    document.querySelectorAll(".dynamic-table tbody tr").forEach(row => {
      const missing = missingKeys.has(row.dataset.hofKey || "");
      if (row.classList.contains("hof-row-missing") !== missing) row.classList.toggle("hof-row-missing", missing);
    });
    const panel = HOF.detailPanel();
    const key = HOF.selectedCase()?.key || "";
    let note = document.getElementById("hof-missing-note");
    if (!panel || !missingKeys.has(key)) {
      note?.remove();
      return;
    }
    if (!note) {
      note = HOF.el("p", { id: "hof-missing-note", class: "hof-alert hof-alert-soft" }, "Bu kayıt bağlı Google Sheets'te artık yok. Tabloda kalmaya devam eder; yönetici Ayarlar → Veri'den tutabilir veya kaldırabilir.");
    }
    const header = panel.querySelector(".detail-header");
    if (header && note.previousElementSibling !== header) header.after(note);
  }

  HOF.on("live:workspace.changed", change => {
    if (change?.kind === "records" && change.dataset) loadSummary().then(markMissing);
  });
  HOF.on("live:resync", () => loadSummary().then(markMissing));

  HOF.whenReady(() => {
    loadSummary().then(markMissing);
    HOF.onDom(() => {
      gateControls();
      renderStart();
      replaceLegacyModal();
      markMissing();
    });
  });
  // picker: "yeni oturum aç" penceresi (hof-sessions.js) aynı dosya seçiciyi ve bağlantı alanını kullanır.
  const picker = { dropHtml, linkHtml, wireDrop, wireLink, sheetPattern: SHEET_PATTERN };
  // importMatrix (v2.0.17): tarayıcıda hazır matris (serbest sayfadan dönüştürme) — aynı ön izleme/eşleme ekranı.
  const importMatrix = (body, label, options = {}) => runImport({ kind: "excel", ...body }, label, options);
  HOF.sources = { importExcel, importSheet, importMatrix, openDataSettings, openMissing, uploadExcel: importExcel, picker };
})();
